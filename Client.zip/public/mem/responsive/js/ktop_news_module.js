(function($) {
    //path設定
    var XML_PATH = '/mem/responsive/data/news_json_kojin.xml';
    var XML_PATH_SOGO = '/static/responsive/data/news_json_sogo.xml';
    
    $(function(){
        //xmlの呼び出し
        $.get(XML_PATH, function( data, textStatus) {
            //呼び出したxmlの配列化
            var GET_XML = $(data).find( 'record' );
           //news別のカウンタFLG
            var informationFlg = 0;
            var serviceFlg = 0;
            var maintenanceFlg = 0;
            var securityFlg = 0;
            var otherFlg = 0;
            var inportantFlg = 0;
            //news別の配列
            var informationArray = new Array();
            var serviceArray = new Array();
            var maintenanceArray = new Array();
            var inportantArray = new Array();
            var securityArray = new Array();
            var otherArray = new Array();
            //表示件数
            var informationCnt = 5;
            var information02Cnt = 5;
            var inportantCnt = 2;
            var serviceCnt = 5;
            var service02Cnt = 5;
            var maintenanceCnt = 5;
            var maintenance02Cnt = 5;
            var securityCnt = 5;
            var security02Cnt = 5;
            var otherCnt = 5;
            var other02Cnt = 5;
            
            //newsType別に配列に分け入れる
            GET_XML.each( function(e) {
                var newsType = $(this).find('NewsType').text();
                var this_array = $(this);
                if ( newsType != "ktop_important" ) {
                    informationArray.unshift (this_array);
                }
                switch (newsType) {
                    case "ktop_service":
                        serviceArray.unshift (this_array);
                        break;
                    case "ktop_maintenance":
                        maintenanceArray.unshift (this_array);
                        break;
                    case "ktop_security":
                        securityArray.unshift (this_array);
                        break;
                    case "ktop_other":
                        otherArray.unshift (this_array);
                        break;
                    case "ktop_important":
                        inportantArray.unshift (this_array);
                        break;
                    default:
                        break;
                }
            });
            
            //重要なお知らせ
            if ( inportantArray.length > 0 ) {
                $(".top_important").css('display','block');
                $.each(inportantArray, function(e) {
                    var newsType = $(this).find('NewsType').text();
                    var releaseDate = $(this).find('ReleaseDate').text();
                    var newsTitle = $(this).find('NewsTitle').text();
                    var newsDescription = $(this).find('NewsDescription').text();
                    var newsLink = $(this).find('NewsLink').text();
                    var linkTarget = $(this).find("LinkTarget").text();
                    var availability = $(this).find('availability').text();
                    var setHTML = releaseDate ? "<dl class='top_importantDateContent'><dt class='top_important_date'>"+releaseDate+"</dt>" : "<dt class='top_importantDateContent'>&nbsp;</dt>";
                    
                    //linkのチェック
                    if ( newsLink.length > 0 ) {
                        if ( linkTarget.length > 0 && linkTarget == "blank" ) {
                                setHTML += "<dd class='top_important_text'><div><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></div>"
                            } else if ( linkTarget.length > 0 && linkTarget == "winpopup" ){
                                setHTML += "<dd class='top_important_text'><div><a href = '"+ newsLink +"' class='winPopup' target='_blank'> " + newsTitle + "<span class='blankLink'></span></a></div>"
                            } else {
                                setHTML += "<dd class='top_important_text'><div><a href = '"+ newsLink +"'>" + newsTitle + "</a></div>"
                            }
                    } else {
                        setHTML += "<dl class='top_importantDateContent'><dd><div>"+newsTitle+"</div>";
                    }
                    //Descriptionのチェック
                    if ( newsDescription.length > 0 ) {
                        setHTML += "<div>"+ newsDescription +"</div></dd>"
                    } else {
                        setHTML += "</dd></dl>"
                    }
                    //内容の表示
                    if (availability != "Invalid" && inportantFlg < inportantCnt) {
                        $("#ktop_important").append(setHTML);
                        inportantFlg++;
                    }
                });
            } else {
                $(".ktop_importantAreaWrap, .top_important").hide();
            }
            
            //インフォメーション
            if ( informationArray.length > 0 ) {
                $.each(informationArray, function(e) {
                    var newsType = $(this).find('NewsType').text();
                    var releaseDate = $(this).find('ReleaseDate').text();
                    var newsTitle = $(this).find('NewsTitle').text();
                    var newsDescription = $(this).find('NewsDescription').text();
                    var newsLink = $(this).find('NewsLink').text();
                    var linkTarget = $(this).find("LinkTarget").text();
                    var availability = $(this).find('availability').text();
                    var setHTML = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    var setHTMLType02 = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    
                    //linkのチェック
                    if ( newsLink.length > 0 ) {
                        if ( linkTarget.length > 0 && linkTarget == "blank" ) {
                                setHTML += "<dd><div><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                            } else if ( linkTarget.length > 0 && linkTarget == "winpopup" ){
                                setHTML += "<dd><div><a href = '"+ newsLink +"' class='winPopup' target='_blank'> " + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' class='winPopup' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                            } else {
                                setHTML += "<dd><div><a href = '"+ newsLink +"'>" + newsTitle + "</a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"'>" + newsTitle + "</a></span></div></dd>"
                            }
                    } else {
                        setHTML += "<dd><div>"+newsTitle+"</div>";
                        setHTMLType02 += "<dd><div><span class='titleArea'>"+newsTitle+"</span></div></dd>";
                    }
                    //Descriptionのチェック
                    if ( newsDescription.length > 0 ) {
                        setHTML += "<div>"+ newsDescription +"</div></dd>"
                    } else {
                        setHTML += "</dd>"
                    }
                    //内容の表示
                    if (availability != "Invalid") {
                        $("dl#ktop_information").each(function(){
                            if ( $(this).is(".newsType02") && informationFlg < information02Cnt ) {
                                $(this).append(setHTMLType02);
                            } else if ( !$(this).is(".newsType02") && informationFlg < informationCnt ) {
                                $(this).append(setHTML);
                            }
                        });
                        informationFlg++;
                    }
                });
            } else {
                $("dl#ktop_information").each(function(){
                    $(this).append("<p>新着情報はありません。</p>");
                });
            }
            
            //商品情報
            if ( serviceArray.length > 0 ) {
                $.each(serviceArray, function(e) {
                    var newsType = $(this).find('NewsType').text();
                    var releaseDate = $(this).find('ReleaseDate').text();
                    var newsTitle = $(this).find('NewsTitle').text();
                    var newsDescription = $(this).find('NewsDescription').text();
                    var newsLink = $(this).find('NewsLink').text();
                    var linkTarget = $(this).find("LinkTarget").text();
                    var availability = $(this).find('availability').text();
                    var setHTML = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    var setHTMLType02 = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    
                    //linkのチェック
                    if ( newsLink.length > 0 ) {
                        if ( linkTarget.length > 0 && linkTarget == "blank" ) {
                                setHTML += "<dd><div><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                            } else if ( linkTarget.length > 0 && linkTarget == "winpopup" ){
                                setHTML += "<dd><div><a href = '"+ newsLink +"' class='winPopup' target='_blank'> " + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' class='winPopup' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                            } else {
                                setHTML += "<dd><div><a href = '"+ newsLink +"'>" + newsTitle + "</a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"'>" + newsTitle + "</a></span></div></dd>"
                            }
                    } else {
                        setHTML += "<dd><div>"+newsTitle+"</div>";
                        setHTMLType02 += "<dd><div><span class='titleArea'>"+newsTitle+"</span></div></dd>";
                    }
                    //Descriptionのチェック
                    if ( newsDescription.length > 0 ) {
                        setHTML += "<div>"+ newsDescription +"</div></dd>"
                    } else {
                        setHTML += "</dd>"
                    }
                    //内容の表示
                    if (availability != "Invalid") {
                        $("dl#ktop_service").each(function(){
                            if ( $(this).is(".newsType02") && serviceFlg < service02Cnt ) {
                                $(this).append(setHTMLType02);
                            } else if ( !$(this).is(".newsType02") && serviceFlg < serviceCnt ) {
                                $(this).append(setHTML);
                            }
                        });
                        serviceFlg++;
                    }
                });
            } else {
                $("#ktop_service").append("<p>商品情報はありません。</p>");
            }
            
            //メンテナンス情報
            if ( maintenanceArray.length > 0 ) {
                $.each(maintenanceArray, function(e) {
                    var newsType = $(this).find('NewsType').text();
                    var releaseDate = $(this).find('ReleaseDate').text();
                    var newsTitle = $(this).find('NewsTitle').text();
                    var newsDescription = $(this).find('NewsDescription').text();
                    var newsLink = $(this).find('NewsLink').text();
                    var linkTarget = $(this).find("LinkTarget").text();
                    var availability = $(this).find('availability').text();
                    var setHTML = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    var setHTMLType02 = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    
                    //linkのチェック
                    if ( newsLink.length > 0 ) {
                        if ( linkTarget.length > 0 && linkTarget == "blank" ) {
                                setHTML += "<dd><div><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                            } else if ( linkTarget.length > 0 && linkTarget == "winpopup" ){
                                setHTML += "<dd><div><a href = '"+ newsLink +"' class='winPopup' target='_blank'> " + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' class='winPopup' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div>"
                            } else {
                                setHTML += "<dd><div><a href = '"+ newsLink +"'>" + newsTitle + "</a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"'>" + newsTitle + "</a></span></div>"
                            }
                    } else {
                        setHTML += "<dd><div>"+newsTitle+"</div>";
                        setHTMLType02 += "<dd><div>"+newsTitle+"</div>";
                    }
                    //Descriptionのチェック
                    if ( newsDescription.length > 0 ) {
                        setHTML += "<div>"+ newsDescription +"</div></dd>"
                    } else {
                        setHTML += "</dd>"
                    }
                    //内容の表示
                    if (availability != "Invalid" && maintenanceFlg < maintenanceCnt) {
                        $("dl#ktop_maintenance").each(function(){
                            if ( $(this).is(".newsType02") && maintenanceFlg < maintenance02Cnt ) {
                                $(this).append(setHTMLType02);
                            } else if ( !$(this).is(".newsType02") && maintenanceFlg < maintenanceCnt ) {
                                $(this).append(setHTML);
                            }
                        });
                        maintenanceFlg++;
                    }
                });
            } else {
                $("#ktop_maintenance").append("<p>メンテナンス情報はありません。</p>");
            }
            
            //セキュリティ情報
            if ( securityArray.length > 0 ) {
                $.each(securityArray, function(e) {
                    var newsType = $(this).find('NewsType').text();
                    var releaseDate = $(this).find('ReleaseDate').text();
                    var newsTitle = $(this).find('NewsTitle').text();
                    var newsDescription = $(this).find('NewsDescription').text();
                    var newsLink = $(this).find('NewsLink').text();
                    var linkTarget = $(this).find("LinkTarget").text();
                    var availability = $(this).find('availability').text();
                    var setHTML = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    var setHTMLType02 = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    
                    //linkのチェック
                    if ( newsLink.length > 0 ) {
                        if ( linkTarget.length > 0 && linkTarget == "blank" ) {
                                setHTML += "<dd><div><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                            } else if ( linkTarget.length > 0 && linkTarget == "winpopup" ){
                                setHTML += "<dd><div><a href = '"+ newsLink +"' class='winPopup' target='_blank'> " + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' class='winPopup' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div>"
                            } else {
                                setHTML += "<dd><div><a href = '"+ newsLink +"'>" + newsTitle + "</a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"'>" + newsTitle + "</a></span></div>"
                            }
                    } else {
                        setHTML += "<dd><div>"+newsTitle+"</div>";
                        setHTMLType02 += "<dd><div>"+newsTitle+"</div>";
                    }
                    //Descriptionのチェック
                    if ( newsDescription.length > 0 ) {
                        setHTML += "<div>"+ newsDescription +"</div></dd>"
                    } else {
                        setHTML += "</dd>"
                    }
                    //内容の表示
                    if (availability != "Invalid" && securityFlg < securityCnt) {
                        $("dl#ktop_security").each(function(){
                            if ( $(this).is(".newsType02") && securityFlg < security02Cnt ) {
                                $(this).append(setHTMLType02);
                            } else if ( !$(this).is(".newsType02") && securityFlg < securityCnt ) {
                                $(this).append(setHTML);
                            }
                        });
                        securityFlg++;
                    }
                });
            } else {
                $("#ktop_security").append("<p>セキュリティ情報はありません。</p>");
            }
            
            //その他
            if ( otherArray.length > 0 ) {
                $.each(otherArray, function(e) {
                    var newsType = $(this).find('NewsType').text();
                    var releaseDate = $(this).find('ReleaseDate').text();
                    var newsTitle = $(this).find('NewsTitle').text();
                    var newsDescription = $(this).find('NewsDescription').text();
                    var newsLink = $(this).find('NewsLink').text();
                    var linkTarget = $(this).find("LinkTarget").text();
                    var availability = $(this).find('availability').text();
                    var setHTML = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    var setHTMLType02 = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    
                    //linkのチェック
                    if ( newsLink.length > 0 ) {
                        if ( linkTarget.length > 0 && linkTarget == "blank" ) {
                                setHTML += "<dd><div><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                            } else if ( linkTarget.length > 0 && linkTarget == "winpopup" ){
                                setHTML += "<dd><div><a href = '"+ newsLink +"' class='winPopup' target='_blank'> " + newsTitle + "<span class='blankLink'></span></a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' class='winPopup' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div>"
                            } else {
                                setHTML += "<dd><div><a href = '"+ newsLink +"'>" + newsTitle + "</a></div>"
                                setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"'>" + newsTitle + "</a></span></div>"
                            }
                    } else {
                        setHTML += "<dd><div>"+newsTitle+"</div>";
                        setHTMLType02 += "<dd><div>"+newsTitle+"</div>";
                    }
                    //Descriptionのチェック
                    if ( newsDescription.length > 0 ) {
                        setHTML += "<div>"+ newsDescription +"</div></dd>"
                    } else {
                        setHTML += "</dd>"
                    }
                    //内容の表示
                    if (availability != "Invalid" && otherFlg < otherCnt) {
                        $("dl#ktop_other").each(function(){
                            if ( $(this).is(".newsType02") && otherFlg < other02Cnt ) {
                                $(this).append(setHTMLType02);
                            } else if ( !$(this).is(".newsType02") && otherFlg < otherCnt ) {
                                $(this).append(setHTML);
                            }
                        });
                        otherFlg++;
                    }
                });
            } else {
                $("#ktop_other").append("<p>その他の情報はありません。</p>");
            }
            //popUpFunc();
        });

        //news_json_sogo.xmlの呼び出し
        $.get(XML_PATH_SOGO, function( data, textStatus) {
            //呼び出したxmlの配列化
            var GET_XML = $(data).find( 'record' );
           //お客さまの声のカウンタFLG
            var koeFlg = 0;
            //news別の配列
            var koeArray = new Array();
            //表示件数
            var koeCnt = 5;
            var koe02Cnt = 5;
            
            //お客様の声データを配列に入れる
            GET_XML.each( function(e) {
                var newsType = $(this).find('NewsType').text();
                var this_array = $(this);
                if ( newsType === "gtop_koe" ) {
                    koeArray.unshift (this_array);
                }
            });

            if ( koeArray.length > 0 ) {
                $.each(koeArray, function(e) {
                    var newsType = $(this).find('NewsType').text();
                    var releaseDate = $(this).find('ReleaseDate').text();
                    var newsTitle = $(this).find('NewsTitle').text();
                    var newsDescription = $(this).find('NewsDescription').text();
                    var newsLink = $(this).find('NewsLink').text();
                    var linkTarget = $(this).find("LinkTarget").text();
                    var availability = $(this).find('availability').text();
                    var setHTML = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";
                    var setHTMLType02 = releaseDate ? "<dt>"+releaseDate+"</dt>" : "<dt>&nbsp;</dt>";

                    //linkのチェック
                    if ( newsLink.length > 0 ) {
                        setHTML += "<dd><div><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></div>"
                        setHTMLType02 += "<dd><div><span class='titleArea'><a href = '"+ newsLink +"' target='_blank'>" + newsTitle + "<span class='blankLink'></span></a></span></div></dd>"
                    } else {
                        setHTML += "<dd><div>"+newsTitle+"</div>";
                        setHTMLType02 += "<div><span class='titleArea'>"+newsTitle+"</span></div></dd>";
                    }
                    //Descriptionのチェック
//                    if ( newsDescription.length > 0 ) {
//                        setHTML += "<div>"+ newsDescription +"</div></dd>"
//                    } else {
//                       setHTML += "</dd>"
//                    }
                    //内容の表示
                    if (availability != "Invalid") {
                        $("dl#ktop_koe").each(function(){
                            if ( $(this).is(".newsType02") && koeFlg < koe02Cnt ) {
                                $(this).append(setHTMLType02);
                            } else if ( !$(this).is(".newsType02") && koeFlg < koeCnt ) {
                                $(this).append(setHTML);
                            }
                        });
                        koeFlg++;
                    }
                });
            } else {
                $("dl#ktop_koe").each(function(){
                    $(this).append("<p>お客さまの声に関する情報はありません。</p>");
                });
            }
        });
        
    });
    
})(jQuery);

//画像を切り替える処理
(function(){
    //最初のactタブの画像変更
    var firstActImg = $('#tabType03 ul li.act').children('img');
    var firstActSrc = firstActImg.attr('src');
    if (firstActSrc != undefined) {
        var firstActPath = firstActSrc.substring(0, firstActSrc.lastIndexOf(".", firstActSrc.length));
    } else {
        var firstActPath = "";
    }
    firstActImg.attr('src',firstActPath + '_act.png');
    //clickした際の処理（clickイベントハンドラ付与）
    $('#tabType03 ul li').click(function(){
        var indexNum;
        var actTab = $('#tabType03 ul li.act');
        if(!$(this).hasClass('act')){
            //act初期化
            actTab.removeClass('act');
            var noActPath = actTab.children('img').attr('src').replace('_act','');
            actTab.children('img').attr('src',noActPath);
            if($('html').hasClass('ie9') && actTab.children('img').attr('style').match('_act')){
                //ie9対応
                var styleClear = actTab.children('img').attr('style').replace('_act','');
                actTab.children('img').attr('style',styleClear)
            }

            //clickしたタブの画像切り替え
            indexNum = $('#tabType03 ul li').index(this);
            var targetImg = $('#tabType03 ul li').eq(indexNum).children('img');
            var targetSrc = targetImg.attr('src');
            var targetPath = targetSrc.substring(0 , targetSrc.lastIndexOf(".",targetSrc.length) ) ;
            targetImg.attr('src',targetPath + '_act.png');
        }
    });
})(jQuery);