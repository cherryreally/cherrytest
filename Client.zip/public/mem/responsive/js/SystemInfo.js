$(function() {

	var DATA_PATH = '/static/responsive/data/system_info.xml';
	var COLORS = {
		'balck': '',
		'red': 'txtNormalImp'
	};

	function prepareSystemInfo() {
		$.ajax(DATA_PATH, {
				dataType: 'xml',
				cache: false
		}).done(function(data) {
			try {
				var $data = $(data);
				var $systemInfoArea = $('#systemInfoArea');
				var $infos = $data.find('info');
				if (!$infos.length) {
					// 掲載情報が無い場合はエリア非表示
					$systemInfoArea.css('display', 'none');
					return;
				}

				// タイトルを設定
				$systemInfoArea.find('[data-systeminfo-item="title"]').html($data.find('title').text());

				// 掲載情報内容表示エリア
				var $systemInfosPC = $systemInfoArea.find('.forPcBlock [data-systeminfo-item="infos"]');
				var $systemInfosSP = $systemInfoArea.find('.forSpBlock [data-systeminfo-item="infos"]');

				// テンプレート
				var $templatePC = $systemInfoArea.find('.forPcBlock [data-systeminfo-item="info"]');
				var $templateSP = $systemInfoArea.find('.forSpBlock [data-systeminfo-item="info"]');

				// 掲載情報を生成
				$infos.each(function () {
					var $systemInfoData = $(this);
					var $systemInfoPC = $templatePC.clone();
					var $systemInfoSP = $templateSP.clone();
					var color = getColorClass($systemInfoData.find('color').text());
					var date = $systemInfoData.find('date').text();
					var detail = $systemInfoData.find('detail').text();

					$systemInfoPC.addClass(color);
					$systemInfoPC.find('[data-systeminfo-item="date"]').html(date);
					$systemInfoPC.find('[data-systeminfo-item="detail"]').html(detail);

					$systemInfoSP.addClass(color);
					$systemInfoSP.find('[data-systeminfo-item="date"]').html(date);
					$systemInfoSP.find('[data-systeminfo-item="detail"]').html(detail);

					$systemInfosPC.append($systemInfoPC);
					$systemInfosSP.append($systemInfoSP);
				});

				// テンプレートを削除
				$templatePC.remove();
				$templateSP.remove();

				// エリアを表示
				$systemInfoArea.css('display', '');
			} catch (e) {
				// 例外発生時は明示的にエリア非表示
				$('#systemInfoArea').css('display', 'none');
			}
		});
	}

	function getColorClass(color) {
		return (typeof COLORS[color] === 'undefined') ? '' : COLORS[color];
	}

	prepareSystemInfo();

});