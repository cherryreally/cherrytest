(function($) {
    document.getElementById("id_input").addEventListener("focus", function() {
      this.removeAttribute('readonly');
    });
    document.getElementById("pw_input").addEventListener("focus", function() {
      this.removeAttribute('readonly');
    });

    document.getElementById("pw_eye").addEventListener("click", function() {
        let pw_eye = $(this);
        let pw_input = $("#pw_input");
        pw_eye.toggleClass("mdi-eye mdi-eye-off");
        if (pw_input.attr("type") == "password") {
            pw_input.attr("type", "text");
        } else {
            pw_input.attr("type","password");
        }
    });
    //オプション
    const options = {
        childList: true, //直接の子の変更を監視
    }
    //コールバック関数
    function callback(mutationsList, observer) {
      mutationsList.forEach(function(mutation){
            const children = mutation.target.children;
            let addFlag;
            let idErr;
            children.forEach(function(child){
                if(child.className == "loginValidationMessage") {
                    addFlag = 1;
                    if(mutation.target.id == "input_id" && child.textContent == "IDをご入力ください。") {
                      idErr = 1;
                    }
                }
            });
            if(addFlag) {
                if(mutation.target.id == "input_id") {
                    if(mutation.target.classList.contains("maB52")) {
                        mutation.target.classList.remove("maB52");
                    } else {
                        mutation.target.classList.remove("maB72");
                    }
                    if(idErr){
                        mutation.target.classList.add("maB52");
                    } else {
                        mutation.target.classList.add("maB72");
                    }
                } else {
                    mutation.target.classList.add("maB60");
                }
                mutation.target.classList.add("errorColor");
            } else {
                if(mutation.target.id == "input_id") {
                    if(mutation.target.classList.contains("maB52")) {
                        mutation.target.classList.remove("maB52");
                    } else {
                        mutation.target.classList.remove("maB72");
                    }
                } else {
                    mutation.target.classList.remove("maB60");
                }
                mutation.target.classList.remove("errorColor");
            }
        });
    }

    //ターゲット要素をDOMで取得
    const target1 = document.querySelector("#input_id");
    const target2 = document.querySelector("#input_password");
    //インスタンス化
    const obs = new MutationObserver(callback);
    //ターゲット要素の監視を開始
    obs.observe(target1, options);
    obs.observe(target2, options);
})(jQuery);