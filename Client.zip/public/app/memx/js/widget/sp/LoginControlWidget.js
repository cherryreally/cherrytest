define([
'dojo/_base/declare', 
'dojo/_base/array',
'dojo/_base/lang',
'dojo/topic', 
'dojo/dom', 
'dojo/dom-style',
'dojo/text!./LoginControlWidget.html', 
'dijit/registry', 
'vp/alcor/control/StoreManager',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/_LocationHandler',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/util/Logger',
'vps/member/WebApiConst', 
'vps/member/force_login/LoginConst'
], function(declare, array, lang, topic, dom, domStyle, template, registry, StoreManager,
TransitionManager, LocationHandler, AlcorConstants, _AbstractPage, Logger, WebApiConst, LoginConst) {
var _myself = 'vps.member.LoginControlWidget';

return declare('vps.member.LoginControlWidget', [_AbstractPage],
 {

templateString: template,

headerPreLogin:     'vps.member.HeaderWidgetPreLogin',     
headerPostLogin:    'vps.member.HeaderWidgetPostLogin',    
menuPreLogin:       LoginConst.MENU_WIDGET_PRE_LOGIN,       
menuPostLogin:      'vps.member.MenuWidgetPostLogin',      
footerPreLogin:     'vps.member.FooterWidgetPreLogin',     
footerPostLogin:    'vps.member.FooterWidgetPostLogin',    

loginFlg: 'default', 

constructor: function(kwArgs) {
this.own(topic.subscribe(AlcorConstants.LOGIN_STATUS.LOGIN_EVENT_VP, lang.hitch(this, function(){

var _loginFlg = arguments[0];
var res = arguments[1];
var status = res ? res.getStatus() : null;
var transitTo = arguments[2];
var paramObj = arguments[3];

this.setDefaultLoginFlg();

var keysJsonPath = StoreManager.getKeysJsonPath();
StoreManager.loadKeyData(keysJsonPath, lang.hitch(this, function(store, keys) {
console.log("LoginControlWidget reload keys.json and callback");

if (this.isReplace()) {
this.replaceHeaderFooterMenuWidget(_loginFlg);
}


if (status === AlcorConstants.HTTP_STATUS_CODE.UNAUTHORIZED) { 
this._onNotLoggedIn(transitTo, paramObj);
return;
}

if(paramObj._login){

var link = store.get(AlcorConstants.LINK_ID_PREFIX + "00.u161.judge");

var _transitTo;
if(transitTo){
_transitTo = transitTo.split('?')[0];
}else{
_transitTo = transitTo;
}

var cached = StoreManager.fetchScreenData(AlcorConstants.FORCE_LOGIN_BACK);
var current = StoreManager.getUserData(LoginConst.CURRENT_FOR_LOGIN);

if( cached && cached.data && link && link.url && _transitTo === link.url){
if(_transitTo.indexOf("http") === 0 || _transitTo.indexOf("//") === 0){
var tmp = _transitTo.slice(_transitTo.indexOf("//") + 2);
_transitTo = tmp.slice(tmp.indexOf("/"));
}

var _postData = {
'strURL': encodeURIComponent(current)
};

TransitionManager.transit({
webApiId: _transitTo,
doMove: false,
postData: _postData,
success: function(res){
if(res && res.header && res.header.transitTo === current){
var _cwm = TransitionManager.getContentWidgetManager();
StoreManager.removeScreenData(AlcorConstants.FORCE_LOGIN_BACK);

if(typeof cached.data === 'string'){
_cwm.placeContentWidget(cached.data);
}else if(cached.data.webApiId || cached.data.transitTo){
TransitionManager.transit(cached.data);
}

return;
}

if(res && res.header && res.header.transitTo){
LocationHandler.move(res.header.transitTo);
}
}
});      

Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55206003',
errorMessage: _myself +
'::onStartup() ' +
'transit for agreejudge service.  serviceURL : ' + _transitTo +
' , strURL :' + current
});

return;
}

if( cached && cached.data && transitTo === current){
var _cwm = TransitionManager.getContentWidgetManager();
StoreManager.removeScreenData(AlcorConstants.FORCE_LOGIN_BACK);

if(typeof cached.data === 'string'){
_cwm.placeContentWidget(cached.data);
}else if(cached.data.webApiId || cached.data.transitTo){
TransitionManager.transit(cached.data);
}
return;
}
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55206004',
errorMessage: _myself +
'::onStartup() ' +
'move to transitTo URL : ' + transitTo
});

this._transitForSuccess(transitTo, res, paramObj, location.href);
}else if(paramObj.syncReloadKeys){
this._transitForSuccess(transitTo, res, paramObj, location.href);
}

}));

})));
},

setDefaultLoginFlg: function() {
var _head = dom.byId(LoginConst.HEADER_WIDGET_DEFAULT_ID);
if(_head){
array.forEach(registry.findWidgets(_head), lang.hitch(this, function(widget) {
if(widget && widget.declaredClass && widget.declaredClass === this.headerPreLogin){
this.loginFlg = AlcorConstants.LOGIN_STATUS.NOT_LOGINED;
}else if(widget && widget.declaredClass && widget.declaredClass === this.headerPostLogin){
this.loginFlg = AlcorConstants.LOGIN_STATUS.LOGINED;
}
}));
}
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55206002',
errorMessage: _myself +
'::setDefaultLoginFlg() ' +
'default loginFlg : ' + this.loginFlg
});
},
_transitForSuccess: function(transitTo, res, paramObj, current) {
var status = res ? res.getStatus() : null;
if(transitTo && status === AlcorConstants.HTTP_STATUS_CODE.SUCCESS){
if(transitTo === current){
location.reload(); 
} else {
TransitionManager.execTransitTo(transitTo, paramObj, res);
}
}
},
_onNotLoggedIn: function(transitTo, paramObj) {
if (!transitTo.match(AlcorConstants.CONTENTS_WIDGET_REGEXP)) { 
var query = LocationHandler.getQueryObject();
if (query && query[AlcorConstants.RETURN_PATH_PARAM]) {
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55206005',
errorMessage: _myself +
'::_onNotLoggedIn() ' +
'cannot transit to LoginPage twice'
});
} else {
var newQuery = {};
newQuery[AlcorConstants.RETURN_PATH_PARAM] = LocationHandler.getHref();
LocationHandler.move(transitTo, paramObj.replaceLocation, newQuery);
}
} else { 
var _current = TransitionManager._cwManager._currentContentWidget;
TransitionManager._cwManager.placeContentWidget(transitTo).then(lang.hitch(this, function() {

if (paramObj._isInitTransitOptions){
StoreManager.putScreenData(AlcorConstants.FORCE_LOGIN_BACK,_current.declaredClass);
} else {
var cached = StoreManager.fetchScreenData(AlcorConstants.PREVIOUS_OPTIONS);
if(cached && cached.data){
StoreManager.putScreenData(AlcorConstants.FORCE_LOGIN_BACK,cached.data);
}
}

}));
}

StoreManager.removeScreenData(AlcorConstants.PREVIOUS_OPTIONS);
},

replaceHeaderFooterMenuWidget: function(loginStatus){

if((loginStatus === AlcorConstants.LOGIN_STATUS.LOGINED) && (loginStatus !== this.loginFlg)){
this.replaceWidgetWithName(this.headerPostLogin ,LoginConst.HEADER_WIDGET_DEFAULT_ID);
this.replaceWidgetWithName(this.menuPostLogin ,LoginConst.MENU_WIDGET_DEFAULT_ID);
this.replaceWidgetWithName(this.footerPostLogin ,LoginConst.FOOTER_WIDGET_DEFAULT_ID);
this.loginFlg = loginStatus;
} else if((loginStatus === AlcorConstants.LOGIN_STATUS.NOT_LOGINED) && (loginStatus !== this.loginFlg)){
this.replaceWidgetWithName(this.headerPreLogin ,LoginConst.HEADER_WIDGET_DEFAULT_ID);
var menuPreLoginWidget = this.replaceWidgetWithName(this.menuPreLogin ,LoginConst.MENU_WIDGET_DEFAULT_ID);
this.replaceWidgetWithName(this.footerPreLogin ,LoginConst.FOOTER_WIDGET_DEFAULT_ID);
this.loginFlg = loginStatus;
}
},

replaceWidgetWithName: function(contentWidgetName, widgetId){
var _target = dom.byId(widgetId);
if(_target){
var widgetClass = lang.getObject(contentWidgetName);
if (widgetClass) { 
return this.replaceWidget(widgetClass, widgetId);
} else { 
var modulePath = contentWidgetName.replace(/\./g, '/');
try {
require([modulePath], lang.hitch(this, function() {
var widgetClass = lang.getObject(contentWidgetName);
return this.replaceWidget(widgetClass, widgetId);
}));
} catch (e) { 
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55206001',
errorMessage: _myself +
'::replaceWidgetWithName() ' +
'failed to require widget : ' + modulePath
});
}
}
}
},

replaceWidget: function(widgetClass, widgetId){
this.destroyOldWidget(widgetId);
var newWidget = new widgetClass();

newWidget.placeAt(widgetId).startup();
return newWidget;
},

destroyOldWidget: function(parentId) {
array.forEach(registry.findWidgets(dom.byId(parentId)), function(widget) {
widget.destroy();
});
},

isReplace: function() {
var current = LocationHandler.getHref();
if(current.indexOf("logout") >= 0){
return false;
} else {
return true;
}
}


});
});
