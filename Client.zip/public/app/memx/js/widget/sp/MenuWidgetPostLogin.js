define([
'dojo/_base/declare', 
'dojo/dom', 
'vpx/sp/view/ActionPreparatorBr',
'dojo/text!./MenuWidgetPostLogin.html', 
'/app/memx/js/widget/HMFWidgetUtil.js',
'vps/member/WebApiConst',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/control/StoreManager',
'vp/alcor/pages/MenuWidget', 
'vp/alcor/view/ExtLink'
], function(declare, dom, ActionPreparator, template, HMFWidgetUtil,
WebApiConst, AlcorConstants, StoreManager, MenuWidget, ExtLink) {

return declare('vps.member.MenuWidgetPostLogin', [MenuWidget],  {
templateString: template,

onStartup: function() {
this.inherited(arguments);


}
});
});
