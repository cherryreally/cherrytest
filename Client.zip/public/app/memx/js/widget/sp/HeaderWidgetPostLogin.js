define([
'dojo/_base/declare', 
'dojo/text!./HeaderWidgetPostLogin.html', 
'vp/alcor/pages/HeaderWidget', 
'/app/memx/js/widget/HMFWidgetUtil.js',
'vpx/view/megadropdown',
'vpx/sp/view/ActionPreparatorBr',
'vpx/sp/view/VAppWebView'
], function(declare, template, HeaderWidget, HMFWidgetUtil,
megadropdown, ActionPreparator, VAppWebView) {

return declare('vps.member.HeaderWidgetPostLogin', [HeaderWidget],  {
templateString: template,

onBuildRendered: function() {
VAppWebView.prepareVAppWebView();
},
onStartup: function() {
this.inherited(arguments);
this.afterReplace();
},
afterReplace: function(){
HMFWidgetUtil.replaceLink("vpass.member.user.HpSvrRoot", ".HpSvrRoot_header");
}
});
});
