define([
'/app/memx/js/widget/WebApiConst.js',
'dojo/_base/lang'
], function(WebApiConst, lang) {
return lang.mixin(WebApiConst, {
COMMON_KEYS_JSON_PATH: '/app/memx/common_sp_keys.json'
});
});
