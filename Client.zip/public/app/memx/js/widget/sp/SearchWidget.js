define([
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom',
'dojo/dom-style',
'dojo/topic',
'dijit/registry',
'dojo/text!./SearchWidget.html', 
'vp/alcor/pages/_AbstractPage',
'vp/alcor/constants/AlcorConstants',
'vpx/sp/view/ActionPreparatorBr',
'vp/alcor/util/UAUtil'
], function(declare, lang, dom, domStyle,
topic, registry, template, _AbstractPage, AlcorConstants, ActionPreparator, UAUtil) {

function switchLinkDisplay(isLoggedIn) {
var mypageLink = dom.byId('mypage_link');
var toppageLink = dom.byId('toppage_link');

if (!mypageLink || !toppageLink) {
return;
}
var mypageStyle = isLoggedIn ? 'block' : 'none';
var toppageStyle = isLoggedIn ? 'none' : 'block';

domStyle.set(mypageLink, 'display', mypageStyle);
domStyle.set(toppageLink, 'display', toppageStyle);
}

return declare([_AbstractPage],  {
templateString: template,
_pcSearch:"switch_pc_search",

isLoggedIn: true,

constructor: function() {
this.own(topic.subscribe(AlcorConstants.LOGIN_STATUS.LOGIN_EVENT_VP, lang.hitch(this, function(_loginFlg) {
this.isLoggedIn = _loginFlg !== AlcorConstants.LOGIN_STATUS.NOT_LOGINED;
switchLinkDisplay(this.isLoggedIn);
})));
},

onStartup: function() {

switchLinkDisplay(this.isLoggedIn);

this.onNode(this._pcSearch, 'click', function() {
UAUtil.switchDevice("01:01");
});
}
});
});
