define([
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom',
'dojo/text!./DeviceButton.html',
'dojo/dom-style',
'vp/alcor/util/UAUtil',
'vp/alcor/config/AlcorConfig',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/pages/_AbstractPage'
], function(declare, lang, dom, template, domStyle, UAUtil, AlcorConfig, AlcorConstants, _AbstractPage) {
return declare('vps.member.EnableDeviceButton', [_AbstractPage], {
templateString: template,
_pc:"switch_pc",
_pcSearch:"switch_pc_search",

onStartup: function() {
if (dom.byId('switch_pc')) {
domStyle.set(this._pc, "display", "block");
}
if (dom.byId('switch_pc_search')) {
domStyle.set(this._pcSearch, "display", "block");
}
}
});
});
