define([
    'dojo/_base/array',
    'dojo/_base/lang',
    'dojo/date/locale',
    'vp/alcor/control/StoreManager',
    'vp/alcor/view/FuncControl'
], function(array, lang, locale, StoreManager, FuncControl) {
    return {
        /**
         * 受け取った値が存在するかどうかを真偽判定する。<br>
         * 配列以外の場合：null, undefined, 空文字列を偽とし、それ以外の値を真とする。<br>
         * 配列の場合：長さ0を偽とし、それ以外の場合を真とする。<br>
         * @param {array|string} value 評価する値
         * @returns {boolean} 受け取った値がこの関数の条件を満たせばtrue、それ以外の場合はfalse
         * @private
         */
        _present: function(value) {
            return value !== null && value !== undefined &&
                value !== '' && (!lang.isArray(value) || value.length !== 0);
        },
        
        /**
         * 2つの値を受け取り、==で比較した結果が真、かつ値の組み合わせが空文字と0でない場合はtrue、
         * それ以外の場合はfalseを返す。
         * @param {number|string} a 比較対象とする値
         * @param {number|string} b 比較対象とする値
         * @returns {boolean} 受け取った値がこの関数の条件を満たせばtrue、それ以外の場合はfalse
         * @private
         */
        _equal: function(a, b) {
            /* jshint eqeqeq: false */
            // JSでは '' と 0 の == はtrueとなってしまうため、同組み合わせのみ特別扱いでfalseとする
            return a == b && !(a === '' && b === 0 || a === 0 && b === '');
        },
        
        /**
         * 8桁で渡された数値文字列をDateコンストラクタ関数を実行できる形式に変換する。<br>
         * 変換後の文字列が日付型に変換できない場合は対象文字列をそのまま返す。
         * @param {string} 対象文字列
         * @returns {string} 変換された文字列または対象文字列
         * @private
         */
        _convDateString: function(value) {
            if (!value || !lang.isString(value) || value.length !== 8) {
                return value;
            }
            var datestring = [value.substr(0, 4), value.substr(4, 2), value.substr(6, 2)].join('/');
            return locale.parse(datestring, {
                locale: 'ja-jp',
                selector: 'date'
            }) ? datestring : value;
        },
        
        /**
         * TOP画面の事前処理。<br>
         * info2, info3, info4<br>
         * @param {object} res Web-APIレスポンスデータ
         * @public
         */
        prepareTop: function(res) {
            if (res && res.body && res.body.content) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                if (res.body.content.WebMeisaiTopDisplayServiceBean) {
                    // headerのtransitToの値によって事前処理分岐
                    if (transitTo === 'vp.member.pages.info2') { // TOP：封書
                        this._prepareInfo2(content);
                    } else if (transitTo === 'vp.member.pages.info3') { // TOP：はがき
                        this._prepareInfo3(content);
                    } else if (transitTo === 'vp.member.pages.info4') { // TOP：S法人
                        this._prepareInfo4(content);
                    }
                } else if (res.body.content.CustomizedMeisaiAnsDisplayServiceBean) {
                    if (transitTo === 'vp.member.pages.info13'){
                        this._prepareInfo13(content);
                    }
                }
            }
        },
        
        /**
         * 金融商品画面の事前処理。<br>
         * info5<br>
         * @param {object} res Web-APIレスポンスデータ
         * @public
         */
        prepareFin: function(res) {
            if (res && res.body && res.body.content) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                if (res.body.content.WebMeisaiFinDisplayServiceBean) {
                    // headerのtransitToの値によって事前処理分岐
                    if (transitTo === 'vp.member.pages.info5') {
                        this._prepareInfo5(content);
                    }
                } else if (res.body.content.CustomizedMeisaiAnsDisplayServiceBean) {
                    if (transitTo === 'vp.member.pages.info13') {
                        this._prepareInfo13(content);
                    }
                }
            }
        },
        
        /**
         * 内訳画面の事前処理。<br>
         * info6, info7<br>
         * @param {object} res Web-APIレスポンスデータ
         * @public
         */
        prepareDetail: function(res) {
            if (res && res.body && res.body.content) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                if (res.body.content.WebMeisaiDetailDisplayServiceBean) {
                    // headerのtransitToの値によって事前処理分岐
                    if (transitTo === 'vp.member.pages.info6') { // 内訳画面
                        this._prepareInfo6(content);
                    } else if (transitTo === 'vp.member.pages.info7') { // 内訳画面：S法人
                        this._prepareInfo7(content);
                    }
                } else if (res.body.content.CustomizedMeisaiAnsDisplayServiceBean) {
                    if (transitTo === 'vp.member.pages.info13') {
                        this._prepareInfo13(content);
                    }
                }
            }
        },
        
        // **********************//
        // ***以降、ページ毎のメソッド***//
        // **********************//
        
        // ========================================== TOP系 ========================================== //
        
        /**
         * info2 : TOP(封書)の事前処理
         * @param {object} content Web-APIレスポンスデータのcontent部
         * @private
         */
        _prepareInfo2: function(content) {
            var bean = content.WebMeisaiTopDisplayServiceBean;
            var vo = bean.webMeisaiTopK3Vo;
            
            // prMsg12(PR文言「*12」)の配列を結合
            bean._prMsg12 = lang.isArray(bean.prMsg12) ? bean.prMsg12.join('') : '';
            
            // prMsg03(PR文言「*03」)の配列を結合
            bean._prMsg03 = lang.isArray(bean.prMsg03) ? bean.prMsg03.join('') : '';
            
            // prMsg04(PR文言「*04」)の配列を結合
            bean._prMsg04 = lang.isArray(bean.prMsg04) ? bean.prMsg04.join('') : '';
            
            // prMsg05(PR文言「*05」)の配列を結合
            bean._prMsg05 = lang.isArray(bean.prMsg05) ? bean.prMsg05.join('') : '';
            
            // otoiawaseの配列を結合
            vo._otoiawase = lang.isArray(vo.otoiawase) ? vo.otoiawase.join('<br>') : '';
            
            // otoiawaseの1行目だけ<b>タグで囲み、それ以外は通常のまま配列を結合
            if (lang.isArray(vo.otoiawase)) {
                vo._otoiawaseBoldFirstRaw = vo.otoiawase;
                vo._otoiawaseBoldFirstRaw[0] = '<b>' + vo.otoiawase[0] + '</b>';
                vo._otoiawaseBoldFirstRaw = vo._otoiawaseBoldFirstRaw.join('<br>');
            } else {
                vo._otoiawaseBoldFirstRaw = '';
            }
            
            // webMeisaiTopK3Vo.joiningDay1、webMeisaiTopK3Vo.joiningDay2(加入･切替日)を日付型文字列に変換する
            vo._joiningDay1 = this._convDateString(vo.joiningDay1);
            vo._joiningDay2 = this._convDateString(vo.joiningDay2);
            
            // サーバーから取得したbeanを加工
            if (!vo.accountOvly || !vo.accountOvly.match(/A00[1-4]/)) {
                // A001～A004に該当しない場合はA000とする
                vo.accountOvly = 'A000';
            }
            var referUrl = content.HpSvrRoot.value + content.TkAccountExplanation.value + bean.bridgePagePrm;
            bean._referUrl = referUrl;
            
            // A000, A001の場合は残高表示サービスについてオンライン口座照会表示用フラグを追加
            if (vo.accountOvly.match(/A00[01]/)) {
                bean._isAccountOvly01 = true;
                
                var olLinkIndicateFl = bean.olLinkIndicateFl; // SMBCオンライン接続リンク先有無フラグ
                var menteDetailFlg = bean.menteDetailFlg; // メンテナンス詳細フラグ
                
                if (olLinkIndicateFl === '1') {
                    // 決済金融機関残高照会ページへのリンクあり
                    vo.olShowFlag = '1';
                } else if (olLinkIndicateFl === '2' && menteDetailFlg === '1') {
                    // メンテナンスページへのリンクあり メンテナンスGIFあり、リンクありのケース（リンク付きメッセージ）
                    vo.olShowFlag = '2';
                } else if (olLinkIndicateFl === '2' && menteDetailFlg === '2') {
                    // メンテナンスページへのリンクあり メンテナンスGIFのみのケース（メッセージのみ）
                    vo.olShowFlag = '3';
                } else {
                    // 残高照会ページリンクなし メンテナンスページリンクなし
                    vo.olShowFlag = '4';
                }
            }
            
            // A003, A004の場合は残高表示サービスについてオンライン口座照会表示用フラグは1のみ
            if (vo.accountOvly.match(/A00[34]/)) {
                vo.olShowFlag = '1';
            }
            
            // オーバレイ情報04のためのフラグ調整
            if (vo.accountOvly !== 'A001' && vo.accountOvly !== 'A002' &&
                    vo.accountOvly !== 'A003' && vo.accountOvly !== 'A004') {
                vo._accountOvlyOtherFlg = true;
            }
            
            // attentionMsg(注意文言-1)を'（＃印'で始まる場合のみ表示するためのフラグを追加
            bean._isAttentionMsgStartsWithHash = vo.attentionMsg && (vo.attentionMsg.indexOf('（＃印') === 0);
            
            // attentionMsg、attentionMsg2の存在判定(スマホ対応)
            if (this._present(vo.attentionMsg) || this._present(vo.attentionMsg2)) {
                vo._attentionMsgFlg = true;
            }
            
            // attentionMsg21、attentionMsg22の存在判定(スマホ対応)
            if (this._present(vo.attentionMsg21) || this._present(vo.attentionMsg22)) {
                vo._attentionMsgFlg2 = true;
            }
            
            // 照会/会員番号欄オーバレイのフラグを追加
            var memberOvly = vo.memberOvly;
            // スマホのみ 現行のWebMeisaiTopPcV02.jspからロジックを踏襲
            if (memberOvly === 'M002' || memberOvly === 'M004' || memberOvly === 'M009' || memberOvly === 'M202' || memberOvly === 'M204') {
                vo.card2Check = true;
            }
            if (memberOvly === 'M001' || memberOvly === 'M002') {
                // オーバレイコード:001=カード枚数１枚、002=カード枚数２枚
                vo.memberOvlyFlg = '1';
            } else if (memberOvly === 'M003' || memberOvly === 'M004') {
                // 貸金対応 加入日、切替日表示パターン
                // オーバレイコード:003=カード枚数１枚、 004=カード枚数２枚
                vo.memberOvlyFlg = '2';
            } else if (memberOvly === 'M101' || memberOvly === 'M103') {
                // 東急対応用
                vo.memberOvlyFlg = '3';
                // ▽custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 ▽
            }else if (memberOvly === 'M008' || memberOvly === 'M009') {
                //SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件
                //オーバーレイコード:008=通常会員、009=VM統合
                vo.memberOvlyFlg = '5';
                // △custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 △
                // ▽ SC00463：（210422）【営業秘密】Vpass情報マスキング強化対応(PH1．0) ▽
            } else if (memberOvly === 'M201') {
                //オーバーレイコード:M201(代替番号1段表示)
                vo.memberOvlyFlg = '6';
            } else if (memberOvly === 'M202') {
                //オーバーレイコード:M202(代替番号2段表示)
                vo.memberOvlyFlg = '7';
            } else if (memberOvly === 'M203') {
                //オーバーレイコード:M203(代替番号1段、加入・切替日表示)
                vo.memberOvlyFlg = '8';
            } else if (memberOvly === 'M204') {
                //オーバーレイコード:M204(代替番号2段、加入・切替日2段表示)
                vo.memberOvlyFlg = '9';
            }  else {
                // オーバレイコード:その他 2004年06月請求以前の表を表示
                vo.memberOvlyFlg = '0';
            }
            
            var u051MaskingUseracctDisp ='0';
            FuncControl.getResult({
                functionControlKey:'U051_Masking_Useracct_disp',
                type:'equals',
                value:'1'
            }).then(lang.hitch(this, function(isEqual) { 
                if (isEqual) {
                    u051MaskingUseracctDisp ='1';
                }
            }));
            
            // カード加入・切替日表示フラグ
            // カード加入・切替日表示フラグ
            if (vo.memberOvlyFlg === '0' || vo.memberOvlyFlg === '1' || memberOvly === 'M101' ) {
                vo.joiningDayDispFlg1 = false;
                vo.joiningDayDispFlg2 = false;
            } else {
                if (vo.accountOvly === 'A002') {
                    if (vo.joiningDay1 === '') {
                        vo.joiningDayDispFlg1 = false;
                    }
                    if (vo.joiningDay2 === '') {
                        vo.joiningDayDispFlg2 = false;
                    }
                } else {
                    //DCMX専用オーバーレイコード:008=通常会員、009=VM統合　の場合
                    if (vo.memberOvlyFlg === '5') {
                        if(u051MaskingUseracctDisp === '1'){
                            vo.joiningDayDispFlg1 = true;
                            vo.joiningDayDispFlg2 = true;
                        } else {
                            vo.joiningDayDispFlg1 = false;
                            vo.joiningDayDispFlg2 = false;
                        }
                    } else {
                        vo.joiningDayDispFlg1 = true;
                        vo.joiningDayDispFlg2 = true;
                    }
                }
            }
                        
            // 会員番号とカード名称の存在チェックフラグを追加(スマホ表示対応)
            if (this._present(vo.userAcct1) && this._present(vo.cardName1)) {
                //DCMX専用オーバーレイコード:008=通常会員、009=VM統合　の場合
                if(vo.memberOvlyFlg === '5') {
                    if(u051MaskingUseracctDisp === '1') {
                        vo.cardUserChk1 = true;
                    } else {
                        vo.cardUserChk1 = false;
                    }
                } else {
                    vo.cardUserChk1 = true;
                }
            }
            if (this._present(vo.userAcct2) && this._present(vo.cardName2)) {
                //DCMX専用オーバーレイコード:008=通常会員、009=VM統合　の場合
                if(vo.memberOvlyFlg === '5') {
                    if(u051MaskingUseracctDisp === '1') {
                        vo.cardUserChk2 = true;
                    } else {
                        vo.cardUserChk2 = false;
                    }
                } else {
                    vo.cardUserChk2 = true;
                }
            }
            
            // 翌営業日振込サービス表示フラグを追加
            if (bean.preEditFlag) {
                if (!this._equal(vo.furikomiUser, '1') && this._equal(vo.nextFurikomiService, '1')) {
                    vo._nextFurikomiServiceDspFlg = true;
                }
            } else {
                if (!this._equal(vo.furikomiUser, '1') && this._equal(vo.nextFurikomiServiceFixedLength, '1')) {
                    vo._nextFurikomiServiceDspFlg = true;
                }
            }
            //#info2パフォーマンス対応

            //webMeisaiTopK3Vo.accountOvlyとwebMeisaiTopK3Vo.mpDispFlagの不等号、等号チェックを1つに統合するためのパラメータ設定
            if(vo.accountOvly != 'A000' && vo.mpDispFlag == '1'){
                    vo._mpDspFlg = true;
                }
 

            // PR文言の出力情報を整形する。
            if (vo.finPrVoList) {
                array.forEach(vo.finPrVoList, function(entry1, i) {
                    var list = [];
                    var entry = entry1;
                    array.forEach(entry.finPrRowList, function(entry2, i) {
                        if (i < entry.finPrRowCntStart - 1 || entry.finPrRowCntEnd - 1 < i) {
                            return ;
                        }
                        var obj = {};
                        obj.value = entry2;
                        obj.bold = '';
                        // bold判定
                        if (entry.finPrRowCntStart == 1 && i == 0) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 2 && i == 1 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 1 && i == 2 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        list.push(obj);
                    });
                    entry1._finPrRowList = list;
                });
            }
        },
        
        /**
         * info3 : TOP(はがき)の事前処理
         * @param {object} content Web-APIレスポンスデータのcontent部
         * @private
         */
        _prepareInfo3: function(content) {
            var bean = content.WebMeisaiTopDisplayServiceBean;
            var vo = bean.webMeisaiTopK3Vo;
            
            // prMsg11(PR文言「*11」)の配列を結合
            bean._prMsg11 = lang.isArray(bean.prMsg11) ? bean.prMsg11.join('') : '';
            
            // prMsg12(PR文言「*12」)の配列を結合
            bean._prMsg12 = lang.isArray(bean.prMsg12) ? bean.prMsg12.join('') : '';
            
            // prMsg03(PR文言「*03」)の配列を結合
            bean._prMsg03 = lang.isArray(bean.prMsg03) ? bean.prMsg03.join('') : '';
            
            // prMsg04(PR文言「*04」)の配列を結合
            bean._prMsg04 = lang.isArray(bean.prMsg04) ? bean.prMsg04.join('') : '';
            
            // prMsg05(PR文言「*05」)の配列を結合
            bean._prMsg05 = lang.isArray(bean.prMsg05) ? bean.prMsg05.join('') : '';
            
            // otoiawaseの配列を結合
            vo._otoiawase = lang.isArray(vo.otoiawase) ? vo.otoiawase.join('<br>') : '';
            
            var referUrl = content.HpSvrRoot.value + content.TkAccountExplanation.value + bean.bridgePagePrm;
            bean._referUrl = referUrl;
            
            // webMeisaiTopK3Vo.joiningDay1、webMeisaiTopK3Vo.joiningDay2(加入･切替日)を日付型文字列に変換する
            vo._joiningDay1 = this._convDateString(vo.joiningDay1);
            vo._joiningDay2 = this._convDateString(vo.joiningDay2);
            
            // 情報オーバレイの番号を修正
            // A001～A004以外はA000にまるめる。
            if (!vo.accountOvly || !vo.accountOvly.match(/A00[1-4]/)) {
                vo.accountOvly = 'A000';
            }
            // A000, A001の場合は残高表示サービスについてオンライン口座照会表示用フラグを追加
            if (vo.accountOvly.match(/A00[01]/)) {
                bean._isAccountOvly01 = true;
                // olShowFlag の決定
                if (bean.olLinkIndicateFl === '1') {
                    // 決済金融機関残高照会ページへのリンクあり
                    vo.olShowFlag = '1';
                } else if (bean.olLinkIndicateFl === '2' && bean.menteDetailFlg === '1') {
                    // メンテナンスページへのリンクあり メンテナンスGIFあり、リンクありのケース（リンク付きメッセージ）
                    vo.olShowFlag = '2';
                } else if (bean.olLinkIndicateFl === '2' && bean.menteDetailFlg === '2') {
                    // メンテナンスページへのリンクあり メンテナンスGIFのみのケース（メッセージのみ）
                    vo.olShowFlag = '3';
                } else {
                    // 残高照会ページリンクなし メンテナンスページリンクなし
                    vo.olShowFlag = '4';
                }
            }
            
            // A003, A004の場合は残高表示サービスについてオンライン口座照会表示用フラグは1のみ
            if (vo.accountOvly.match(/A00[34]/)) {
                vo.olShowFlag = '1';
            }
            
            // オーバレイ情報04のためのフラグ調整
            if (vo.accountOvly !== 'A001' && vo.accountOvly !== 'A002' &&
                    vo.accountOvly !== 'A003' && vo.accountOvly !== 'A004') {
                vo._accountOvlyOtherFlg = true;
            }
            
            // attentionMsg(注意文言-1)を'（＃印'で始まる場合のみ表示するためのフラグを追加
            bean._isAttentionMsgStartsWithHash = vo.attentionMsg && (vo.attentionMsg.indexOf('（＃印') === 0);
            
            // attentionMsg21、attentionMsg22の存在判定(スマホ対応)
            if (this._present(vo.attentionMsg21) || this._present(vo.attentionMsg22)) {
                vo._attentionMsgFlg2 = true;
            }
            
            // 照会/会員番号欄オーバレイのフラグを追加
            var memberOvly = vo.memberOvly;
            if (memberOvly === 'M001' || memberOvly === 'M002') {
                // オーバレイコード:001=カード枚数１枚、002=カード枚数２枚
                vo.memberOvlyFlg = '1';
            } else if (memberOvly === 'M003' || memberOvly === 'M004') {
                // 貸金対応 加入日、切替日表示パターン
                // オーバレイコード:003=カード枚数１枚、 004=カード枚数２枚
                vo.memberOvlyFlg = '2';
            } else if (memberOvly === 'M101' || memberOvly === 'M103') {
                // 東急対応用
                vo.memberOvlyFlg = '3';
               // ▽custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 ▽
            } else if (memberOvly === 'M008' || memberOvly === 'M009') {
                //SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件
                //オーバーレイコード:008=通常会員、009=VM統合
                vo.memberOvlyFlg = '5';
                // △custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 △
            } else {
                // オーバレイコード:その他 2004年06月請求以前の表を表示
                vo.memberOvlyFlg = '0';
            }

            //SC00463：（210422）【営業秘密】Vpass情報マスキング強化対応(PH1．0)
            //【概要】
            //会員番号の画面表示をハンドリングするための分岐処理。
            //※上記案件の本番対応前後により会員番号を画面表示するか判定するため
            //  対応前：画面表示なし(計算書サーバの保持データが会員番号等のため表示しない)
            //  対応後：画面表示あり(計算書サーバの保持データが代替番号等のため表示する)
            //
            //【判定方法】
            //計算書サーバから取得した会員番号(userAcctCheckData)のレイアウトを基に対応前後を判定する。
            //判定結果を"userAcctDispPattern"に設定(0:表示なし、1：表示あり)し、htmlの画面描画処理に使用する。
            //
            //①フル桁マスキング(****************) の場合
            //⇒対応後レイアウトのため画面表示あり(1：表示あり を設定)
            //
            //②フル桁マスキング 且つ 4桁ハイフン区切り(****-****-****-****) の場合
            //⇒対応前レイアウトのため画面表示なし(0：表示なし を設定)
            //
            //③下3桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：4980-1234-5678-9***、4980-12**-****-9***) の場合
            //⇒対応前レイアウトのため画面表示なし(0：表示なし を設定)
            //
            //④7～12桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：1234-56**-****-1234) の場合
            //⇒対応前レイアウトのため画面表示なし(0：表示なし を設定)
            //※対応前で計算書サーバにスクランブル番号が保持されていた場合等が該当
            //
            //⑤上記以外(例：1234567890123456) の場合
            //⇒対応後レイアウトのため画面表示あり(1：表示あり を設定)
            //※計算書サーバにの保持データが代替番号等の場合に該当

            var userAcctCheckData = vo.userAcct1;
            var fullMaskPattern = '****************';
            var pastFullMaskPattern = '****-****-****-****';
            var lastThreePattern = '***';
            var scramblePattern = /^\d{4}-\d{2}\*{2}-\*{4}-\d{4}$/;

            //①フル桁マスキング(****************) の場合
            if (userAcctCheckData === fullMaskPattern) {
                vo.userAcctDispFlag = '1';

            //②フル桁マスキング 且つ 4桁ハイフン区切り(****-****-****-****) の場合
            } else if (userAcctCheckData === pastFullMaskPattern) {
                vo.userAcctDispFlag = '0';

            //③下3桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：4980-1234-5678-9***、4980-12**-****-9***) の場合
            } else if ((userAcctCheckData.lastIndexOf(lastThreePattern) + lastThreePattern.length === userAcctCheckData.length)) {
                vo.userAcctDispFlag = '0';

            //④7～12桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：1234-56**-****-1234) の場合
            } else if (scramblePattern.test(userAcctCheckData)) {
                vo.userAcctDispFlag = '0';

            //⑤上記以外(例：1234567890123456) の場合
            } else {
                vo.userAcctDispFlag = '1';
            }

            var u051MaskingUseracctDisp ='0';
            FuncControl.getResult({
                functionControlKey:'U051_Masking_Useracct_disp',
                type:'equals',
                value:'1'
            }).then(lang.hitch(this, function(isEqual) { 
                if (isEqual) {
                    u051MaskingUseracctDisp ='1';
                }
            }));
            //#info3パフォーマンス対応

            //webMeisaiTopK3Vo.accountOvlyとwebMeisaiTopK3Vo.mpDispFlagの不等号、等号チェックを1つに統合するためのパラメータ設定
            if(vo.accountOvly != 'A000' && vo.mpDispFlag == '1'){
                    vo._mpDspFlg = true;
                }

            // カード加入・切替日表示フラグ
            if (vo.memberOvlyFlg === '0' || vo.memberOvlyFlg === '1' || memberOvly === 'M101') {
                vo.joiningDayDispFlg1 = false;
                vo.joiningDayDispFlg2 = false;
            } else {
                if (vo.accountOvly === 'A002') {
                    if (vo.joiningDay1 === '') {
                        vo.joiningDayDispFlg1 = false;
                    }
                    if (vo.joiningDay2 === '') {
                        vo.joiningDayDispFlg2 = false;
                    }
                } else {
                    //DCMX専用オーバーレイコード:008=通常会員、009=VM統合　の場合
                    if (vo.memberOvlyFlg === '5') {
                        if(u051MaskingUseracctDisp === '1'){
                            vo.joiningDayDispFlg1 = true;
                            vo.joiningDayDispFlg2 = true;
                        } else {
                            vo.joiningDayDispFlg1 = false;
                            vo.joiningDayDispFlg2 = false;
                        }
                    } else {
                        vo.joiningDayDispFlg1 = true;
                        vo.joiningDayDispFlg2 = true;
                    }
                }
            }

            // 会員番号とカード名称の存在チェックフラグを追加(スマホ表示対応)
            if (this._present(vo.userAcct1) && this._present(vo.cardName1)) {
                //DCMX専用オーバーレイコード:008=通常会員、009=VM統合　の場合
                if(vo.memberOvlyFlg === '5') {
                    if(u051MaskingUseracctDisp === '1') {
                        vo.cardUserChk1 = true;
                    } else {
                        vo.cardUserChk1 = false;
                    }
                } else {
                    vo.cardUserChk1 = true;
                }
            }
            if (this._present(vo.userAcct2) && this._present(vo.cardName2)) {
                //DCMX専用オーバーレイコード:008=通常会員、009=VM統合　の場合
                if(vo.memberOvlyFlg === '5') {
                    if(u051MaskingUseracctDisp === '1') {
                        vo.cardUserChk2 = true;
                    } else {
                        vo.cardUserChk2 = false;
                    }
                } else {
                    vo.cardUserChk2 = true;
                }
            }
            
            // Web明細PR文言「*11」表示フラグを追加
            if (this._equal(vo.callLimitMsgFlg, '1') && this._equal(bean.prMsg11DispFlag, '1')) {
                vo._callLimitPrMsg11DspFlg = true;
            }
            
            // Web明細PR文言「*12」表示フラグを追加
            if (this._equal(vo.callLimitMsgFlg, '2') && this._equal(bean.prMsg12DispFlag, '1')) {
                vo._callLimitPrMsg12DspFlg = true;
            }
            
            // 翌営業日振込サービス表示フラグを追加
            if (!this._equal(vo.furikomiUser, '1') && this._equal(vo.nextFurikomiService, '1')) {
                vo._nextFurikomiServiceDspFlg = true;
            }

            // PR文言の出力情報を整形する。
            if (vo.finPrVoList) {
                array.forEach(vo.finPrVoList, function(entry1, i) {
                    var list = [];
                    var entry = entry1;
                    array.forEach(entry.finPrRowList, function(entry2, i) {
                        if (i < entry.finPrRowCntStart - 1 || entry.finPrRowCntEnd - 1 < i) {
                            return ;
                        }
                        var obj = {};
                        obj.value = entry2;
                        obj.bold = '';
                        // bold判定
                        if (entry.finPrRowCntStart == 1 && i == 0) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 2 && i == 1 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 1 && i == 2 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        list.push(obj);
                    });
                    entry1._finPrRowList = list;
                });
            }
        },
        
        /**
         * info4 : TOP(S法人)の事前処理
         * @param {object} content Web-APIレスポンスデータのcontent部
         * @private
         */
        _prepareInfo4: function(content) {
            var bean = content.WebMeisaiTopDisplayServiceBean;
            var vo = bean.webMeisaiTopK3Vo;
            
            // otoiawaseの配列を結合
            vo._otoiawase = lang.isArray(vo.otoiawase) ? vo.otoiawase.join('<br>') : '';
            
            var referUrl = content.HpSvrRoot.value + content.TkAccountExplanation.value + bean.bridgePagePrm;
            bean._referUrl = referUrl;
            // 口座残高サービスの画像ファイル名(階層が他の値と別のため、うまくReplaceできない)
            bean._referImage = bean.linkHanteiVo.linkImg;
            
            // 残高表示サービスについてオンライン口座照会表示用フラグを追加
            bean._isAccountOvly01 = true;
            // olShowFlag の決定
            if (bean.olLinkIndicateFl === '1') {
                // 決済金融機関残高照会ページへのリンクあり
                vo.olShowFlag = '1';
            } else if (bean.olLinkIndicateFl === '2' && bean.menteDetailFlg === '1') {
                // メンテナンスページへのリンクあり メンテナンスGIFあり、リンクありのケース（リンク付きメッセージ）
                vo.olShowFlag = '2';
            } else if (bean.olLinkIndicateFl === '2' && bean.menteDetailFlg === '2') {
                // メンテナンスページへのリンクあり メンテナンスGIFのみのケース（メッセージのみ）
                vo.olShowFlag = '3';
            } else {
                // 残高照会ページリンクなし メンテナンスページリンクなし
                vo.olShowFlag = '4';
            }
        },
        
        // ========================================== 金融商品系 ========================================== //
        
        /**
         * info5 : 金融商品の事前処理
         * @param {object} content Web-APIレスポンスデータのcontent部
         * @private
         */
        _prepareInfo5: function(content) {
            var bean = content.WebMeisaiFinDisplayServiceBean;
            
            // prMsg06(PR文言「*06」)の配列を結合
            bean._prMsg06 = lang.isArray(bean.prMsg06) ? bean.prMsg06.join('') : '';
            
            // prMsg10(PR文言「*10」)の配列を結合
            bean._prMsg10 = lang.isArray(bean.prMsg10) ? bean.prMsg10.join('') : '';
            
            // prMsg14(PR文言「*14」)の配列を結合
            bean._prMsg14 = lang.isArray(bean.prMsg14) ? bean.prMsg14.join('') : '';

            // prMsg16(PR文言「*16」)の配列を結合
            bean._prMsg16 = lang.isArray(bean.prMsg16) ? bean.prMsg16.join('') : '';

            // prMsg17(PR文言「*17」)の配列を結合
            bean._prMsg17 = lang.isArray(bean.prMsg17) ? bean.prMsg17.join('') : '';

            // divInstallmentInfoList.month(分割表データ.お支払月)を日付型文字列に変換する
            array.forEach(bean.divInstallmentInfoList, function(item) {
                item._month = this._convDateString(item.month);
            }, this);
            
            // キャッシング一括(旧・キャッシュサービス)利率欄表示フラグを追加
            if (!this._equal(bean.formIdDispFlag, '1') && this._present(bean.cashRate)) {
                bean._notCashRateDspFlg = true;
            }
            
            // キャッシュサービス利率表示フラグを追加
            if (this._equal(bean.formIdDispFlag, '1') && this._present(bean.cashRate)) {
                bean._cashRateDspFlg = true;
            }
            
            // 返済明細予定欄表示フラグを追加
            if (this._equal(bean.revoRepaymentDispFlag, '1') && this._equal(bean.revoRepaymentDetailsDispFlag, '1')) {
                bean._revoRepaymentDetailsDispFlag = true;
            }
        },
        
        // ========================================== 内訳系 ========================================== //
        
        /**
         * info6 : 内訳の事前処理
         * @param {object} content Web-APIレスポンスデータのcontent部
         * @private
         */
        _prepareInfo6: function(content) {
            var bean = content.WebMeisaiDetailDisplayServiceBean;
            // タイトル行の表示有無フラグを設定する
            var newOldView = content.NewOldView.value;
            if (newOldView === 'true') {
                var cardAssortmentList = content.CardAssortmentDisplayServiceBean.cardAssortmentList;
                var oldTitleCode = '';
                array.forEach(cardAssortmentList, function(entry, i) {
                    var cardAssortmentInfo = cardAssortmentList[i];
                    array.forEach(cardAssortmentInfo, function(entry2, j) {
                        if (oldTitleCode !== cardAssortmentInfo[j].titleCode) {
                            cardAssortmentInfo[j]._titleCodeFlag = true;
                        } else {
                            cardAssortmentInfo[j]._titleCodeFlag = false;
                        }
                        oldTitleCode = cardAssortmentInfo[j].titleCode;
                    });
                });
            }
            
            // 利用枠に表示する列数をカウントする
            var limitKindCnt = 0;
            if(bean.limitKind !== undefined 
                && bean.limitKind !== null
                && bean.limitKind !== '' ) {
                limitKindCnt = bean.limitKind.length - 1;
            }
            
            bean._limitKindCnt = limitKindCnt;
            
            // オーバレイ情報03（利用枠欄）の編集
            if (bean.limitOvly.match(/G00[1-3]/)) {
                // G001～G003に該当する場合はG00とする
                bean.limitOvly = 'G00';
            } else if (bean.limitOvly.match(/G10[1-3]/)) {
                // G101～G103に該当する場合はG10とする
                bean.limitOvly = 'G10';
            } else if (bean.limitOvly.match(/G20[1-3]/)) {
                // G201～G203に該当する場合はG20とする
                bean.limitOvly = 'G20';
            } else if (bean.limitOvly.match(/G30[1-3]/)) {
                // G301～G303に該当する場合はG30とする
                bean.limitOvly = 'G30';
            } else {
                // 上記に該当しない場合、連携なし
                bean.limitOvly = 'OTHER';
                if (bean.formId === 'G66' || bean.formId === 'CU1') {
                    bean._limitOvlyOtherFlg = 'before';
                } else {
                    bean._limitOvlyOtherFlg = 'after';
                }
            }
            
            // オーバレイ情報15（ポイント告知欄）の編集
            if (bean.pointOvly === 'P008' || bean.pointOvly === 'P018') {
                // P008、P018に該当する場合はP008_P018とする
                bean.pointOvly = 'P008_P018';
            } else if (bean.pointOvly === 'P811' || bean.pointOvly === 'P911') {
                // P811、P911に該当する場合はP811_P911とする
                bean.pointOvly = 'P811_P911';
            } else if (bean.pointOvly === 'P814' || bean.pointOvly === 'P914') {
                // P814、P914に該当する場合はP814_P914とする
                bean.pointOvly = 'P814_P914';
            } else if (bean.pointOvly === 'P019' || bean.pointOvly === 'PCARD2') {
                // ドコモポイントに関係するオーバレイコード P019、PCARD2の場合は、告知欄が異なるため、pointFrameDispFlag に '2' を設定する
                bean.pointFrameDispFlag = '2';
            }
            
            // オーバレイ情報15_オーバレイコードPCARDにおけるロイヤリティクラス表示の判定ロジック
            // 用紙区分、用紙ID表示フラグが共に 1でない 、かつロイヤリティクラスオーバレイがPCARDであること
            if (!this._equal(bean.formKbn, '1') && !this._equal(bean.formIdDispFlag, '1') &&
                    bean.royaltyClassOvly === 'PCARD') {
                // royaltyPcardOvly の存在判定
                if (this._present(bean.royaltyPcardOvly)) {
                    bean._royaltyPcardOvlyDispFlg = true;
                } else {
                    bean._royaltyPcardOvlyDispFlg = false;
                }
            }
            
            // ポイント注意文言の表示フラグを追加
            if (this._present(bean.pointCautionWord) && this._equal(bean.formKbn, '1')) {
                bean._pointCautionWordFlg = true;
            } else {
                bean._pointCautionWordFlg = false;
            }
            
            // 失効文言の表示フラグを追加
            if (this._present(bean.pointReserveWord) && this._equal(bean.formKbn, '1')) {
                if (this._equal(bean.pointReserveWordFlg, '1')) {
                    bean._pointReserveWordDspFlg = '1';
                } else {
                    bean._pointReserveWordDspFlg = '2';
                }
            } else {
                bean._pointReserveWordDspFlg = '0';
            }
            
            // 全面改定対応前 ロイヤリティメッセージフラグを追加
            if (bean.royaltyClassOvly.match(/C00[1-3]/)) {
                bean._royaltyClassOvlyFlg = bean.royaltyClassOvly;
            } else {
                bean._royaltyClassOvlyFlg = 'OTHER';
            }
            
            // prMsg02(PR文言「*02」)の配列を結合
            bean._prMsg02 = lang.isArray(bean.prMsg02) ? bean.prMsg02.join('') : '';
            
            // prMsg13(PR文言「*13」)の配列を結合
            bean._prMsg13 = lang.isArray(bean.prMsg13) ? bean.prMsg13.join('') : '';
            
            // prMsg01(PR文言「*01」)の配列を結合
            bean._prMsg01 = lang.isArray(bean.prMsg01) ? bean.prMsg01.join('') : '';
            
            // 新テーブルの場合に行う
            if (newOldView === 'true') {
                var beanCardAssortment = content.CardAssortmentDisplayServiceBean;
                // カード種別情報表示フラグを追加
                if (this._present(beanCardAssortment.cardAssortmentCount) &&
                        !this._equal(beanCardAssortment.cardAssortmentCount, '0')) {
                    beanCardAssortment._cardAssortmentDspFlg = true;
                }
            }
            
            // ポイントオーバレイ表示フラグを追加
            if (this._present(bean.formIdDispFlag) && this._present(bean.pointOvly)) {
                bean._pointOvlyDspFlg = true;
            }
            
            // ロイヤリティクラスオーバレイ表示フラグを追加
            if (!this._equal(bean.formKbn, '1') && this._equal(bean.royaltyClassOvly, 'PCARD')) {
                bean._royaltyClassOvlyDspFlg = true;
            }
            
            // ロイヤリティメッセージオーバレイ表示フラグを追加
            if (this._equal(bean._royaltyClassOvlyFlg, 'OTHER') && this._present(bean.royaltyWord)) {
                bean._royaltyClassOvlyOtherDspFlg = true;
            }
            
            // プレミアムステージの案内文言表示フラグを追加
            if (this._equal(bean.formIdDispFlag, '1') && this._present(bean.premiumStageWord)) {
                bean._premiumStageWordDspFlg = true;
            }
            
            // サンクスポイント情報欄表示フラグを追加
            if (this._equal(bean.formIdDispFlag, '1') && this._present(bean.thanksPointOvly)) {
                bean._thanksPointOvlyDspFlg = true;
            }
        },
        
        /**
         * info7 : 内訳(S法人)の事前処理
         * @param {object} content Web-APIレスポンスデータのcontent部
         * @private
         */
        _prepareInfo7: function(content) {
            var bean = content.WebMeisaiDetailDisplayServiceBean;
            
            // 現在日表示フラグを追加
            if (bean.nowDateM !== '' && bean.nowDateM !== '**') {
                bean._DateDispFlg = true;
            } else {
                bean._DateDispFlg = false;
            }
            
            // カードご利用枠(カード限度額)の2件目表示制御
            var limitWord = bean.limitWord;
            var limitValue = bean.limitValue;
            
            // 2つ目の限度額文言、限度額の両方が存在しない場合、表示を行わない
            if (!this._equal(limitWord[1], '') && limitValue[1] !== '') {
                bean._limitDispFlg = true;
            } else {
                bean._limitDispFlg = false;
            }
        },

        /**
         * info13 : 利用明細の事前処理
         */
        _prepareInfo13: function(content) {
            var bean = content.CustomizedMeisaiAnsDisplayServiceBean;
            StoreManager.putUserData('info13bean', bean);

            if (bean.meisaiList && bean.meisaiList.length !== 0 && bean.userKbn === '0') {
                if (bean.ktmktKbn === '1' || bean.ktmktKbn === '2') {
                    bean.tempFlg = '012';
                }
            }
            if (bean.csvMoneyFlag === '1' && bean.kanjyoFlag) {
                bean.tempKanjyoFlg = '11';
            } else {
                bean.tempKanjyoFlg = '';
            }
        }

    };
});
