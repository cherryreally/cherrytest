define([
'dojo/_base/declare', 
'dojo/dom', 
'dojo/dom-style',
'dojo/text!./FooterWidgetPostLogin.html', 
'/app/memx/js/widget/HMFWidgetUtil.js',
'vp/alcor/pages/FooterWidget', 
'vp/alcor/util/findWidgetsRecursive',
'vp/alcor/util/UAUtil',
'vps/member/WebApiConst',
'vp/alcor/control/StoreManager',
'vp/alcor/constants/AlcorConstants'
], function(declare, dom, domStyle, template, HMFWidgetUtil, FooterWidget, findWidgetsRecursive, UAUtil, WebApiConst, StoreManager, AlcorConstants) {

return declare('vps.member.FooterWidgetPostLogin', [FooterWidget],  {
templateString: template,
_pc:"switch_pc",    
enableDevice:   "vps.member.EnableDeviceButton",    
disableDevice:   "vps.member.DisableDeviceButton",  

onStartup: function() {
this.inherited(arguments);

this.afterReplace();

var copyArea = dom.byId('CopyAreaYear');
var year = new Date().getYear();
if (year < 2000) {
year += 1900;
}
copyArea.innerHTML = year;

var _contents = dom.byId('Center');
if(_contents){
findWidgetsRecursive(_contents, function(widget) {
if (widget.declaredClass === this.enableDevice ) {
domStyle.set(this._pc, "display", "block");
} else if(widget.declaredClass === this.disableDevice) {
domStyle.set(this._pc, "display", "none");
}
},this);
}

this.onNode(this._pc, 'click', function() {
UAUtil.switchDevice("01:01");
});

this.onNode('footerVpassLogoutBtn', 'click', function() {
var href = '/memx/sp/logout/index.html';
if (WebApiConst.FW_WEBAPI_CONTEXTROOT === AlcorConstants.CONTEXTROOT.MEMTRANS.WEBAPI) {
StoreManager.keyStorePromise.then(function(keyStore) {
var sysprops = keyStore.get(AlcorConstants.SYS_PROP_KEY) || {};
href = sysprops['vpass.member.user.HpSvrRoot'] + href;
});
}
location.href = href;
});
},

afterReplace: function(){
HMFWidgetUtil.replaceLink("vpass.member.user.HpSvrRoot", ".HpSvrRoot_footer");
HMFWidgetUtil.replaceLink("vpass.member.user.NosecHpSvrRoot", ".NosecHpSvrRoot_footer");
}
});
});
