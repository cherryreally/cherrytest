define(function() {
return {
INPUT_PASSWORD_BASE_COUNT_MIN : 6,
INPUT_PASSWORD_BASE_COUNT_MAX : 20,
INPUT_MYID_BASE_COUNT_MIN :  7,
INPUT_MYID_BASE_COUNT_MAX : 20,
ERROR_INPUT_PASSWORD : 'パスワードをご入力ください。',
ERROR_INPUT_PASSWORD_HALF : 'パスワードは6~20桁の半角英数字でご入力ください。',
ERROR_INPUT_PASSWORD_DIGITS : 'パスワードは6~20桁の半角英数字でご入力ください。',
ERROR_INPUT_MYID : 'IDをご入力ください。',
ERROR_INPUT_MYID_HALF : 'IDは7~20桁の半角英数字・記号（“_”および“-”）でご入力ください。',
ERROR_INPUT_MYID_DIGITS : 'IDは7~20桁の半角英数字・記号（“_”および“-”）でご入力ください。',

CURRENT_FOR_LOGIN : 'CurrentForLogin',
MENU_WIDGET_PRE_LOGIN : 'vps.member.MenuWidgetPreLogin',
HEADER_WIDGET_DEFAULT_ID : 'Head',
MENU_WIDGET_DEFAULT_ID : 'Left',
FOOTER_WIDGET_DEFAULT_ID : 'Footer',

LOGIN_URL : '/login/index.html',
LOGOUT_URL : '/logout/index.html',

FORCE_LOGIN_URL : '/force_login/index.html',
FORCE_LOGIN_SMALL_URL : '/sforcelogin/index.html'

};
});
