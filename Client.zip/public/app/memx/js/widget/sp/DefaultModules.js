define([
'/app/memx/js/widget/DefaultModules.js',
'jquery'
], 1);
