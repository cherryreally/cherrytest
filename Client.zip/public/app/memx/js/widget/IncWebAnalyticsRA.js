define([
'dojo/_base/array',
'dojo/_base/lang',
'dojo/dom-construct',
'dojo/query', 
'dojo/_base/declare', 
'vp/alcor/pages/_AbstractPage', 
'vps/member/WebApiConst', 
'vp/alcor/control/xhrController',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/control/StoreManager',
'vp/alcor/control/_LocationHandler',
'vp/alcor/util/fetchDeepProperty',
'vp/alcor/util/closestWidget',
'vp/alcor/util/Logger'
], function(array, lang, domConstruct, query,  declare, _AbstractPage, WebApiConst, xhrController,
AlcorConstants, StoreManager, _LocationHandler, fetchDeepProperty, closestWidget, Logger) {
var _myself = 'vps.member.IncWebAnalyticsRA';

function _endsWith(string, suffix) {
return string.indexOf(suffix, string.length - suffix.length) !== -1;
}

return declare('vps.member.IncWebAnalyticsRA', [_AbstractPage],  {

constructor: function() {
if(!StoreManager.catalystPromise.isFulfilled()){
StoreManager.initSc(this.configPath);
}
},

getContainerRelatedWebApiIdList: function(target) {
if(!target){
target = this.domNode;
}
if (!target) { 
return null;
}
var container = closestWidget(_AbstractPage, target);
if (container) {
var relatedWebApiIdList = container.getRelatedWebApiIdList();
var parentWebApiIdList  = this.getContainerRelatedWebApiIdList(container.domNode.parentNode);
if(parentWebApiIdList){
array.forEach(parentWebApiIdList, function(_item){
relatedWebApiIdList.push(_item);
});
}
return relatedWebApiIdList;
}
return null;
},

getAndCall: function(key, callback) {
var _scVariables = [];

var options = {
method: 'POST',
data:{
requestURI : key
}
};
xhrController(WebApiConst.API.CATALYST_GETVAR_RS0001,options).then(
lang.hitch(this, function(res) {
if(res && res.body && res.body.content &&
res.body.content.SiteCatalystServiceBean &&
res.body.content.SiteCatalystServiceBean.customList){
var customList = res.body.content.SiteCatalystServiceBean.customList;
array.forEach(customList, function(entry) {
if(entry.key){
window[entry.key] = entry.value;
_scVariables.push(entry.key);
}
}, this);
}else{
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55006002',
errorMessage: _myself +
'::onStartup() ' +
'cannot found dynamic vars for sitecatalyst from server responce.'
});
}

this._callSC();
if(callback){
callback();
}
array.forEach(_scVariables, function(key) {
if(window[key]){
window[key] = undefined;
}
if(window.s){
var _key = key.replace("sc_","");
if(window.s[_key]){
window.s[_key] = undefined;
}
}
}, this);

}), lang.hitch(this, function() {
Logger.write({
category: 'VP',
logLevel: 'WARN',
errorNo: 'C55006005',
errorMessage: _myself + '::onStartup() ' + 'SiteCatalyst get var service is failed.'
});

this._callSC();

}));
},

onStartup: function() {
var _disable = query("#ra_disable");
if(_disable.length > 0 || this.configPath === AlcorConstants.CATALYST_DISABLE){
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55006001',
errorMessage: _myself + '::onStartup() ' + 'SiteCatalyst disable flag is detected.'
});
}else{
var _relatedWebApiIdList = this.getContainerRelatedWebApiIdList();
var _path = _LocationHandler.getPathName();
var _current = _path + _LocationHandler.getHash();
if(_endsWith(_path,"/")){
var _keyUrlWithHTML = _path + AlcorConstants.OMITTED_DEFAULT_FILE + _LocationHandler.getHash();
}
var _keyUrl = this.keyURL || _current;

var unSents = StoreManager.queryScreenData().filter(function(entry) {
var isApiMatched = !_relatedWebApiIdList || !_relatedWebApiIdList.length ||
array.some(_relatedWebApiIdList, function(id) {
return entry.id === id;
});

if(isApiMatched && entry && entry.data &&
entry.data[AlcorConstants.SITECATALYST_SESSION_BEAN_NAME] &&
entry.data[AlcorConstants.SITECATALYST_SESSION_BEAN_NAME].loginFlg &&
!entry.data[[AlcorConstants.SITECATALYST_SESSION_BEAN_NAME]].loginInfoOutputFlg){
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55006006',
errorMessage: _myself + '::onStartup() ' + 'Detect unSent Login Flag.'
});
return entry.id;
}
});

StoreManager.catalystPromise.always(lang.hitch(this, function(res) {
var screenList;
if(res && res.data){
screenList = res.get(AlcorConstants.CATALYST_KEY);
}
if(res === AlcorConstants.CATALYST_JSON_ALL ||
(res !== AlcorConstants.CATALYST_JSON_NOT_EXIST &&
((screenList && (array.indexOf(screenList,_keyUrl) !== -1 ||
array.indexOf(screenList,_keyUrlWithHTML) !== -1 )) ||
unSents.length > 0)
)){
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55006007',
errorMessage: _myself +
'::onStartup() ' +
'Get variables for Target Screen.current url:' + _keyUrl
});
this.getAndCall(_keyUrl,function(){
unSents.forEach(function(entry){
entry.data[AlcorConstants.SITECATALYST_SESSION_BEAN_NAME].loginInfoOutputFlg = true;
StoreManager.putScreenData(entry.id,entry.data);
});
});
}else{

Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55006004',
errorMessage: _myself +
'::onStartup() ' +
'current url is not in IncWebAnalyticsRA.json and not unsent status. current url:' +
_keyUrl
});
this._callSC();
}

}));

}
},

_callSC: function() {
if(typeof _satellite !== 'undefined'){
_satellite.track("ajaxLoad");
}else{
Logger.write({
category: 'VP',
logLevel: 'INFO',
errorNo: 'C55006003',
errorMessage: _myself +
'::onStartup() ' + 'cannot load Adobe Analytics Script.'
});
}
}

});
});
