define([
'dojo/_base/declare', 
'dojo/dom', 
'dojo/text!./HeaderWidgetPostLogin.html', 
'vp/alcor/pages/HeaderWidget', 
'./HMFWidgetUtil',
'vpx/view/megadropdown',
'vpx/view/ActionPreparatorBr',
'vp/alcor/view/ExtLink'
], function(declare, dom, template, HeaderWidget, HMFWidgetUtil,
megadropdown, ActionPreparator, ExtLink) {

return declare('vps.member.HeaderWidgetPostLogin', [HeaderWidget],  {
templateString: template,

onStartup: function() {
this.inherited(arguments);

if(megadropdown.MDDinit){
megadropdown.MDDinit();
}
ActionPreparator.prepareHeaderActions();

this.afterReplace();

var extLink = new ExtLink();
extLink.getLinkUrl('00.cmp.domain').then(function(url) {
var domain = url;
var link = dom.byId('h_commonPoint1');
if(link){
var uri = link.pathname;
var queryParam = link.search;
url = domain + uri + queryParam;
link.href = url;
}
});

},
afterReplace: function(){
HMFWidgetUtil.replaceLink("vpass.member.user.HpSvrRoot", ".HpSvrRoot_header");
}
});
});
