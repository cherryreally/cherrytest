/**
 * 
 */
define(['dojo/_base/array', 'dojo/_base/lang', 'vp/alcor/control/StoreManager'], function(array, lang, StoreManager){
    return {
        test: function() {
            alert('呼び出し成功');
        },
        /**
         * TOP画面の事前処理.<br>
         * info2, info3, info4.<br>
         */
        prepareTop: function(res){
            if (res && res.body && res.body.content) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                if (res.body.content.WebMeisaiTopDisplayServiceBean) {
                    // headerのtransitToの値によって事前処理分岐
                    if (transitTo === 'vp.member.pages.info2') { 
                        this._prepareInfo2(content);
                    } else if (transitTo === 'vp.member.pages.info3'){
                        this._prepareInfo3(content);
                    } else if (transitTo === 'vp.member.pages.info4'){
                        this._prepareInfo4(content);
                    }
                } else if (res.body.content.CustomizedMeisaiAnsDisplayServiceBean) {
                    if (transitTo === 'vp.member.pages.info13'){
                        this._prepareInfo13(content);
                    }
                }
            }
        },

        /**
         * TOP(印刷)画面の事前処理.<br>
         * info8, info9.<br>
         */
        prepareTopPrint: function(res){
            if (res && res.body && res.body.content && res.body.content.WebMeisaiTopDisplayServiceBean) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                // headerのtransitToの値によって事前処理分岐
                if (transitTo === 'vp.member.pages.info8') {
                    this._prepareInfo8(content);
                } else if (transitTo === 'vp.member.pages.info9'){
                    // no work.
                }
            }
        },

        /**
         * 金融商品画面の事前処理.<br>
         * info5.<br>
         */
        prepareFin: function(res){
            if (res && res.body && res.body.content) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                if (res.body.content.WebMeisaiFinDisplayServiceBean) {
                    // headerのtransitToの値によって事前処理分岐
                    if (transitTo === 'vp.member.pages.info5') { // TOP(S法人)の事前処理
                        this._prepareInfo5(content);
                    }
                } else if (res.body.content.CustomizedMeisaiAnsDisplayServiceBean) {
                    if (transitTo === 'vp.member.pages.info13') {
                        this._prepareInfo13(content);
                    }
                }
            }
        },

        // info10はDummy利用無し、パフォーマンス対応のための事前処理
        /**
         * 金融商品(印刷)画面の事前処理.<br>
         * info10.<br>
         */
        prepareFinPrint: function(res){
            if (res && res.body && res.body.content && res.body.content.WebMeisaiFinDisplayServiceBean) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                // headerのtransitToの値によって事前処理分岐
                if (transitTo === 'vp.member.pages.info10') {
                    this._prepareInfo10(content);
                }
            }
        },

        /**
         * 内訳画面の事前処理.<br>
         * info6, info7.<br>
         */
        prepareDetail: function(res){
            if (res && res.body && res.body.content) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                if (res.body.content.WebMeisaiDetailDisplayServiceBean) {
                    // headerのtransitToの値によって事前処理分岐
                    if (transitTo === 'vp.member.pages.info6') {
                        this._prepareInfo6(content);
                    } else if (transitTo === 'vp.member.pages.info7'){
                        this._prepareInfo7(content);
                    }
                } else if (res.body.content.CustomizedMeisaiAnsDisplayServiceBean) {
                    if (transitTo === 'vp.member.pages.info13') {
                        this._prepareInfo13(content);
                    }
                }
            }
        },

        /**
         * 内訳(印刷)画面の事前処理.<br>
         * info11, info12.<br>
         */
        prepareDetailPrint: function(res){
            if (res && res.body && res.body.content && res.body.content.WebMeisaiDetailDisplayServiceBean) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                // headerのtransitToの値によって事前処理分岐
                if (transitTo === 'vp.member.pages.info11') {
                    this._prepareInfo11(content);
                } else if (transitTo === 'vp.member.pages.info12'){
                    this._prepareInfo12(content);
                }
            }
        },
        
        /**
         * U050利用明細画面の事前処理.<br>
         * info13.<br>
         */
        prepareMeisai: function(res){
            if (res && res.body && res.body.content && res.body.content.CustomizedMeisaiAnsDisplayServiceBean) {
                var transitTo = res.header.transitTo;
                var content = res.body.content;
                // headerのtransitToの値によって事前処理分岐
                if (transitTo === 'vp.member.pages.info13') {
                    this._prepareInfo13(content);
                }
            }
        },


        //**********************//
        //***以降、ページ毎のメソッド***//
        //**********************//

        // ========================================== TOP系 ========================================== //

        /**
         * info2 : TOP(封書)の事前処理
         */
        _prepareInfo2: function(content){
            var bean = content.WebMeisaiTopDisplayServiceBean;
            var vo = bean.webMeisaiTopK3Vo;

            // 口座残高サービスURLの生成
            var referUrl = content.HpSvrRoot.value + content.TkAccountExplanation.value + bean.bridgePagePrm;
            bean._referUrl = referUrl;

            // サーバーから取得したbeanを加工
            if (!bean.webMeisaiTopK3Vo.accountOvly || !bean.webMeisaiTopK3Vo.accountOvly.match(/A00[1-4]/)) {
                // A001～A004に該当しない場合はA000とする
                bean.webMeisaiTopK3Vo.accountOvly = 'A000';
            }

            // A000, A001の場合は残高表示サービスについてオンライン口座照会表示用フラグを追加
            if (bean.webMeisaiTopK3Vo.accountOvly.match(/A00[01]/)) {
                bean._isAccountOvly01 = true;
                
                var olLinkIndicateFl = bean.olLinkIndicateFl;
                var menteDetailFlg = bean.menteDetailFlg;
                
                if (olLinkIndicateFl === '1') {
                    // 決済金融機関残高照会ページへのリンクあり
                    bean.webMeisaiTopK3Vo.olShowFlag = '1';
                } else if (olLinkIndicateFl === '2' && menteDetailFlg === '1') {
                    // メンテナンスページへのリンクあり メンテナンスGIFあり、リンクありのケース（リンク付きメッセージ）
                    bean.webMeisaiTopK3Vo.olShowFlag = '2';
                } else if (olLinkIndicateFl === '2' && menteDetailFlg === '2') {
                    // メンテナンスページへのリンクあり メンテナンスGIFのみのケース（メッセージのみ）
                    bean.webMeisaiTopK3Vo.olShowFlag = '3';
                } else {
                    // 残高照会ページリンクなし メンテナンスページリンクなし
                    bean.webMeisaiTopK3Vo.olShowFlag = '4';
                }
            }
            // A001, A003, A004の場合のみ口座情報注釈文言を表示するためのフラグを追加
            bean._isAccountOvly134 = !!bean.webMeisaiTopK3Vo.accountOvly.match(/A00[134]/);
            
            bean._isAccountOvly34 = !!bean.webMeisaiTopK3Vo.accountOvly.match(/A00[34]/);
            
            // attentionMsgを'（＃印'で始まる場合のみ表示するためのフラグ
            bean._isAttentionMsgStartsWithHash =
            bean.webMeisaiTopK3Vo.attentionMsg && (bean.webMeisaiTopK3Vo.attentionMsg.indexOf('（＃印') === 0);

            //照会/会員番号欄オーバレイのフラグを追加
            var memberOvly = bean.webMeisaiTopK3Vo.memberOvly;
            if (memberOvly === 'M001' || memberOvly === 'M002') {
                // オーバーレイコード:001=カード枚数１枚、002=カード枚数２枚
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '1';
            } else if (memberOvly === 'M003' || memberOvly === 'M004') {
                //貸金対応 加入日、切替日表示パターン
                //オーバーレイコード:003=カード枚数１枚、 004=カード枚数２枚
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '2';
            } else if (memberOvly === 'M101') {
                //東急対応用
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '3';
            } else if (memberOvly === 'M103') {
                //東急対応用
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '4';
                // ▽custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 ▽
            } else if (memberOvly === 'M008' || memberOvly === 'M009') {
                //SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件
                //オーバーレイコード:008=通常会員、009=VM統合
                bean.webMeisaiTopK3Vo.memberOvlyFlg = "5";
                // △custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 △
                // ▽ SC00463：（210422）【営業秘密】Vpass情報マスキング強化対応(PH1．0) ▽
            } else if (memberOvly === 'M201') {
                //オーバーレイコード:M201(代替番号1段表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '6';
            } else if (memberOvly === 'M202') {
                //オーバーレイコード:M202(代替番号2段表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '7';
            } else if (memberOvly === 'M203') {
                //オーバーレイコード:M203(代替番号1段、加入・切替日表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '8';
            } else if (memberOvly === 'M204') {
                //オーバーレイコード:M204(代替番号2段、加入・切替日2段表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '9';
                // △ SC00463：（210422）【営業秘密】Vpass情報マスキング強化対応(PH1．0) △
            } else {
                // オーバーレイコード:その他　2004年06月請求以前の表を表示
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '0';
            }
            
            //moneyと勘定奉行有無のフラグを追加
            var rowType45Umu = bean.webMeisaiTopK3Vo.rowType45Umu;
            var firstRow = bean.webMeisaiTopK3Vo.firstRow;
            if (firstRow === '1' && rowType45Umu === false ) {
                bean.webMeisaiTopK3Vo.moneyFlg = '1';
            } else {
                bean.webMeisaiTopK3Vo.moneyFlg = '2';
            }
            
            //#info2パフォーマンス対応
            
            //_isAccountOvly134とwebMeisaiTopK3Vo.acctMsgSizeの等号、greaterThanチェックを1つに統合するためのパラメータ設定
            if(bean._isAccountOvly134 == true && vo.acctMsgSize > 0){
                    vo._ovly134AcctMsgDspFlg = true;
                }
            
            //webMeisaiTopK3Vo.accountOvlyとwebMeisaiTopK3Vo.mpDispFlagの不等号、等号チェックを1つに統合するためのパラメータ設定
            if(vo.accountOvly != 'A000' && vo.mpDispFlag == '1'){
                    vo._mpDspFlg = true;
                }
 
            //webMeisaiTopK3Vo.furikomiUserとwebMeisaiTopK3Vo.nextFurikomiServiceFixedLengthの不等号、等号チェックを1つに統合するためのパラメータ設定
            if(bean.preEditFlag) {
                if(vo.furikomiUser != '1' && vo.nextFurikomiService == '1'){
                    vo._nextFurikomiServiceDspFlg = true;
                }
            } else {
                if(vo.furikomiUser != '1' && vo.nextFurikomiServiceFixedLength == '1'){
                    vo._nextFurikomiServiceDspFlg = true;
                }
            }

            // PR文言の出力情報を整形する。
            if (vo.finPrVoList) {
                array.forEach(vo.finPrVoList, function(entry1, i) {
                    var list = [];
                    var entry = entry1;
                    array.forEach(entry.finPrRowList, function(entry2, i) {
                        if (i < entry.finPrRowCntStart - 1 || entry.finPrRowCntEnd - 1 < i) {
                            return ;
                        }
                        var obj = {};
                        obj.value = entry2;
                        obj.bold = '';
                        // bold判定
                        if (entry.finPrRowCntStart == 1 && i == 0) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 2 && i == 1 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 1 && i == 2 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        list.push(obj);
                    });
                    entry1._finPrRowList = list;
                });
            }

            // 日付変換
            vo._joiningDay1 = this._getMillis(vo.joiningDay1);
            vo._joiningDay2 = this._getMillis(vo.joiningDay2);

            // prMsg対応
            bean._prMsg03 = this._toObjList(bean.prMsg03);
            bean._prMsg04 = this._toObjList(bean.prMsg04);
            bean._prMsg05 = this._toObjList(bean.prMsg05);
            bean._prMsg12 = this._toObjList(bean.prMsg12);
        },


        /**
         * info3 : TOP(はがき)の事前処理
         */
        _prepareInfo3: function(content){
            var bean = content.WebMeisaiTopDisplayServiceBean;
            var vo = bean.webMeisaiTopK3Vo;

            // 口座残高サービスURLの生成
            var referUrl = content.HpSvrRoot.value + content.TkAccountExplanation.value + bean.bridgePagePrm;
            bean._referUrl = referUrl;

            // 口座残高サービスの画像ファイル名(階層が他の値と別のため、うまくReplaceできない)
            bean._referImage = bean.linkHanteiVo.linkImg;

            // ** 情報オーバーレイの番号を修正。 ** //
            // A001～A004以外はA000にまるめる。
            if (!vo.accountOvly || !vo.accountOvly.match(/A00[1-4]/)) {
                vo.accountOvly = 'A000';
            }
            // A000, A001の場合は残高表示サービスについてオンライン口座照会表示用フラグを追加
            if (vo.accountOvly.match(/A00[01]/)) {
                bean._isAccountOvly01 = true;
                // olShowFlag の決定
                if (bean.olLinkIndicateFl === '1') {
                    // 決済金融機関残高照会ページへのリンクあり
                    vo.olShowFlag =  '1';
                } else if (bean.olLinkIndicateFl === '2' && bean.menteDetailFlg === '1') {
                    // メンテナンスページへのリンクあり メンテナンスGIFあり、リンクありのケース（リンク付きメッセージ）
                    vo.olShowFlag =  '2';
                } else if (bean.olLinkIndicateFl === '2' && bean.menteDetailFlg === '2') {
                    // メンテナンスページへのリンクあり メンテナンスGIFのみのケース（メッセージのみ）
                    vo.olShowFlag =  '3';
                } else {
                    // 残高照会ページリンクなし メンテナンスページリンクなし
                    vo.olShowFlag =  '4';
                }
            }
            // A001, A003, A004の場合のみ口座情報注釈文言を表示するためのフラグを追加
            bean._isAccountOvly134 = !!vo.accountOvly.match(/A00[134]/);
            
            bean._isAccountOvly34 = !!bean.webMeisaiTopK3Vo.accountOvly.match(/A00[34]/);
            
            // ** attentionMsgを'（＃印'で始まる場合のみ表示するためのフラグを設定 ** //
            bean._isAttentionMsgStartsWithHash = vo.attentionMsg && (vo.attentionMsg.indexOf('（＃印') === 0);

            // ** 照会/会員番号欄オーバレイのフラグを追加 ** //
            var memberOvly = vo.memberOvly;
            if (memberOvly === 'M001' || memberOvly === 'M002') {
                // オーバーレイコード:001=カード枚数１枚、002=カード枚数２枚
                vo.memberOvlyFlg = '1';
            } else if (memberOvly === 'M003' || memberOvly === 'M004') {
                // 貸金対応 加入日、切替日表示パターン
                // オーバーレイコード:003=カード枚数１枚、 004=カード枚数２枚
                vo.memberOvlyFlg = '2';
            } else if (memberOvly === 'M101') {
                // 東急対応用
                vo.memberOvlyFlg = '3';
            } else if (memberOvly === 'M103') {
                // 東急対応用
                vo.memberOvlyFlg = '4';
                // ▽custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 ▽
            } else if (memberOvly === 'M008' || memberOvly === 'M009') {
                //SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件
                //オーバーレイコード:008=通常会員、009=VM統合
                vo.memberOvlyFlg = '5';
                // △custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 △
            } else {
                // オーバーレイコード:その他　2004年06月請求以前の表を表示
                vo.memberOvlyFlg = '0';
            }

            //SC00463：（210422）【営業秘密】Vpass情報マスキング強化対応(PH1．0)
            //【概要】
            //会員番号の画面表示をハンドリングするための分岐処理。
            //※上記案件の本番対応前後により会員番号を画面表示するか判定するため
            //  対応前：画面表示なし(計算書サーバの保持データが会員番号等のため表示しない)
            //  対応後：画面表示あり(計算書サーバの保持データが代替番号等のため表示する)
            //
            //【判定方法】
            //計算書サーバから取得した会員番号(userAcctCheckData)のレイアウトを基に対応前後を判定する。
            //判定結果を"userAcctDispPattern"に設定(0:表示なし、1：表示あり)し、htmlの画面描画処理に使用する。
            //
            //①フル桁マスキング(****************) の場合
            //⇒対応後レイアウトのため画面表示あり(1：表示あり を設定)
            //
            //②フル桁マスキング 且つ 4桁ハイフン区切り(****-****-****-****) の場合
            //⇒対応前レイアウトのため画面表示なし(0：表示なし を設定)
            //
            //③下3桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：4980-1234-5678-9***、4980-12**-****-9***) の場合
            //⇒対応前レイアウトのため画面表示なし(0：表示なし を設定)
            //
            //④7～12桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：1234-56**-****-1234) の場合
            //⇒対応前レイアウトのため画面表示なし(0：表示なし を設定)
            //※対応前で計算書サーバにスクランブル番号が保持されていた場合等が該当
            //
            //⑤上記以外(例：1234567890123456) の場合
            //⇒対応後レイアウトのため画面表示あり(1：表示あり を設定)
            //※計算書サーバにの保持データが代替番号等の場合に該当

            var userAcctCheckData = vo.userAcct1;
            var fullMaskPattern = '****************';
            var pastFullMaskPattern = '****-****-****-****';
            var lastThreePattern = '***';
            var scramblePattern = /^\d{4}-\d{2}\*{2}-\*{4}-\d{4}$/;

            //①フル桁マスキング(****************) の場合
            if (userAcctCheckData === fullMaskPattern) {
                vo.userAcctDispFlag = '1';

            //②フル桁マスキング 且つ 4桁ハイフン区切り(****-****-****-****) の場合
            } else if (userAcctCheckData === pastFullMaskPattern) {
                vo.userAcctDispFlag = '0';

            //③下3桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：4980-1234-5678-9***、4980-12**-****-9***) の場合
            } else if ((userAcctCheckData.lastIndexOf(lastThreePattern) + lastThreePattern.length === userAcctCheckData.length)) {
                vo.userAcctDispFlag = '0';

            //④7～12桁アスタリスク(*)マスキング 且つ 4桁ハイフン区切り(例：1234-56**-****-1234) の場合
            } else if (scramblePattern.test(userAcctCheckData)) {
                vo.userAcctDispFlag = '0';

            //⑤上記以外(例：1234567890123456) の場合
            } else {
                vo.userAcctDispFlag = '1';
            }

            // ** 勘定奉行有無のフラグを追加 ** //
            var rowType45Umu = vo.rowType45Umu;
            var firstRow = vo.firstRow;
            if (firstRow === '1' && rowType45Umu === false ) {
                bean._kanjoFlg = '0'; // 勘定奉行DL不可
            } else {
                bean._kanjoFlg = '1'; // 勘定奉行DL可能
            }
            
            //#info3パフォーマンス対応
            
            //_isAccountOvly134とwebMeisaiTopK3Vo.acctMsgSizeの等号、greaterThanチェックを1つに統合するためのパラメータ設定
            if(bean._isAccountOvly134 == true && vo.acctMsgSize > 0){
                    vo._ovly134AcctMsgDspFlg = true;
                }
            
            //webMeisaiTopK3Vo.accountOvlyとwebMeisaiTopK3Vo.mpDispFlagの不等号、等号チェックを1つに統合するためのパラメータ設定
            if(vo.accountOvly != 'A000' && vo.mpDispFlag == '1'){
                    vo._mpDspFlg = true;
                }
            
            //webMeisaiTopK3Vo.callLimitMsgFlgとprMsg11DispFlagの等号チェックを1つに統合するためのパラメータ設定
            if(vo.callLimitMsgFlg == '1' && bean.prMsg11DispFlag == '1'){
                    vo._callLimitPrMsg11DspFlg = true;
                }
            
            //webMeisaiTopK3Vo.callLimitMsgFlgとprMsg12DispFlagの等号チェックを1つに統合するためのパラメータ設定
            if(vo.callLimitMsgFlg == '2' && bean.prMsg12DispFlag == '1'){
                    vo._callLimitPrMsg12DspFlg = true;
                }
            
            //webMeisaiTopK3Vo.furikomiUserとwebMeisaiTopK3Vo.nextFurikomiServiceの不等号、等号チェックを1つに統合するためのパラメータ設定
            if(vo.furikomiUser != '1' && vo.nextFurikomiService == '1'){
                    vo._nextFurikomiServiceDspFlg = true;
                }

            // PR文言の出力情報を整形する。
            if (vo.finPrVoList) {
                array.forEach(vo.finPrVoList, function(entry1, i) {
                    var list = [];
                    var entry = entry1;
                    array.forEach(entry.finPrRowList, function(entry2, i) {
                        if (i < entry.finPrRowCntStart - 1 || entry.finPrRowCntEnd - 1 < i) {
                            return ;
                        }
                        var obj = {};
                        obj.value = entry2;
                        obj.bold = '';
                        // bold判定
                        if (entry.finPrRowCntStart == 1 && i == 0) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 2 && i == 1 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        if (entry.finPrRowCntStart == 1 && i == 2 && entry.finPrPatid == 51 && vo.formKbn == 11) {
                            obj.bold = '1';
                        }
                        list.push(obj);
                    });
                    entry1._finPrRowList = list;
                });
            }
            
            // 日付変換
            vo._joiningDay1 = this._getMillis(vo.joiningDay1);
            vo._joiningDay2 = this._getMillis(vo.joiningDay2);

            // prMsg対応
            bean._prMsg03 = this._toObjList(bean.prMsg03);
            bean._prMsg04 = this._toObjList(bean.prMsg04);
            bean._prMsg05 = this._toObjList(bean.prMsg05);
            bean._prMsg11 = this._toObjList(bean.prMsg11);
            bean._prMsg12 = this._toObjList(bean.prMsg12);
        },


        /**
         * info4 : TOP(S法人)の事前処理
         */
        _prepareInfo4: function(content){
            var bean = content.WebMeisaiTopDisplayServiceBean;
            // 口座残高サービスURLの生成
            var referUrl = content.HpSvrRoot.value + content.TkAccountExplanation.value + bean.bridgePagePrm;
            bean._referUrl = referUrl;
            // 口座残高サービスの画像ファイル名(階層が他の値と別のため、うまくReplaceできない)
            bean._referImage = bean.linkHanteiVo.linkImg;
        },


        /**
         * info8 : TOP(封書/はがき・印刷)の事前処理
         */
        _prepareInfo8: function(content){
            var bean = content.WebMeisaiTopDisplayServiceBean;
            var vo = bean.webMeisaiTopK3Vo;
            this.formKbn = bean.webMeisaiTopK3Vo.formKbn;
            this.isPreEdit = bean.webMeisaiTopK3Vo.preEditFlag;
            
            // サーバーから取得したbeanを加工
            if (!bean.webMeisaiTopK3Vo.accountOvly ||
                    !bean.webMeisaiTopK3Vo.accountOvly.match(/A00[1-4]/)) {
                // A001～A004に該当しない場合はA000とする
                bean.webMeisaiTopK3Vo.accountOvly = 'A000';
            }
            // A001, A003, A004の場合のみ口座情報注釈文言を表示するためのフラグを追加
            bean._isAccountOvly134 = !!bean.webMeisaiTopK3Vo.accountOvly.match(/A00[134]/);

            bean._isAccountOvly34 = !!bean.webMeisaiTopK3Vo.accountOvly.match(/A00[34]/);
            //照会/会員番号欄オーバレイのフラグを追加
            var memberOvly = bean.webMeisaiTopK3Vo.memberOvly;
            if (memberOvly === 'M001' || memberOvly === 'M002') {
                // オーバーレイコード:001=カード枚数１枚、002=カード枚数２枚
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '1';
            } else if (memberOvly === 'M003' || memberOvly === 'M004') {
                //貸金対応 加入日、切替日表示パターン
                //オーバーレイコード:003=カード枚数１枚、 004=カード枚数２枚
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '2';
            } else if (memberOvly === 'M101') {
                //東急対応用
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '3';
            } else if (memberOvly === 'M103') {
                //東急対応用
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '4';
                // ▽custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 ▽
            } else if (memberOvly === 'M008' || memberOvly === 'M009') {
                //SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件
                //オーバーレイコード:008=通常会員、009=VM統合
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '5';
                // △custom 2014/03/17 K.Isobe 【SC05009：（130520）【営業秘密】iD-PP対応に伴うDCMX計算書改定の件】 △
                // ▽ SC00463：（210422）【営業秘密】Vpass情報マスキング強化対応(PH1．0) ▽
            } else if (memberOvly === 'M201') {
                //オーバーレイコード:M201(代替番号1段表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '6';
            } else if (memberOvly === 'M202') {
                //オーバーレイコード:M202(代替番号2段表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '7';
            } else if (memberOvly === 'M203') {
                //オーバーレイコード:M203(代替番号1段、加入・切替日表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '8';
            } else if (memberOvly === 'M204') {
                //オーバーレイコード:M204(代替番号2段、加入・切替日2段表示)
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '9';
                // △ SC00463：（210422）【営業秘密】Vpass情報マスキング強化対応(PH1．0) △
            } else {
                // オーバーレイコード:その他　2004年06月請求以前の表を表示
                bean.webMeisaiTopK3Vo.memberOvlyFlg = '0';
            }
            
            //#info8パフォーマンス対応
            
            //_isAccountOvly134とwebMeisaiTopK3Vo.acctMsgSizeの等号、greaterThanチェックを1つに統合するためのパラメータ設定
            if(bean._isAccountOvly134 == true && vo.acctMsgSize > 0){
                    vo._ovly134AcctMsgDspFlg = true;
                }
            
            // 日付変換
            vo._joiningDay1 = this._getMillis(vo.joiningDay1);
            vo._joiningDay2 = this._getMillis(vo.joiningDay2);

            // prMsg対応
            bean._prMsg03 = this._toObjList(bean.prMsg03);
            bean._prMsg04 = this._toObjList(bean.prMsg04);
            bean._prMsg05 = this._toObjList(bean.prMsg05);
            bean._prMsg12 = this._toObjList(bean.prMsg12);
        },

        // 事前処理なし
//        /**
//         * info9 : TOP(S法人・印刷)の事前処理
//         */
//        _prepareInfo9: function(content){
//            
//        },


        // ========================================== 金融商品系 ========================================== //

        // パフォーマンス対応により有効化
        /**
         * info5 : 金融商品の事前処理
         */
        _prepareInfo5: function(content){
            var bean = content.WebMeisaiFinDisplayServiceBean;
            //formIdDispFlagとcashRateの不等号、存在チェックを1つに統合するためのパラメータ設定
            if(bean.formIdDispFlag != '1' && this._present(bean.cashRate)){
                    bean._notCashRateDspFlg = true;
                }

            //formIdDispFlagとcashRateの等号、存在チェックを1つに統合するためのパラメータ設定
            if(bean.formIdDispFlag == '1' && this._present(bean.cashRate)){
                    bean._cashRateDspFlg = true;
                }
            
            //revoRepaymentDispFlagとrevoRepaymentDetailsDispFlagの等号、存在チェックを1つに統合するためのパラメータ設定
            if(bean.revoRepaymentDispFlag == '1' && bean.revoRepaymentDetailsDispFlag == '1' ){
                    bean._revoRepaymentDetailsDspFlg = true;
                }
            
            // 分割表データの日付変換を行う
            var divInstallmentInfoList=bean.divInstallmentInfoList;
            array.forEach(divInstallmentInfoList, function(info, i){
                var tmpDate = info.month;
                if (tmpDate == null || tmpDate.length < 6) {
                    info._month = " ";
                    return ;
                }
                var year = tmpDate.substring(0, 4);
                var tmpMonth = tmpDate.substring(4, 6);
                // 月の処理 01～09の場合は先頭の0を外す
                if(tmpMonth.charAt(0)==='0'){
                    tmpMonth = tmpMonth.charAt(1);
                }
                info._month = year + '/' + tmpMonth;
            });

            // prMsg対応
            bean._prMsg06 = this._toObjList(bean.prMsg06);
            bean._prMsg07 = this._toObjList2(bean.prMsg07);
            bean._prMsg08 = this._toObjList2(bean.prMsg08);
            bean._prMsg09 = this._toObjList2(bean.prMsg09);
            bean._prMsg10 = this._toObjList(bean.prMsg10);
            bean._prMsg14 = this._toObjList(bean.prMsg14);
            bean._prMsg16 = this._toObjList(bean.prMsg16);
            bean._prMsg17 = this._toObjList(bean.prMsg17);
        },
        
        /**
         * info10 : 金融商品（印刷）の事前処理
         */
        _prepareInfo10: function(content){
            var bean = content.WebMeisaiFinDisplayServiceBean;
            //formIdDispFlagとcashRateの不等号、存在チェックを1つに統合するためのパラメータ設定
            if(bean.formIdDispFlag != '1' && this._present(bean.cashRate)){
                    bean._notCashRateDspFlg = true;
                }

            //formIdDispFlagとcashRateの等号、存在チェックを1つに統合するためのパラメータ設定
            if(bean.formIdDispFlag == '1' && this._present(bean.cashRate)){
                    bean._cashRateDspFlg = true;
                }
            
            //revoRepaymentDispFlagとrevoRepaymentDetailsDispFlagの等号、存在チェックを1つに統合するためのパラメータ設定
            if(bean.revoRepaymentDispFlag == '1' && bean.revoRepaymentDetailsDispFlag == '1' ){
                bean._revoRepaymentDetailsDspFlg = true;
            }

            // 分割表データの日付変換を行う
            var divInstallmentInfoList=bean.divInstallmentInfoList;
            array.forEach(divInstallmentInfoList, function(info, i){
                var tmpDate = info.month;
                if (tmpDate == null || tmpDate.length < 6) {
                    info._month = " ";
                    return ;
                }
                var year = tmpDate.substring(0, 4);
                var tmpMonth = tmpDate.substring(4, 6);
                // 月の処理 01～09の場合は先頭の0を外す
                if(tmpMonth.charAt(0)==='0'){
                    tmpMonth = tmpMonth.charAt(1);
                }
                info._month = year + '/' + tmpMonth;
            });

            // prMsg対応
            bean._prMsg06 = this._toObjList(bean.prMsg06);
            bean._prMsg07 = this._toObjList2(bean.prMsg07);
            bean._prMsg08 = this._toObjList2(bean.prMsg08);
            bean._prMsg09 = this._toObjList2(bean.prMsg09);
            bean._prMsg10 = this._toObjList(bean.prMsg10);
            bean._prMsg14 = this._toObjList(bean.prMsg14);
            bean._prMsg16 = this._toObjList(bean.prMsg16);
            bean._prMsg17 = this._toObjList(bean.prMsg17);
        },

        // ========================================== 内訳系 ========================================== //

        /**
         * info6 : 内訳の事前処理
         */
        _prepareInfo6: function(content){
            var bean = content.WebMeisaiDetailDisplayServiceBean;
            var beanCardAssortment = content.CardAssortmentDisplayServiceBean;
            // タイトル行の表示有無フラグを設定する
            var newOldView = content.NewOldView.value;
            // 新テーブルの場合に行う
            if (newOldView === 'true') {
                var cardAssortmentList = content.CardAssortmentDisplayServiceBean.cardAssortmentList;
                var oldTitleCode = "";
                array.forEach(cardAssortmentList, function(entry, i){
                    var cardAssortmentInfo = cardAssortmentList[i];
                    array.forEach(cardAssortmentInfo, function(entry2, j){
                        if (oldTitleCode !== cardAssortmentInfo[j].titleCode) {
                            cardAssortmentInfo[j]._titleCodeFlag = true;
                        } else {
                            cardAssortmentInfo[j]._titleCodeFlag = false;
                        }
                        oldTitleCode = cardAssortmentInfo[j].titleCode;
                    });
                });
            }
            // 利用枠に表示する列数をカウントする
            var limitKindCnt = 0;
            if(bean.limitKind !== undefined 
                && bean.limitKind !== null
                && bean.limitKind !== '' ) {
                limitKindCnt = bean.limitKind.length - 1;
            }
            
            bean._limitKindCnt = limitKindCnt;

            
            // オーバレイ情報03（利用枠欄）の編集
            if (bean.limitOvly.match(/G00[1-3]/)) {
                // G001～G003に該当する場合はG00とする
                bean.limitOvly = 'G00';
            } else if (bean.limitOvly.match(/G10[1-3]/)) {
                // G101～G103に該当する場合はG10とする
                bean.limitOvly = 'G10';
            } else if (bean.limitOvly.match(/G20[1-3]/)) {
                // G201～G203に該当する場合はG20とする
                bean.limitOvly = 'G20';
            } else if (bean.limitOvly.match(/G30[1-3]/)) {
                // G301～G303に該当する場合はG30とする
                bean.limitOvly = 'G30';
            } else if (bean.limitOvly == "OTHER") {
                // 上記に該当しない場合、連携なし
                if (bean.formId === "G66" || bean.formId === "CU1") {
                    bean._limitOvlyOtherFlg = "before";
                } else {
                    bean._limitOvlyOtherFlg = "after";
                }
            }
            
            // オーバレイ情報15（ポイント告知欄）の編集
            if (bean.pointOvly === "P008" || bean.pointOvly === "P018") {
                // P008、P018に該当する場合はP008_P018とする
                bean.pointOvly = 'P008_P018';
            } else if (bean.pointOvly === "P811" || bean.pointOvly === "P911") {
                // P811、P911に該当する場合はP811_P911とする
                bean.pointOvly = 'P811_P911';
            } else if (bean.pointOvly === "P814" || bean.pointOvly === "P914") {
                // P814、P911に該当する場合はP814_P914とする
                bean.pointOvly = 'P814_P914';
            } else if (bean.pointOvly === 'P019' || bean.pointOvly === 'PCARD2') {
                // ドコモポイントに関係するオーバーレイコード P019、PCARD2の場合は、告知欄が異なるため、pointFrameDispFlag に '2' を設定する
                bean.pointFrameDispFlag = '2';
            }
                
            // ポイント注意文言の表示制御編集
            if (bean.pointCautionWord && bean.pointCautionWord.length !== 0 && bean.formKbn === "1") {
                bean._pointCautionWordFlg = true;
            } else {
                bean._pointCautionWordFlg = false;
            }
            
            // 失効文言の表示制御編集
           if (this._present(bean.pointReserveWord) && this._equal(bean.formKbn, '1')) {
                if (this._equal(bean.pointReserveWordFlg, '1')) {
                    bean._pointReserveWordDspFlg = "1";
                } else {
                    bean._pointReserveWordDspFlg = "2";
                }
            } else {
                bean._pointReserveWordDspFlg = "0";
            }
            
            // 全面改定対応前 ロイヤリティメッセージフラグ編集
            if (bean.royaltyClassOvly.match(/C00[1-3]/)) {
                bean._royaltyClassOvlyFlg = bean.royaltyClassOvly;
            } else {
                bean._royaltyClassOvlyFlg = "OTHER";
            }
            
            // limitKindのキーバリュー化
            var limitKind = content.WebMeisaiDetailDisplayServiceBean.limitKind;
            var _limitKind = [];
            array.forEach(limitKind, function(entry, i){
                var obj = {};
                obj['value'] = limitKind[i];
                _limitKind[i] = obj;
            });
            bean._limitKind = _limitKind;

            // prMsg対応
            bean._prMsg01 = this._toObjList(bean.prMsg01);
            bean._prMsg02 = this._toObjList(bean.prMsg02);
            bean._prMsg13 = this._toObjList(bean.prMsg13);

            //#info6パフォーマンス対応
            
            // 新テーブルの場合に行う
            if (newOldView === 'true') {
                //cardAssortmentCountのLogicが2回繰り返されていたものを1つに統一するためのパラメータ設定
                if (this._present(beanCardAssortment.cardAssortmentCount) &&
                        beanCardAssortment.cardAssortmentCount != '0') {
                        beanCardAssortment._cardAssortmentDspFlg = true;
                }
            }
            //formIdDispFlagとpointOvlyの存在チェックを1つに統合するためのパラメータ設定
            if (this._present(bean.formIdDispFlag) && this._present(bean.pointOvly)) {
                bean._pointOvlyDspFlg = true;
            }
            
            //formKbnとroyaltyClassOvlyの不等号、等号チェックを1つに統合するためのパラメータ設定
            if (bean.formKbn != '1' && bean.royaltyClassOvly == 'PCARD') {
                bean._royaltyClassOvlyDspFlg = true;
            }
            
            //_royaltyClassOvlyFlgとroyaltyWordの等号、存在チェックを1つに統合するためのパラメータ設定
            if (bean._royaltyClassOvlyFlg == 'OTHER' && this._present(bean.royaltyWord)) {
                bean._royaltyClassOvlyOtherDspFlg = true;
            }
            
            //formIdDispFlagとpremiumStageWordの等号、存在チェックを1つに統合するためのパラメータ設定
            if (bean.formIdDispFlag == '1' && this._present(bean.premiumStageWord)) {
                bean._premiumStageWordDspFlg = true;
            }
    
            //formIdDispFlagとthanksPointOvlyの等号、存在チェックを1つに統合するためのパラメータ設定
            if (bean.formIdDispFlag == '1' && this._present(bean.thanksPointOvly)) {
                bean._thanksPointOvlyDspFlg = true;
               }
            
            // premiumStageWordのキーバリュー化
            var premiumStageWord = content.WebMeisaiDetailDisplayServiceBean.premiumStageWord;
            var _premiumStageWord = [];
            array.forEach(premiumStageWord, function(entry, i){
                var obj = {};
                obj['PremiumStage'] = premiumStageWord[i];
                _premiumStageWord[i] = obj;
            });
            bean._premiumStageWord = _premiumStageWord;
        },

        /**
         * info7 : 内訳(S法人)の事前処理
         */
        _prepareInfo7: function(content){
            var bean = content.WebMeisaiDetailDisplayServiceBean;
            
            // カードご利用枠(カード限度額)の2件目表示制御
            var limitWord = content.WebMeisaiDetailDisplayServiceBean.limitWord;
            var limitValue = content.WebMeisaiDetailDisplayServiceBean.limitValue;
            
            // 2つ目の限度額文言、限度額の両方が存在しない場合、表示を行わない
            if (limitWord.length > 1 && limitValue.length > 1 && '' != limitWord[1] && '' != limitValue[1]) {
                bean._limitDispFlg = true;
            } else {
                bean._limitDispFlg = false;
            }
        },


        /**
         * info11 : 内訳(印刷)の事前処理
         */
        _prepareInfo11: function(content){
            var bean = content.WebMeisaiDetailDisplayServiceBean;
            // 利用枠に表示する列数をカウントする
            var limitKindCnt = 0;
            if(bean.limitKind !== undefined 
                && bean.limitKind !== null
                && bean.limitKind !== '' ) {
                limitKindCnt = bean.limitKind.length - 1;
            }
            
            bean.limitKindCnt = limitKindCnt;
            
            // オーバレイ情報03（利用枠欄）の編集
            if (bean.limitOvly.match(/G00[1-3]/)) {
                // G001～G003に該当する場合はG00とする
                bean.limitOvly = 'G00';
            } else if (bean.limitOvly.match(/G10[1-3]/)) {
                // G101～G103に該当する場合はG10とする
                bean.limitOvly = 'G10';
            } else if (bean.limitOvly.match(/G20[1-3]/)) {
                // G201～G203に該当する場合はG20とする
                bean.limitOvly = 'G20';
            } else if (bean.limitOvly.match(/G30[1-3]/)) {
                // G301～G303に該当する場合はG30とする
                bean.limitOvly = 'G30';
            }

            // オーバレイ情報15（ポイント告知欄）の編集
            if (bean.pointOvly === "P008" || bean.pointOvly === "P018") {
                // P008、P018に該当する場合はP008_P018とする
                bean.pointOvly = 'P008_P018';
            } else if (bean.pointOvly === "P811" || bean.pointOvly === "P911") {
                // P811、P911に該当する場合はP811_P911とする
                bean.pointOvly = 'P811_P911';
            } else if (bean.pointOvly === "P814" || bean.pointOvly === "P914") {
                // P814、P911に該当する場合はP814_P914とする
                bean.pointOvly = 'P814_P914';
            }

            // limitKindのキーバリュー化
            var limitKind = content.WebMeisaiDetailDisplayServiceBean.limitKind;
            var _limitKind = [];
            array.forEach(limitKind, function(entry, i){
                var obj = {};
                obj['value'] = limitKind[i];
                _limitKind[i] = obj;
            });
            bean._limitKind = _limitKind;

            // prMsg対応
            bean._prMsg02 = this._toObjList(bean.prMsg02);
            bean._prMsg13 = this._toObjList(bean.prMsg13);

            // ポイント注意文言の表示制御編集
            if (bean.pointCautionWord && bean.pointCautionWord.length !== 0 && bean.formKbn === "1") {
                bean.pointCautionWordFlg = true;
            } else {
                bean.pointCautionWordFlg = false;
            }
            
            // 失効文言の表示制御編集
            if (this._present(bean.pointReserveWord) && this._equal(bean.formKbn, '1')) {
                if (this._equal(bean.pointReserveWordFlg, '1')) {
                    bean.pointReserveWordDspFlg = "1";
                } else {
                    bean.pointReserveWordDspFlg = "2";
                }
            } else {
                bean.pointReserveWordDspFlg = "0";
            } 

            // premiumStageWordのキーバリュー化
            var premiumStageWord = content.WebMeisaiDetailDisplayServiceBean.premiumStageWord;
            var _premiumStageWord = [];
            array.forEach(premiumStageWord, function(entry, i){
                var obj = {};
                obj['value'] = premiumStageWord[i];
                _premiumStageWord[i] = obj;
            });
            bean._premiumStageWord = _premiumStageWord;
            
            // 全面改定対応前 ロイヤリティメッセージフラグ編集
            if (bean.royaltyClassOvly.match(/C00[1-3]/)) {
                bean.royaltyClassOvlyFlg = bean.royaltyClassOvly;
            } else {
                bean.royaltyClassOvlyFlg = "OTHER";
            }
            
            //#info11パフォーマンス対応
            
            //formIdDispFlagとpointOvlyの存在チェックを1つに統合するためのパラメータ設定
            if (this._present(bean.formIdDispFlag) && this._present(bean.pointOvly)){
                       bean._pointOvlyDspFlg = true;
            }
            
            //formKbnとroyaltyClassOvlyの不等号、等号チェックを1つに統合するためのパラメータ設定
            if (bean.formKbn != '1' && bean.royaltyClassOvly == 'PCARD'){
                    bean._royaltyClassOvlyDspFlg = true;
            }            
        },

        /**
         * info12 : 内訳(S法人・印刷)の事前処理
         */
        _prepareInfo12: function(content){
            var bean = content.WebMeisaiDetailDisplayServiceBean;
            
            // カードご利用枠(カード限度額)の2件目表示制御
            var limitWord = content.WebMeisaiDetailDisplayServiceBean.limitWord;
            var limitValue = content.WebMeisaiDetailDisplayServiceBean.limitValue;
            
            // 2つ目の限度額文言、限度額の両方が存在しない場合、表示を行わない
            if (limitWord.length > 1 && limitValue.length > 1 && '' != limitWord[1] && '' != limitValue[1]) {
                bean._limitDispFlg = true;
            } else {
                bean._limitDispFlg = false;
            }
        },

        /**
         * info13 : 利用明細の事前処理
         */
        _prepareInfo13: function(content) {
            var bean = content.CustomizedMeisaiAnsDisplayServiceBean;
            StoreManager.putUserData('info13bean', bean);

            if (bean.meisaiList && bean.meisaiList.length !== 0 && bean.userKbn === '0') {
                if (bean.ktmktKbn === '1' || bean.ktmktKbn === '2') {
                    bean.tempFlg = '012';
                }
            }
            if (bean.csvMoneyFlag === '1' && bean.kanjyoFlag) {
                bean.tempKanjyoFlg = '11';
            } else {
                bean.tempKanjyoFlg = '';
            }
        },

		/**
		 * 配列を結合します。
		 */
		_toObjList: function(ary) {
            var _ary = [];
            var str2 = "";
            array.forEach(ary, function(entry, i) {
           		str2 = str2 + ' ' + ary[i];
            });
            _ary[0] = {
            		value : str2
            };
            return _ary;
		},
		/**
		 * 配列を結合します。1つ目の配列値のみ別に格納します。
		 */
		_toObjList2: function(ary) {
            var _ary = [];
            var str1 = "";
            var str2 = "";
            array.forEach(ary, function(entry, i) {
            	if (i == 0) {
            		str1 = ary[i];
            	} else {
            		str2 = str2 + ' ' + ary[i];
            	}
            });
            _ary[0] = {
            		value : str1
            };
            _ary[1] = {
            		value : str2
            };
            return _ary;
		},

        /**
         * yyyyMMddから秒数を取得します
         */
        _getMillis: function(dateString) {
            if (null == dateString || dateString.length != 8) {
                return dateString;
            }
            return new Date(dateString.substring(0, 4), dateString.substring(4, 6) - 1, dateString.substring(6), 12, 0, 0, 0).getTime();
        },

        _present: function(value){
            return value !== null && value !== undefined && value !== '' && (!lang.isArray(value) || value.length !== 0);
        },
        /**
         * 2つの値を受け取り、==で比較した結果が真、かつ値の組み合わせが空文字と0でない場合はtrue、
         * それ以外の場合はfalseを返す。
         * @param {number|string} a 比較対象とする値
         * @param {number|string} b 比較対象とする値
         * @returns {boolean} 受け取った値がこの関数の条件を満たせばtrue、それ以外の場合はfalse
         * @private
         */
        _equal: function(a, b) {
            /* jshint eqeqeq: false */
            // JSでは '' と 0 の == はtrueとなってしまうため、同組み合わせのみ特別扱いでfalseとする
            return a == b && !(a === '' && b === 0 || a === 0 && b === '');
        }
    }
});