define(function() {
return {
SEND_FLAG_KEY: 'vp-view-CONFIRM_MAIL_RS0001_confirm_mail_send',
SEND_FLAG_OK: '1',
};
});
