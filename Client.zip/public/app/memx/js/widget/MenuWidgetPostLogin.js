define([
'dojo/_base/declare', 
'dojo/dom', 
'./HMFWidgetUtil',
'dojo/text!./MenuWidgetPostLogin.html', 
'vps/member/WebApiConst',
'vps/member/VerisignSeal',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/control/StoreManager',
'vp/alcor/pages/MenuWidget', 
'vp/alcor/view/ExtLink'
], function(declare, dom, HMFWidgetUtil, template, WebApiConst,
VerisignSeal, AlcorConstants, StoreManager, MenuWidget, ExtLink) {

return declare('vps.member.MenuWidgetPostLogin', [MenuWidget],  {
templateString: template,

onStartup: function() {
this.inherited(arguments);


}
});
});
