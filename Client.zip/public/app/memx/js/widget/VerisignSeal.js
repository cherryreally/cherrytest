define([
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom-construct',
'dijit/_WidgetBase',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/control/StoreManager'
], function(declare, lang, domConst, _WidgetBase, AlcorConstants, StoreManager) {
return declare('vps.member.VerisignSeal', [_WidgetBase],
 {
targetProperty: 'vpass.member.user.appHpSvrDomain',

iframePath: '/app/memx/js/widget/VerisignSealFrame.html',

startup: function() {
StoreManager.keyStorePromise.then(lang.hitch(this, this._onKeyStorePrepared));
},

_onKeyStorePrepared: function(keyStore) {
var sysprops = keyStore.get(AlcorConstants.SYS_PROP_KEY);
if (!sysprops) {
console.error('property keys not found');
return;
}
var hostName = sysprops[this.targetProperty];
if (!hostName) {
console.error('verisign setting not found');
return;
}
this._createIframe(this.iframePath + '?hostName=' + hostName);
},

_createIframe: function(src) {
domConst.create('iframe', {
src: src,
frameBorder: '0'
}, this.domNode);
}
});
});
