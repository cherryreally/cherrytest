define([
'dojo/_base/declare', 
'dojo/dom',
'dojo/dom-prop',
'dojo/dom-style',
'dojo/text!./DropdownList.html', 
'dijit/registry',
'vp/alcor/pages/_AbstractPage', 
'vp/alcor/control/TransitionManager',
'vps/member/WebApiConst', 
'vp/alcor/control/StoreManager'
], function(declare,dom, domProp, domStyle, template, registry, _AbstractPage,TransitionManager,
WebApiConst, StoreManager) {
var res; 
return declare('vps.member.DropdownList', [_AbstractPage],{
templateString: template,
preventScreenDataCache: true,
constructor: function() {
StoreManager.removeScreenData(this.initTransitOptions.webApiId);
},

onBeforeScreenDataStored: function(content) {
return this._destroyed ? {} : content;
},

initTransitOptions: {
webApiId: WebApiConst.API.VC0205001_RS0050,
postData:{"displayDropdownList":"enable"},
success: function(_res){
res = _res;
}
},

onStartup: function(){
if (res.header.loginFlg) {
if(res && res.body && res.body.content &&
res.body.content.DropdownListInitDisplayServiceBean){
var displayBean = res.body.content.DropdownListInitDisplayServiceBean;
if (displayBean.cardImageFileName !== '') {
var cardImgId = dom.byId('DropdownListCardImage');
if (typeof cardImgId !== 'undefined') {
cardImgId.src = '/common/dynamic/memx/img/' + displayBean.cardImageFileName;
}
}
var target = registry.byId('vp-view-VC0205-001_RS0051_cardIdentifyKey');
if (typeof target !== 'undefined' && displayBean.displayPattern === '1') {
this.onNode(target, 'change', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0205001_RS0051,
formId: 'FRM_c_C302001-0001',
success: function(){
location.reload();
}
});
});
}
}
} else {
if (dom.byId('DropdownListDisplayArea')){
domStyle.set(dom.byId('DropdownListDisplayArea'), "display", "none");
}
}
}
});
});
