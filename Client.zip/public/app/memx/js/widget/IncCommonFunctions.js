define([
'dojo/_base/declare', 
'vp/alcor/pages/_AbstractPage', 
'vps/member/IncWebAnalyticsRA',
'vps/member/IncWebAnalyticsGA'
], function(declare,  _AbstractPage) {
return declare('vps.member.widget.IncCommonFunctions', [_AbstractPage],  {
});
});
