define([
'dojo/_base/declare', 
'dojo/dom-prop',
'dojo/text!./ConfirmMailPanel.html', 
'vp/alcor/pages/_AbstractPage', 
'vpx/view/ActionPreparatorBr',
'vps/member/WebApiConst', 
'./ConfirmMailConst' 
], function(declare, domProp, template, _AbstractPage, ActionPreparator, WebApiConst, ConfirmMailConst) {
return declare('vp.member.widget.ConfirmMailPanel', [_AbstractPage],  {
templateString: template,

onStartup: function() {
ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareInputActions();
},
onBuildRendered: function() {
domProp.set(this.sendFlagOk, 'name', ConfirmMailConst.SEND_FLAG_KEY);
domProp.set(this.sendFlagOk, 'value', ConfirmMailConst.SEND_FLAG_OK);
}
});
});
