//>>built
define("dijit/form/nls/zh/ComboBox",{previousMessage:"\u5148\u524d\u9009\u9879",nextMessage:"\u66f4\u591a\u9009\u9879"});