define(function() {
return {
REGEXP_ID_CHAR: '^[a-zA-Z0-9_\\-]*$',
REGEXP_ID_REJECT_ONLY_NUM: '^(?![0-9]+$).*$',
REGEXP_ID_REJECT_PATTERN: '^(?!(.)\\1*$).*$',
REGEXP_INNER_LINE: '^[a-zA-Z0-9#\\-\\*]*$',
REGEXP_CARD_CODE: '^[A-Z0-9]*$',
REGEXP_EXPIRATION_MONTH_CHAR: '^[0-9]*$',
REGEXP_EXPIRATION_MONTH_RANGE: '^(0[1-9]|1[0-2])?$',
REGEXP_PHONE_REJECT_AREA_CODE: '^(?!070$|080$|090$)[0-9]*$',
REGEXP_MOBILE_PHONE_AREA_CODE: '^(070|080|090)?$',
REGEXP_ADDRESS_NAME_CHAR: '^[ｧ-ﾝ]*$',
REGEXP_ADDRESS_NAME_REJECT_CHAR: '^(?!.*,|.*\'|.*").*$',
REGEXP_EMAIL_EXCEPT_AT_SYMBOL: '^[0-9a-zA-Z/_\\-\\.]*$',
REGEXP_EXCEPT_DOUBLE_QUOTATION: '^[^"]*$',
REGEXP_KATAKANA_AND_ALPHABETICAL: '^[ァ-ヶa-zA-Z]*$',
REGEXP_KATAKANA_AND_ALPHANUMERICAL_AND_KIGOU:'^[0-9a-zA-Z\\.\\-_\\/@<>!#$%+:~=&?*,]+$',
REGEXP_NUMBER_HYPHEN: '^[0-9\\-]*$',
REGEXP_ZENGAKU_SPACE: '^[^ｱ-ﾝｳﾞｶﾞｷﾞｸﾞｹﾞｺﾞｻﾞｼﾞｽﾞｾﾞｿﾞﾀﾞﾁﾞﾂﾞﾃﾞﾄﾞﾊﾞﾋﾞﾌﾞﾍﾞﾎﾞﾊﾟﾋﾟﾌﾟﾍﾟﾎﾟｧｨｩｪｫｯｬｭｮa-zA-Z0-9-+･()=_/?!#$%&*@.,]*$',

};
});
