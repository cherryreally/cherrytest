document.addEventListener('DOMContentLoaded', () => {
  // 获取电话输入框和错误提示元素
  const phone1Input = document.getElementById('vp-view-VC0301001_RS0011_phone1');
  const phone2Input = document.getElementById('vp-view-VC0301001_RS0011_phone2');
  const phone3Input = document.getElementById('vp-view-VC0301001_RS0011_phone3');

  const phone1ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0301001_RS0011_phone1');
  const phone2ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0301001_RS0011_phone2');
  const phone3ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0301001_RS0011_phone3');

  // 监听输入框的 blur 事件
  phone1Input.addEventListener('blur', () => {
    if (!phone1Input.value.trim()) {
      phone1ErrorMessage.style.display = 'block';
      phone1Input.style.backgroundColor = '#ffdcd0';
    } else {
      phone1ErrorMessage.style.display = 'none';
      phone1Input.style.backgroundColor = '';
    }
  });

  phone2Input.addEventListener('blur', () => {
    if (!phone2Input.value.trim()) {
      phone2ErrorMessage.style.display = 'block';
      phone2Input.style.backgroundColor = '#ffdcd0';
    } else {
      phone2ErrorMessage.style.display = 'none';
      phone2Input.style.backgroundColor = '';
    }
  });

  phone3Input.addEventListener('blur', () => {
    if (!phone3Input.value.trim()) {
      phone3ErrorMessage.style.display = 'block';
      phone3Input.style.backgroundColor = '#ffdcd0';
    } else {
      phone3ErrorMessage.style.display = 'none';
      phone3Input.style.backgroundColor = '';
    }
  });
});
