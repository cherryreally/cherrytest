// 获取邮箱输入框和错误提示元素
const emailInput = document.querySelector('input[email-id="1"]');
const emailErrorMessage = document.getElementById('email_1');

// 监听输入框的 blur 事件
emailInput.addEventListener('blur', () => {
  if (!emailInput.value.trim()) {
    emailErrorMessage.style.display = 'block';
    emailInput.style.backgroundColor = '#ffdcd0';
  } else {
    emailErrorMessage.style.display = 'none';
    emailInput.style.backgroundColor = '';
  }
});


// 获取卡名输入框和错误提示元素
const cardnameInput = document.querySelector('input[data-action-preparator-cardname="1"]');
const cardnameErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_cardname');

// 监听输入框的 blur 事件
cardnameInput.addEventListener('blur', () => {
  if (!cardnameInput.value.trim()) {
    cardnameErrorMessage.style.display = 'block';
    cardnameInput.style.backgroundColor = '#ffdcd0';
  } else {
    cardnameErrorMessage.style.display = 'none';
    cardnameInput.style.backgroundColor = '';
  }
});


const yearInput = document.getElementById('vp-view-VC0201-001_RS0010_birth_year');
const yearErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_birth_year');
const monInput = document.getElementById('vp-view-VC0201-001_RS0010_birth_mon');
const monErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_birth_mon');
const dayInput = document.getElementById('vp-view-VC0201-001_RS0010_birth_day');
const dayErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_birth_day');

yearInput.addEventListener('blur', () => {
  if (!yearInput.value.trim()) {
    yearErrorMessage.style.display = 'block';
    yearInput.style.backgroundColor = '#ffdcd0';
  } else {
    yearErrorMessage.style.display = 'none';
    yearInput.style.backgroundColor = '';
  }
});

monInput.addEventListener('blur', () => {
  if (!monInput.value.trim()) {
    monErrorMessage.style.display = 'block';
    monInput.style.backgroundColor = '#ffdcd0';
  } else {
    monErrorMessage.style.display = 'none';
    monInput.style.backgroundColor = '';
  }
});

dayInput.addEventListener('blur', () => {
  if (!dayInput.value.trim()) {
    dayErrorMessage.style.display = 'block';
    dayInput.style.backgroundColor = '#ffdcd0';
  } else {
    dayErrorMessage.style.display = 'none';
    dayInput.style.backgroundColor = '';
  }
});


//选择都道府県
const prefecturesSelect = document.getElementById("data-action-preparator-prefectures");
const prefecturesError = document.getElementById("vp-view-err_vp-view-prefectures");

prefecturesSelect.addEventListener("blur", function () {
  if (this.value === "") {
    prefecturesError.style.display = "block";
    prefecturesSelect.style.backgroundColor = '#ffdcd0';
  } else {
    prefecturesError.style.display = "none";
    prefecturesSelect.style.backgroundColor = '';
  }
});


// 获取郵便番号输入框和错误提示元素
const postalXInput = document.querySelector('input[data-action-preparator-postal1="1"]');
const postalXErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_postal_1');
const postalYInput = document.querySelector('input[data-action-preparator-postal2="2"]');
const postalYErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_postal_2');

// 监听输入框的 blur 事件
postalXInput.addEventListener('blur', () => {
  if (!postalXInput.value.trim()) {
    postalXErrorMessage.style.display = 'block';
    postalXInput.style.backgroundColor = '#ffdcd0';
  } else {
    postalXErrorMessage.style.display = 'none';
    postalXInput.style.backgroundColor = '';
  }
});

postalYInput.addEventListener('blur', () => {
  if (!postalYInput.value.trim()) {
    postalYErrorMessage.style.display = 'block';
    postalYInput.style.backgroundColor = '#ffdcd0';
  } else {
    postalYErrorMessage.style.display = 'none';
    postalYInput.style.backgroundColor = '';
  }
});


// 获取市区郡・町村输入框和错误提示元素
const cityInput = document.querySelector('input[data-action-preparator-city="1"]');
const cityErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_city');

// 监听输入框的 blur 事件
cityInput.addEventListener('blur', () => {
  if (!cityInput.value.trim()) {
    cityErrorMessage.style.display = 'block';
    cityInput.style.backgroundColor = '#ffdcd0';
  } else {
    cityErrorMessage.style.display = 'none';
    cityInput.style.backgroundColor = '';
  }
});


// 获取市町名・番地输入框和错误提示元素
const districtInput = document.querySelector('input[data-action-preparator-district="1"]');
const districtErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_district');

// 监听输入框的 blur 事件
districtInput.addEventListener('blur', () => {
  if (!districtInput.value.trim()) {
    districtErrorMessage.style.display = 'block';
    districtInput.style.backgroundColor = '#ffdcd0';
  } else {
    districtErrorMessage.style.display = 'none';
    districtInput.style.backgroundColor = '';
  }
});

// 邮编接口，自动填入地址
function validateAndSearchAddress() {
  var postalCode1 = document.querySelector('[data-action-preparator-postal1="1"]');
  var postalCode2 = document.querySelector('[data-action-preparator-postal2="2"]');

  if (postalCode1.value.length === 3 && postalCode2.value.length === 4) {
    var fullPostalCode = postalCode1.value + postalCode2.value;

    fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${fullPostalCode}`)
      .then(response => response.json())
      .then(data => {
        document.querySelector('#data-action-preparator-prefectures').value = data.results[0].address1;
        document.querySelector('[data-action-preparator-city="1"]').value = data.results[0].address2;
        document.querySelector('[data-action-preparator-district="1"]').value = data.results[0].address3;
      })
      .catch(error => {
        console.error('Error fetching address:', error);
      });
  } else {
    document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_postal_1').style.display = 'block';
    document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_postal_2').style.display = 'block';
  }
}

document.querySelector('[data-action-preparator-postal1="1"]').addEventListener('input', function () {
  if (this.value.length === 3) {
    document.querySelector('[data-action-preparator-postal2="2"]').focus();
  }
});

document.querySelector('[data-action-preparator-postal2="2"]').addEventListener('input', function () {
  if (this.value.length === 4) {
    validateAndSearchAddress();
  }
});



// 口座番号
function validateDebitAcctNo() {
  const input = document.getElementById('vp-view-VC0204-001_RS0001_debitAcctNo');
  const errorElement = document.getElementById('debitAcctNoError');
  const value = input.value.trim();

  if (value.length === 4 && /^\d{4}$/.test(value)) {
    errorElement.style.display = 'none';
    input.style.backgroundColor = '';
  } else {
    errorElement.style.display = 'block';
    input.style.backgroundColor = '#ffdcd0';
  }
}

function enforceNumericInput(event) {
  if (event.which < 48 || event.which > 57) {
    event.preventDefault();
  }
}

const inputElement = document.getElementById('vp-view-VC0204-001_RS0001_debitAcctNo');
inputElement.addEventListener('blur', validateDebitAcctNo);
inputElement.addEventListener('input', validateDebitAcctNo);
inputElement.addEventListener('keypress', enforceNumericInput);


// 口座番号
// function validateDebitAcctNo() {
//   const input = document.getElementById('vp-view-VC0204-001_RS0001_debitAcctNo');
//   const errorElement = document.getElementById('debitAcctNoError');

//   if (input.value.trim() === '') {
//     errorElement.style.display = 'block';
//     input.style.backgroundColor = '#ffdcd0';
//   } else {
//     errorElement.style.display = 'none';
//     input.style.backgroundColor = '';
//   }
// }

// document.getElementById('vp-view-VC0204-001_RS0001_debitAcctNo').addEventListener('blur', validateDebitAcctNo);
// document.getElementById('vp-view-VC0204-001_RS0001_debitAcctNo').addEventListener('input', validateDebitAcctNo);
