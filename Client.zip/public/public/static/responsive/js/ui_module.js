(function($) {
    
    var JSON_PATH = '/static/responsive/js/json/';
    var JSON_EXT = '.json';
    
    var ATTR_PATH = 'data-ui-module-path';
    var SLCT_PATH = '[' + ATTR_PATH + ']';
    
    var ATTR_TYPE = 'data-ui-module-type';
    var SLCT_TYPE = '[' + ATTR_TYPE + ']';
    var SLCT_TYPE_FORMAT = '[' + ATTR_TYPE + '={0}]';
    
    var ATTR_ID = 'data-ui-module-id';
    
    var ATTR_PROP = 'data-ui-module-prop';
    var SLCT_PROP = '[' + ATTR_PROP + ']';
    
    var ATTR_DISPLAY = 'data-ui-module-display';
    var SLCT_DISPLAY = '[' + ATTR_DISPLAY + ']';
    
    var ATTR_ATTR = 'data-ui-module-attr';

    var ATTR_FORMAT = 'data-ui-module-format';

    var ATTR_FILTER = 'data-ui-module-filter';
    
    var PROP_DELIM = '.';
    
    var _renderWorkers = {};
    
    function _printWithFormat(format) {

        for (var i = 1; i < arguments.length; i++) {
            format = format.replace(
                new RegExp('\\{' + (i - 1) + '\\}', 'g'), arguments[i]);
        }

        return format;
    }

    function _findValue(key, record) {
        
        // プロパティ名の区切り文字の位置を探す．
        var delimPos = key.indexOf(PROP_DELIM);
        
        if (delimPos == -1) {
            // 区切り文字が見つからない場合は，単一階層のプロパティ名であるか，
            // または複数階層を持つプロパティ名の最下位置の部分プロパティ名であると判断して，
            // それに対応するレコード値を返す．
            return record[key];
            
        } else {
            // 区切り文字が見つかった場合は，再帰的に下層に下りてレコード値を探索する．
            var firstKey = key.slice(0, delimPos);
            var lastKey = key.slice(delimPos + 1);
            
            return _findValue(lastKey, record[firstKey]);
        }
    }
    
    function _render(type, records) {
        
        $(_printWithFormat(SLCT_TYPE_FORMAT, type)).each(function() {
            var $typeElement = $(this);
            
            var id = $typeElement.attr(ATTR_ID);
            
            // レコード群の中から指定のid値に該当するレコードを選択する．
            var record;
            $.each(records, function(index, value) {
                if (id == value.id) {
                    record = value;
                    return false;
                }
            });
            
            // 該当するレコードが見つかった場合は，それに対応するブロックを表示状態にする．
            // 見つからなかった場合は，それに対応するブロックを非表示状態にして終了する．
            if (record === undefined) {
                $typeElement.hide();
                return;
                
            } else {
                $typeElement.show();
            }
            
            // 該当レコード内のプロパティ群の中から，指定されているプロパティ名に一致しているものを探して，
            // その値を該当箇所の文字列として設定する．
            $typeElement.find(SLCT_PROP).each(function() {
                var $element = $(this);
                
                var value = _findValue($element.attr(ATTR_PROP), record);
                if (value === undefined) {
                    return;
                }
                
                var filter = $element.attr(ATTR_FILTER);
                if (filter !== undefined) {
                    value = value.replace(new RegExp(filter, 'g'), '');
                }
                
                var format = $element.attr(ATTR_FORMAT);
                if (format !== undefined) {
                    value = _printWithFormat(format, value);
                }
                
                var attr = $element.attr(ATTR_ATTR);
                if (attr !== undefined) {
                    $element.attr(attr, value);
                    
                } else {
                    $element.html(value);
                }
            });
            
            // 該当レコード内のプロパティ群の中から，指定されているプロパティ名に一致しているものを探して，
            // 見つかった場合は表示状態にする．また，見つからなかった場合は，非表示状態にする．
            $typeElement.find(SLCT_DISPLAY).each(function() {
                var $element = $(this);
                
                var value = _findValue($element.attr(ATTR_DISPLAY), record);
                if (value === undefined || value === '') {
                    $element.hide();
                    
                } else {
                    $element.show();
                }
            });
        });
    }
    
    $(function() {
        
        var jsonPath = JSON_PATH;
        $(SLCT_PATH).each(function() {
            jsonPath = $(this).attr(ATTR_PATH);
        });
        
        var now = (new Date).getTime();
        
        // 当該画面内に宣言されているtypeの集合を取得する．
        var types = {};
        $(SLCT_TYPE).each(function() {
            var $typeElement = $(this);
            
            var type = $typeElement.attr(ATTR_TYPE);
            types[type] = undefined;
        });
        
        // type毎に該当するJSONデータを非同期で取得し，レンダリング処理を行う．
        for (type in types) {
            var url = jsonPath + type + JSON_EXT;
            
            var renderWorker = _renderWorkers[url];
            if (renderWorker !== undefined && renderWorker.state() == "pending") {
                continue; // すでにリクエストが準備されている場合はスキップする．
            }
            
            // JSONデータがブラウザ内にキャッシュされてしまうことによって，
            // データ更新が反映されなくなってしまうことを回避するために，
            // 現在時刻をクエリパラメータに追加しつつJSONデータを取得する．
            _renderWorkers[url] = $.getJSON(url, { time: now }, function(records) {
                _render(type, records);
                $(window).trigger("resize");
            });
        }
    });
    
})(jQuery);
