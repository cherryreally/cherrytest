// 获取邮箱输入框和错误提示元素
document.addEventListener('DOMContentLoaded', () => {
  const emailInput = document.querySelector('input[type="email"][email-id="1"]');
  const cardNameInput = document.getElementById('vp-view-VC0201-001_RS0010_cardname');
  const debitAcctNoInput = document.getElementById('vp-view-VC0204-001_RS0001_debitAcctNo');

  const emailErrorMessage = document.getElementById('email_1');
  const cardNameErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_cardname');
  const debitAcctNoErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_debitAcctNo');


  const yearInput = document.getElementById('vp-view-VC0201-001_RS0010_birth_year');
  const yearErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_birth_year');

  const monInput = document.getElementById('vp-view-VC0201-001_RS0010_birth_mon');
  const monErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_birth_mon');

  const dayInput = document.getElementById('vp-view-VC0201-001_RS0010_birth_day');
  const dayErrorMessage = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_birth_day');


  // 监听邮箱输入框的 blur 事件
  emailInput.addEventListener('blur', () => {
    const emailValue = emailInput.value.trim();
    const emailPattern = /[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+(\.[a-zA-Z]{2,})+$/;

    if (!emailValue || !emailPattern.test(emailValue)) {
      emailErrorMessage.style.display = 'block';
      emailInput.style.backgroundColor = '#ffdcd0';
    } else {
      emailErrorMessage.style.display = 'none';
      emailInput.style.backgroundColor = '';
    }
  });

  // 监听卡片持有人姓名输入框的 blur 事件
  cardNameInput.addEventListener('blur', () => {
    const cardNameValue = cardNameInput.value.trim();
    const romanjiPattern = /^[A-Za-z\s\t]+$/;

    if (!cardNameValue || !romanjiPattern.test(cardNameValue)) {
      cardNameErrorMessage.style.display = 'block';
      cardNameInput.style.backgroundColor = '#ffdcd0';
    } else {
      cardNameErrorMessage.style.display = 'none';
      cardNameInput.style.backgroundColor = '';
    }
  });


  // 监听口座番号输入框的 blur 事件
  debitAcctNoInput.addEventListener('blur', () => {
    const debitAcctNoValue = debitAcctNoInput.value.trim();
    const romanjiPattern = /^[0-9]+$/;

    if (!debitAcctNoValue || !romanjiPattern.test(debitAcctNoValue)) {
      debitAcctNoErrorMessage.style.display = 'block';
      debitAcctNoInput.style.backgroundColor = '#ffdcd0';
    } else {
      debitAcctNoErrorMessage.style.display = 'none';
      debitAcctNoInput.style.backgroundColor = '';
    }
  });




  yearInput.addEventListener('blur', () => {
    if (!yearInput.value.trim()) {
      yearErrorMessage.style.display = 'block';
      yearInput.style.backgroundColor = '#ffdcd0';
    } else {
      yearErrorMessage.style.display = 'none';
      yearInput.style.backgroundColor = '';
    }
  });

  monInput.addEventListener('blur', () => {
    if (!monInput.value.trim()) {
      monErrorMessage.style.display = 'block';
      monInput.style.backgroundColor = '#ffdcd0';
    } else {
      monErrorMessage.style.display = 'none';
      monInput.style.backgroundColor = '';
    }
  });

  dayInput.addEventListener('blur', () => {
    if (!dayInput.value.trim()) {
      dayErrorMessage.style.display = 'block';
      dayInput.style.backgroundColor = '#ffdcd0';
    } else {
      dayErrorMessage.style.display = 'none';
      dayInput.style.backgroundColor = '';
    }
  });

});



document.addEventListener('DOMContentLoaded', () => {
  const postalInput1 = document.getElementById('vp-view-VC0201-001_RS0010_postal_1');
  const postalInput2 = document.getElementById('vp-view-VC0201-001_RS0010_postal_2');
  const postalError1 = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_postal_1');
  const postalError2 = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_postal_2');
  // const prefectureSelect = document.querySelector('select[name="data-action-preparator-prefectures"]');
  // const prefectureError = document.getElementById('vp-view-err_vp-view-prefectures');

  const prefecturesInput = document.getElementById('vp-view-prefectures');
  const prefecturesErrorMessage = document.getElementById('vp-view-err_vp-view-prefectures');

  const cityInput = document.getElementById('vp-view-VC0201-001_RS0010_city');
  const cityError = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_city');
  const districtInput = document.getElementById('vp-view-VC0201-001_RS0010_district');
  const districtError = document.getElementById('vp-view-err_vp-view-VC0201-001_RS0010_district');

  function validateAndHighlight(input, errorElement) {
    if (!input.value.trim()) {
      errorElement.style.display = 'block';
      input.style.backgroundColor = '#ffdcd0';
    } else {
      errorElement.style.display = 'none';
      input.style.backgroundColor = '';
    }
  }

  postalInput1.addEventListener('blur', () => validateAndHighlight(postalInput1, postalError1));
  postalInput2.addEventListener('blur', () => validateAndHighlight(postalInput2, postalError2));
  cityInput.addEventListener('blur', () => validateAndHighlight(cityInput, cityError));
  districtInput.addEventListener('blur', () => validateAndHighlight(districtInput, districtError));

  postalInput2.addEventListener('blur', async () => {
    const postalCode = postalInput1.value + postalInput2.value;
    if (postalCode.length === 7) {
      try {
        const response = await fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${postalCode}`);
        const data = await response.json();
        if (data.results && data.results.length > 0) {
          const address = data.results[0];
          // prefectureSelect.value = address.address1;
          prefecturesInput.value = address.address1;
          cityInput.value = address.address2;
          districtInput.value = address.address3;

          // Trigger change event for prefecture select
          // prefectureSelect.dispatchEvent(new Event('change'));
          prefecturesInput.dispatchEvent(new Event('change'));

          // Trigger blur event for city and district inputs
          cityInput.dispatchEvent(new Event('blur'));
          districtInput.dispatchEvent(new Event('blur'));
        }
      } catch (error) {
        console.error('Error fetching address:', error);
      }
    }


    // 监听都道府県选择框的 blur 事件
    prefecturesInput.addEventListener('blur', () => {
      const selectedValue = prefecturesInput.value.trim();

      if (!selectedValue) {
        prefecturesErrorMessage.style.display = 'block';
        prefecturesInput.style.backgroundColor = '#ffdcd0';
      } else {
        prefecturesErrorMessage.style.display = 'none';
        prefecturesInput.style.backgroundColor = '';
      }
    });

  });

});
