(function($) {
    var isLteIE8 = (app.indexOf("msie 6.") != -1 || app.indexOf("msie 7.") != -1 || app.indexOf("msie 8.") != -1);
//    ie8用 bottom余白削除

    if (isLteIE8) {
        $("div").each(function(){
            var this_selector = $(this);
            setDefaultLastChild(this_selector, "p");
            if(!this_selector.hasClass(".tabHead")){
                setDefaultLastChild(this_selector, "ul");
            }
            setDefaultLastChild(this_selector, "div");
            setDefaultLastChild(this_selector, ".txtBox");
            setDefaultLastChild(this_selector, ".formBtnArea");
            setDefaultLastChild(this_selector, ".conversionArea");
        });
        
        $("#contWrap .section").each(function(){
            var this_selector = $(this);
            setDefaultLastChild(this_selector, "p");
            setDefaultLastChild(this_selector, "table");
            setDefaultLastChild(this_selector, "div");
            setDefaultLastChild(this_selector, "ul");
            setDefaultLastChild(this_selector, ".liqW");
        });
        
        $("#contWrap .inquiryWrap ul").each(function(){
            var this_selector = $(this);
            this_selector.children("li").last().children("ul").css("cssText", "margin-bottom:0px !important;");
        });
        
        $("#contWrap ul").each(function(){
            var this_selector = $(this);
            setDefaultLastChild(this_selector, "li");
        });

        $("#contWrap td").each(function(){
            var this_selector = $(this); 
            setDefaultLastChild(this_selector, "p");
            setDefaultLastChild(this_selector, "table");
            setDefaultLastChild(this_selector, "div");
            setDefaultLastChild(this_selector, "ul");
            setDefaultLastChild(this_selector, ".liqW");
        });
        
        $(".verticalStep.type02 dd").each(function(_e){
            this_dd = $(this);
            target = this_dd.find("div:eq(1)");
            target.css('padding','0px 10px 10px 0px');
        });
        
        $(".relevantPageWrapArea .relevantPageArea .smallArrowLink > li:LAST-CHILD").each(function(){
            var this_target = $(this); 
            this_target.css({"border-bottom":"none", "margin-bottom":"0"});
        });
        
    }

    function setDefaultLastChild(selector, target){
        selector.find(target + ":last-child").css("margin-bottom", "0px");
    }
})(jQuery);