(function() {
    
    var LayoutModeCookie = com.smbc_card.layout.LayoutModeCookie;
    var UserAgent = com.smbc_card.util.UserAgent;
    var LayoutModeView = {
        applyBlockForSmartPhone: function() {
            $('.forSpBlock.layoutChangeArea').css('display', 'block');
            $('.changePcMode').css('display', 'none');
        },
        applyBlockForPC: function() {
            // スマートフォン以外は表示モード切替できないようにするために、切替UIを非表示にする
            $('.forPcBlock.layoutChangeArea').css('cssText', 'display:none!important;');
            $('.forSpBlock.layoutChangeArea').css('cssText', 'display:none!important;');
        },
        writeViewportForSmartPhone: function() {
            document.write('<meta name="viewport" content="width=device-width, initial-scale=1.0">');
        },
        writeViewportForPC: function() {
            document.write('<meta name="viewport" content="width=1024, maximum-scale=1.0">');
        },
        writeViewportForiPad: function() {
            // iPadの場合
            if (window.screen.width > window.screen.height) {
                //横画面の場合
                document.write('<meta name="viewport" content="width=device-width, user-scalable=no, maximum-scale=1.0, initial-scale=1.0">');
            } else {
                //縦画面の場合
                document.write('<meta name="viewport" content="width=1024, user-scalable=no, maximum-scale=1.0, initial-scale=1.0">');
            }
            $(window).on("orientationchange", function() {
                if (window.screen.width > window.screen.height) {
                    //横画面の場合
                    $("meta[name='viewport']").attr("content", "width=device-width, user-scalable=no, maximum-scale=1.0, initial-scale=1.0");
                } else {
                    //縦画面の場合
                    $("meta[name='viewport']").attr("content", "width=1024, user-scalable=no, maximum-scale=1.0, initial-scale=1.0");
                    $('body,html').stop().animate({scrollTop:$(window).scrollTop() + 1});
                }
            });
        }
    };
    
    if (typeof dojo === 'object') { // dojoが使用されている場合
        _inCaseWithDojo();
    } else { // dojoが使用されていない場合
        _inCaseWithoutDojo();
    }
    
    function _inCaseWithDojo() {
console.log('viewport.js : Working with Dojo.');
        
        // requireを用いると、ここで記述する処理を即時実行させることができないため、
        // やむを得ず、AlcorConstantsのうち、必要な部分だけを擬似的に作成して使用する
        var AlcorConstantsStatic = {
            ACCESS_SEGMENT: 'device',
            VIRTUAL_ACCESS_SEGMENT: 'deviceVR',
            ACCESS_SEGMENT_SEPARATOR: ':',
            DEVICE: {
                PC: '01',
                PHONE: '02',
                SMART_PHONE: '03'
            },
            DEVICE_DETAIL_DEFAULT: ":01",
        };
        
        // requireを用いると、ここで記述する処理を即時実行させることができないため、
        // やむを得ず、AlcorConfigのうち、必要な部分だけを擬似的に作成して使用する
        // ただし、本物のAlcorConfigの当該メソッドとは動作が異なる（本物はコロンの前までのみ取得される）ことに注意せよ
        var AlcorConfigStatic = {
            getAccessBy: function() {
                return $.cookie(AlcorConstantsStatic.ACCESS_SEGMENT);
            },
            getVAccessBy: function() {
                return $.cookie(AlcorConstantsStatic.VIRTUAL_ACCESS_SEGMENT);
            }
        };
        
        function _getDevice(accessBy) {
            return accessBy.split(AlcorConstantsStatic.ACCESS_SEGMENT_SEPARATOR)[0];
        }
        function _convertLayoutModeToDevice(layoutMode) {
            return layoutMode == LayoutModeCookie.LAYOUT_MODE_SP
                ? AlcorConstantsStatic.DEVICE.SMART_PHONE + AlcorConstantsStatic.DEVICE_DETAIL_DEFAULT
                : AlcorConstantsStatic.DEVICE.PC + AlcorConstantsStatic.DEVICE_DETAIL_DEFAULT; 
        }
        function _convertDeviceToLayoutMode(device) {
            return _getDevice(device) == AlcorConstantsStatic.DEVICE.SMART_PHONE
                ? LayoutModeCookie.LAYOUT_MODE_SP : LayoutModeCookie.LAYOUT_MODE_PC;
        }
        
        var accessBy = AlcorConfigStatic.getAccessBy();
        var vAccessBy = AlcorConfigStatic.getVAccessBy();
        
        // 実デバイス判定値がCookie内に設定されていない場合は、簡易判定を用いる
        if (accessBy === undefined) {
            accessBy = UserAgent.isSmartPhone
                ? AlcorConstantsStatic.DEVICE.SMART_PHONE + AlcorConstantsStatic.DEVICE_DETAIL_DEFAULT
                : AlcorConstantsStatic.DEVICE.PC + AlcorConstantsStatic.DEVICE_DETAIL_DEFAULT; 
        }
        
        // 仮想デバイス判定値がCookie内に設定されていない場合は、静的側で保持している設定値を用いる
        // 静的側でも保持している設定値がない場合は、実デバイス判定値と一致させる（デフォルトの仮想デバイス値）
        if (vAccessBy === undefined) {
            var layoutMode = LayoutModeCookie.load();
            vAccessBy = (layoutMode !== undefined) ? _convertLayoutModeToDevice(layoutMode) : accessBy;
        }
        
        // 動的ページ側で使用している仮想デバイス値を、静的ページ側の表示モードに設定する
        // （他のJSプログラム内で表示モード設定値が参照されており、このタイミングで同期させて参照できるようにしておく必要があるため）
        LayoutModeCookie.save(_convertDeviceToLayoutMode(vAccessBy));
        
        //iOS13環境でのiPad判定の処理追加
        var agent = window.navigator.userAgent.toLowerCase();
        var isiPad = agent.indexOf('ipad') > -1 || agent.indexOf('macintosh') > -1 && 'ontouchend' in document;

        // 仮想デバイス値をもとにviewportを設定する
        if (_getDevice(vAccessBy) == AlcorConstantsStatic.DEVICE.PC) {
            if (isiPad) {
                LayoutModeView.writeViewportForiPad();
            } else {
                LayoutModeView.writeViewportForPC();
            }
        } else if (_getDevice(accessBy) == AlcorConstantsStatic.DEVICE.SMART_PHONE) {
            LayoutModeView.writeViewportForSmartPhone();
        }
        
        require([
            'vp/alcor/util/UAUtil',
            'vp/alcor/config/AlcorConfig'
        ], function(UAUtil, AlcorConfig) {
            
            // 動的側で設定した仮想デバイス値と、静的側で保持している仮想デバイス値が異なる場合、
            // または、静動同期フラグが立っている場合は、静的側の仮想デバイス値を正として、動的側を同期させる
            UAUtil.uaPromise.then(function() {
                if (vAccessBy != AlcorConfigStatic.getVAccessBy() || LayoutModeCookie.isNeedSync()) {
                    UAUtil.switchDeviceForStatic(vAccessBy).then(function() {
                        // 仮想デバイス切替APIが失敗した場合には、次の機会にもう一度同期を試みるようにしたい
                        // そこで、仮想デバイス切替APIが成功した場合のみ、静動同期フラグを降ろす
                        LayoutModeCookie.setNeedSync(false);
                    });
                }
            });
            UAUtil.checkDeviceForStatic();
            
            $(function() {
                if (_getDevice(accessBy) == AlcorConstantsStatic.DEVICE.SMART_PHONE) { // 実デバイスがスマートフォンの場合
                    // スマートフォン向けの表示モード切替UIを設定する
                    LayoutModeView.applyBlockForSmartPhone();
                    
                    // ユーザが表示モードを切り替えた際のハンドラを登録しておく
                    var Handler = {
                        _isHandling: false,
                        onRequestedToChangeLayoutMode: function(device) {
                            // 連打防止のためハンドリングフラグを確認する
                            if (! this._isHandling) {
                                this._isHandling = true;
                            
                                AlcorConfig.setVAccessBy(device);
                                LayoutModeCookie.save(_convertDeviceToLayoutMode(device));
                                
                                // 静動同期フラグを立てておき、仮想デバイス切替APIが成功したらフラグを降ろす
                                LayoutModeCookie.setNeedSync(true);
                                UAUtil.switchDeviceForStatic(device, 0).then(function() {
                                    LayoutModeCookie.setNeedSync(false);
                                    window.location.reload();
                                    $('body').scrollTop(0);
                                }, function() {
                                    window.location.reload();
                                    $('body').scrollTop(0);
                                });
                            }
                            return false;
                        }
                    };
                    $('.changePcSp').click(function() {
                        return Handler.onRequestedToChangeLayoutMode(
                            AlcorConstantsStatic.DEVICE.PC + AlcorConstantsStatic.DEVICE_DETAIL_DEFAULT);
                    });
                    $('.changeSpMode').click(function() {
                        return Handler.onRequestedToChangeLayoutMode(
                            AlcorConstantsStatic.DEVICE.SMART_PHONE + AlcorConstantsStatic.DEVICE_DETAIL_DEFAULT);
                    });
                    
                } else { // 実デバイスがスマートフォン以外の場合
                    // スマートフォン以外向けの表示モード切替UIを設定する
                    LayoutModeView.applyBlockForPC();
                }
            });
        });
    }
    
    function _inCaseWithoutDojo() {
console.log('viewport.js : Working without Dojo.');
        
        var layoutMode = LayoutModeCookie.load();
        
        // 表示モードが設定されていない場合は、実デバイス種別をもとに決定する
        // また、決定した表示モードを保存しておく
        if (layoutMode === undefined) {
            // スマートフォンの場合のみSPレイアウトとし、タブレットはPCと同等の扱いとする
            layoutMode = UserAgent.isSmartPhone ? LayoutModeCookie.LAYOUT_MODE_SP : LayoutModeCookie.LAYOUT_MODE_PC;
            LayoutModeCookie.save(layoutMode);
        }
        
        //iOS13環境でのiPad判定の処理追加
        var agent = window.navigator.userAgent.toLowerCase();
        var isiPad = agent.indexOf('ipad') > -1 || agent.indexOf('macintosh') > -1 && 'ontouchend' in document;

        // 表示モードをもとにviewportを設定する
        if (layoutMode === LayoutModeCookie.LAYOUT_MODE_PC) {
            if (isiPad) {
                LayoutModeView.writeViewportForiPad();
            } else {
                LayoutModeView.writeViewportForPC();
            }
        } else if (layoutMode === LayoutModeCookie.LAYOUT_MODE_SP) {
            LayoutModeView.writeViewportForSmartPhone();
        }
        
        $(function() {
            if (UserAgent.isSmartPhone) { // 実デバイスがスマートフォンの場合
                // スマートフォン向けの表示モード切替UIを設定する
                LayoutModeView.applyBlockForSmartPhone();
                
                // ユーザが表示モードを切り替えた際のハンドラを登録しておく
                function _onRequestedToChangeLayoutMode(layoutMode) {
                    LayoutModeCookie.save(layoutMode);
                    window.location.reload();
                    $('body').scrollTop(0);
                    return false; // 通常のクリック動作をさせない
                }

                $('.changePcSp').click(function() {
                    return _onRequestedToChangeLayoutMode(LayoutModeCookie.LAYOUT_MODE_PC);
                });
                $('.changeSpMode').click(function() {
                    return _onRequestedToChangeLayoutMode(LayoutModeCookie.LAYOUT_MODE_SP);
                });
                
            } else { // 実デバイスがスマートフォン以外の場合
                // スマートフォン以外向けの表示モード切替UIを設定する
                LayoutModeView.applyBlockForPC();
            }
        });
    }
})();
