        $(function() {
            $(".categoryIcon span").css( "background-size", "cover" );
            $(".menuRight span").css( "background-size", "cover" );
            $(".bannerMenu.sideSection p a span").css( "background-size", "cover" );
        });
