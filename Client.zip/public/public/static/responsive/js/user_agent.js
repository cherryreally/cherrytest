var com = com || {};
com.smbc_card = com.smbc_card || {};
com.smbc_card.util = com.smbc_card.util || {};

(function(ns) {
    
    ns.UserAgent = {
        init: function() {
            this.name = window.navigator.userAgent.toLowerCase();
            this.isIE = this.name.indexOf('msie') >= 0 || this.name.indexOf('trident') >= 0;
            this.isChrome = this.name.indexOf('chrome') >= 0;
            this.isiPhone = this.name.indexOf('iphone') >= 0;
            this.isiPod = this.name.indexOf('ipod') >= 0;
            this.isiPad = this.name.indexOf('ipad') >= 0;
            this.isiOS = this.isiPhone || this.isiPod || this.isiPad;
            this.isAndroid = this.name.indexOf('android') >= 0;
            this.isTablet = this.isiPad || (this.isAndroid && this.name.indexOf('mobile') < 0);
            this.isTouchDevice = this.isiOS || this.isAndroid;
            this.isSmartPhone = this.isiPhone || this.isiPod || (this.isAndroid && this.name.indexOf('mobile') >= 0);
            return this;
        }
    }.init();
    
})(com.smbc_card.util);
