document.addEventListener('DOMContentLoaded', () => {
  const monthInput = document.getElementById('vp-view-VC0204-001_RS0001_month');
  const yearInput = document.getElementById('vp-view-VC0204-001_RS0001_year');
  const cvv2Input = document.getElementById('vp-view-VC0204-001_RS0001_cvv2');

  const monthErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_month');
  const yearErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_year');
  const cvv2ErrorMessage = document.getElementById('vp-view-err_vp-view-VC0204-001_RS0001_cvv2');

  // 监听月份输入框的 blur 事件
  monthInput.addEventListener('blur', () => {
    if (!monthInput.value.trim()) {
      monthErrorMessage.style.display = 'block';
      monthInput.style.backgroundColor = '#ffdcd0';
    } else {
      monthErrorMessage.style.display = 'none';
      monthInput.style.backgroundColor = '';
    }
  });

  // 监听年份输入框的 blur 事件
  yearInput.addEventListener('blur', () => {
    if (!yearInput.value.trim()) {
      yearErrorMessage.style.display = 'block';
      yearInput.style.backgroundColor = '#ffdcd0';
    } else {
      yearErrorMessage.style.display = 'none';
      yearInput.style.backgroundColor = '';
    }
  });

  // 监听cvv2输入框的 blur 事件
  cvv2Input.addEventListener('blur', () => {
    if (!cvv2Input.value.trim()) {
      cvv2ErrorMessage.style.display = 'block';
      cvv2Input.style.backgroundColor = '#ffdcd0';
    } else {
      cvv2ErrorMessage.style.display = 'none';
      cvv2Input.style.backgroundColor = '';
    }
  });
});
