define([
'dojo/_base/array',
'dojo/dom-attr',
'dojo/query',
'dojo/_base/declare',
'dojo/dom',
'dojo/text!./info2.html',
'dijit/registry',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/StoreManager',
'vp/alcor/control/TransitionManager',
'vp/alcor/view/ExtLink',
'vps/member/WebApiConst',
'vps/sp/member/WebMeisaiPrepared',
'vpx/sp/view/ActionPreparatorBr',
'./WebMeisaiConst',
'./WebMeisaiGrid',
'./WebMeisaiStore',
'vpx/view/ActionPreparatorU051',
'vps/member/DropdownList',
'vps/member/EnableDeviceButton',
'vp/member/pages/WebMeisaiPaging',
'vps/member/IncCommonFunctions'
], function(array, domAttr, query, declare, dom, template, registry, _AbstractPage, StoreManager, TransitionManager, ExtLink,
WebApiConst, WebMeisaiPrepared, ActionPreparator, WebMeisaiConst, WebMeisaiGrid, WebMeisaiStore, ActionPreparatorU051) {
return declare('vp.member.pages.info2', [_AbstractPage], {
templateString: template,
cssClass: 'mainWidgetBase',
preventBack: true,

onStartup: function() {
var imgNodes = query('img[src$="/dummy.jpg"]');
array.forEach(imgNodes, function(imgNode) {
var nameAttr = domAttr.get(imgNode, 'name');
if (nameAttr && nameAttr.indexOf('%{') === -1) {
domAttr.set(imgNode, 'src', imgNode.src.replace('/common/dynamic/memx/img/dummy.jpg', nameAttr));
}
});

var response = StoreManager.fetchScreenData(WebApiConst.API.VC0502003_RS0001).data;
var topBean = response.WebMeisaiTopDisplayServiceBean;
var commonBean = response.WebMeisaiCommonDisplayServiceBean;

ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareInputActions();
ActionPreparator.prepareLoginRadioActions();

var isPreEdit = topBean.preEditFlag;
var paramMap = topBean.paramMap;

this._grid = new WebMeisaiGrid({
pageSize: 100,
initData: {
dataList: topBean.meisaiList,
total: parseInt(topBean.webMeisaiTopK3Vo.allCnt)
},
initPage: Math.ceil(parseInt(topBean.webMeisaiTopK3Vo.firstRow) / 100),
store: new WebMeisaiStore({
buildPostData: function () {
if ((this._last.page && this._last.count && this._last.prevPageRow && this._last.nextPageRow) === undefined) {
this._last.page = Math.ceil(parseInt(topBean.webMeisaiTopK3Vo.firstRow) / 100);
this._last.count = 100;
this._last.prevPageRow = parseInt(topBean.webMeisaiTopK3Vo.prevPageRow);
this._last.nextPageRow = parseInt(topBean.webMeisaiTopK3Vo.nextPageRow);
}

return this.inherited(arguments);
},
webApiId: WebApiConst.API.VC0502003_RS0001,
bean: 'WebMeisaiTopDisplayServiceBean',
beanProperty: 'meisaiList',
statusBean: 'WebMeisaiTopDisplayServiceBean',
statusBeanProperty: 'webMeisaiTopK3Vo'
}),
formKbn: WebMeisaiConst.FORM_KBN.FUSHO,
isPreEdit: isPreEdit,
updateView: function(){
var isChangePage = query('tbody tr', this.domNode).length > 0;

this.inherited(arguments);
ActionPreparator.prepareAccordionActions();
paramMap = StoreManager.fetchScreenData(WebApiConst.API.VC0502003_RS0001).data.WebMeisaiTopDisplayServiceBean.paramMap;
ActionPreparatorU051.prepareScreen();
StoreManager.putScreenData(WebApiConst.API.VC0502003_RS0001, response);

var p01 = paramMap.p01;
var p03 = paramMap.p03;
var prtbtn = dom.byId('vp-view-VC0502-003_RS0001_U051111_1');
prtbtn.href = "/memx/web_meisai/top/index_prt.html?p01=" + p01 + "&p03=" + p03;

if (isChangePage) {
var meisaiTop = this.domNode.parentNode.offsetTop;
var headerHeight = dom.byId('header').offsetHeight;
var smbcLineHeight = dom.byId('smbcLine').offsetHeight;
var offsetY = 7;
window.scrollTo(0, meisaiTop - headerHeight - smbcLineHeight - offsetY);
}
},
query: {
p01: paramMap.p01
}
}, 'meisaiTable');

var seikyuYM = commonBean.seikyuYM;

var finTabId = 'vp-view-VC0502-003_RS0002_U051111';
var finTab  = dom.byId(finTabId);
this.onNode(finTab, 'click', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0002,
postData: {p01: seikyuYM},
hash:'fin',
success: function(res){
WebMeisaiPrepared.prepareFin(res);
}
}, true);
});
var detailTabId = 'vp-view-VC0502-003_RS0003_U051111';
var detailTab  = dom.byId(detailTabId);
this.onNode(detailTab, 'click', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0003,
postData: {p01: seikyuYM},
hash:'detail',
success: function(res){
WebMeisaiPrepared.prepareDetail(res);
}
}, true);
});

var formNodeId = 'vp-view-WebApiId_U051111_112';
var formNode = registry.byId(formNodeId) || dom.byId(formNodeId);
if (formNode) {
this.onNode(formNode, 'change', function() {
if (!formNode.value || formNode.value.length < 6) {
return ;
}
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0001,
postData: {p01: formNode.value},
success: function(res){
WebMeisaiPrepared.prepareTop(res);
}
});
}, true);
}

var pulldownNodeId = 'vp-view-VC0502-003_RS0001_com_p01';
var pulldownNode = registry.byId(pulldownNodeId) || dom.byId(pulldownNodeId);
if (pulldownNode) {
this.onNode(pulldownNode, 'change', function() {
if (!pulldownNode.value || pulldownNode.value.length < 6) {
return ;
}
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0001,
postData: {p01: pulldownNode.value},
success: function(res){
WebMeisaiPrepared.prepareTop(res);
}
});
}, true);
}

var vo = topBean.webMeisaiTopK3Vo;
if (vo && vo.finPrVoList) {
var tableList = document.getElementsByName('vp-view-VC0502-003_finPrVoList01');
array.forEach(tableList, function(table, i) {
if (vo.finPrVoList[i]) {
array.forEach(table.getElementsByTagName('td'), function(tdNode) {
tdNode.style.backgroundColor = vo.finPrVoList[i].finPrBackcolor;
});
}
});
}



require([
'vp/member/pages/info13',
'dojo/text!vp/member/pages/info13.html',
'vp/member/pages/MeisaiStore',
'vp/member/pages/MeisaiGrid',
'vp/meisai/include/inc_meisai_shiharai_total',
'dojo/text!vp/meisai/include/inc_meisai_shiharai_total.html',
'dojo/text!vp/member/pages/MeisaiRecord.html'
]);

}
});
});
