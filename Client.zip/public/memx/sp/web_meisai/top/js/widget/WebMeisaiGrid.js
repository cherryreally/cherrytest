define([
'dojo/_base/array',
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom-construct',
'dojo/parser',
'dojo/query',
'dojo/text!./WebMeisaiRecord.html',
'vp/alcor/util/ArrayUtil',
'vp/alcor/util/destroyWidgets',
'vp/alcor/view/_AlcorRawGrid',
'./WebMeisaiConst'
], function(array, declare, lang, domConst, parser, query, recordTemplate,
ArrayUtil, destroyWidgets, _AlcorRawGrid, WebMeisaiConst) {
return declare('vp.member.pages.MeisaiGrid', [_AlcorRawGrid], {
isPreEdit: false,

formKbn: null,

_prevRowType: null,

constructor: function() {
var templateList = this._templateList = [];
var separatedList = recordTemplate.split('<tr data-meisai-type="');
for (var i = 1; i < separatedList.length; i++) {
var separated = separatedList[i];
var sepIndex = separated.indexOf('"');
templateList.push({
type: separated.slice(0, sepIndex),
template: ['<tr', separated.slice(sepIndex+1)].join('')
});
}
},

_getSuffix: function(rowType, maxIndex, overlay, rowDataList) {
if (this.formKbn === WebMeisaiConst.FORM_KBN.FIN) { 
if (rowType === WebMeisaiConst.ROW_TYPE.T3C) {
if (maxIndex === '3') {
return maxIndex + '_' + overlay;
} else {
return '_' + overlay;
}
} else {
return '';
}
} else { 
if (rowType !== WebMeisaiConst.ROW_TYPE.T4K &&
rowType !== WebMeisaiConst.ROW_TYPE.T4S &&
rowType !== WebMeisaiConst.ROW_TYPE.T47 &&
rowType !== WebMeisaiConst.ROW_TYPE.T4C) {
return maxIndex;
}

if (rowType === WebMeisaiConst.ROW_TYPE.T47) {
if (this.formKbn === WebMeisaiConst.FORM_KBN.SCORP && rowDataList[3] !== '') {
return 'M';
} else {
return maxIndex;
}
}else if(rowType === WebMeisaiConst.ROW_TYPE.T4C){
if (rowDataList[3] !== '') {
return maxIndex + 'M';
} else {
return maxIndex;
}
}

if (!this.isPreEdit && this.formKbn !== WebMeisaiConst.FORM_KBN.HAGAKI) {
return 'Fixed' + overlay;
} else {
var indexPart = 'PreEdit' + maxIndex;
if (maxIndex !== '3') { 
return indexPart;
}
if (this.formKbn === WebMeisaiConst.FORM_KBN.FUSHO && overlay === '058' ||
this.formKbn === WebMeisaiConst.FORM_KBN.HAGAKI && overlay === '158') {
return indexPart + '_58';
} else if (overlay === '062' || overlay === '162') {
return indexPart + '_62';
} else {
return indexPart;
}
}
}
},

_getFormPrefix: function(rowType) {
if (this.formKbn === WebMeisaiConst.FORM_KBN.HAGAKI && (
rowType === WebMeisaiConst.ROW_TYPE.T45 ||
rowType === WebMeisaiConst.ROW_TYPE.T47 ||
rowType === WebMeisaiConst.ROW_TYPE.T48 ||
rowType === WebMeisaiConst.ROW_TYPE.T4C)) {
return 'H';
} else if (this.formKbn === WebMeisaiConst.FORM_KBN.SCORP) {
return 'SC';
}
return '';
},

_createSeparatorId: function(rowType) {
var fix = this.isPreEdit ? 'PreEdit' : 'Fixed';
var prefix = this._getFormPrefix(rowType);
return prefix + rowType + fix + 'Prev';
},

_getTemplateFor: function(rowType, overlay, maxIndex, rowDataList) {
var targetTypeList = [];
if (rowType === WebMeisaiConst.ROW_TYPE.T4S && this._prevRowType !== rowType) {
targetTypeList.push(this._createSeparatorId(rowType));
}
var idPrefix = this._getFormPrefix(rowType) + rowType;
var index = (typeof maxIndex === 'undefined') ? '' : maxIndex;
var rowId = idPrefix + this._getSuffix(rowType, index, overlay, rowDataList);
var rowIdNoIndex = idPrefix + this._getSuffix(rowType, '', overlay, rowDataList);
if (rowId !== rowIdNoIndex && this.formKbn !== WebMeisaiConst.FORM_KBN.FIN) {
var nonAccordionRowIdNoIndex = this._judgeAccordionBtnDsp(rowIdNoIndex, rowDataList);
targetTypeList.push(nonAccordionRowIdNoIndex);
}
var nonAccordionRowId = this._judgeAccordionBtnDsp(rowId, rowDataList);
targetTypeList.push(nonAccordionRowId);

var htmlList = [];
array.forEach(this._templateList, function(entry) {
if (ArrayUtil.contains(targetTypeList, entry.type)) {
htmlList.push(entry.template);
}
});
return htmlList.join('');
},

_judgeAccordionBtnDsp: function(rowId, rowDataList) {

if('4KFixed002' === rowId || '4KPreEdit3' === rowId || '4SPreEdit3' === rowId || 'SC4KPreEdit3' === rowId){
if( rowDataList[3] === '' || rowDataList[3] === null){
return rowId+'_nonAccordion';
}
} else if ('4KFixed005' === rowId || '4KPreEdit10' === rowId || '4SFixed005' === rowId 
|| '4SPreEdit10' === rowId || 'SC4KPreEdit10' ===rowId || 'SC4SPreEdit10' === rowId) {
if(rowDataList[10] === '' || rowDataList[10] === null){
return rowId+'_nonAccordion';
}
}
return rowId;
},

_createRowHTML: function(rowData) {
var overlayCode = rowData.data[1];
var template = this._getTemplateFor(rowData.rowType, overlayCode, rowData.maxIndex, rowData.data);
var rowHTML = lang.replace(template, rowData.data);
this._prevRowType = rowData.rowType;
return rowHTML;
},

updateView: function(dataList) {
var newTbodyHTML = ['<tbody>'];
array.forEach(dataList, function(rowData) {
var len = rowData.data.length;
for (var i = 0; i < len; i++) {
var data = rowData.data[i];
if (/[\d*]{4}-[\d*]{4}-[\d*]{4}-[\d*]{4}/.test(data)) {
rowData.data[i] = data.replace(/([\d*]{4}-[\d*]{2})[\d*]{2}-[\d*]{4}-[\d*]{4}/g, '$1**-****-****');
}
}
newTbodyHTML.push(this._createRowHTML(rowData));
}, this);
newTbodyHTML.push('</tbody>');
var oldTbodyNode = query('tbody', this.domNode)[0];
destroyWidgets(oldTbodyNode);
var newTbodyNode = domConst.place(newTbodyHTML.join(''), oldTbodyNode, 'replace');
parser.parse(newTbodyNode);
}
});
});
