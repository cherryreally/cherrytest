define([
'dojo/_base/declare',
'dojo/text!./DummyInfoTop.html',
'vp/alcor/pages/_AbstractPage',
'vps/member/WebApiConst',
'vps/sp/member/WebMeisaiPrepared' 
], function(declare, template, _AbstractPage, WebApiConst, WebMeisaiPrepared) {
return declare('vp.member.pages.DummyInfoTop', [_AbstractPage], {
templateString: template,
includeQueryParamOnInit:true,

constructor: function(){
var url = location.href;
if (url && 0 < url.search(/[?&]seikyuYM=/)) {
this.initTransitOptions.webApiId = WebApiConst.API.VC0501002_RS0001;
} else if (url && 0 < url.search(/[?&]service=fin/)) {
this.initTransitOptions.webApiId = WebApiConst.API.VC0502003_RS0002;
} else if (url && 0 < url.search(/[?&]service=detail/)) {
this.initTransitOptions.webApiId = WebApiConst.API.VC0502003_RS0003;
} else {
this.initTransitOptions.webApiId = WebApiConst.API.VC0502003_RS0001;
}
},
initTransitOptions: {
webApiId: WebApiConst.API.VC0502003_RS0001,
doMove: true,
keepErrorInfoOverHTML: false,
success: function(res){
var url = location.href;
if (url && 0 < url.search(/[?&]service=fin/)) {
WebMeisaiPrepared.prepareFin(res);
} else if (url && 0 < url.search(/[?&]service=detail/)) {
WebMeisaiPrepared.prepareDetail(res);
} else {
WebMeisaiPrepared.prepareTop(res);
}
}
}
});
});

