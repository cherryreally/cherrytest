require([
'vp/alcor/control/TransitionManager', 
'vps/member/WebApiConst', 
'dojo/parser', 
'vps/member/DefaultModules'
], function(TransitionManager, WebApiConst) {
TransitionManager.init({
initHistory: function() {
history.back();
},
webApiConst: WebApiConst,
lazyParsingMode: true,
acceptHash:[
{
hash:'fin',
contentWidgetName:'vp.member.pages.DummyInfoFin',
history: function() {}
},
{
hash:'detail',
contentWidgetName:'vp.member.pages.DummyInfoDetail',
history: function() {}
}
]
});
});
