require([
'vp/alcor/control/TransitionManager',
'dojo/ready',
'vps/member/WebApiConst',
'vps/member/DefaultModules',
'dojo/parser'
], function(TransitionManager, ready, WebApiConst) {
TransitionManager.init({
lazyParsingMode: true,
initHistory: function(){
history.back();
},
webApiConst: WebApiConst,
acceptHash:[
{
hash:'accept',
contentWidgetName:'vp.member.pw.pages.accept',
history: function() {}
},
{
hash:'accept2',
contentWidgetName:'vp.member.pw.pages.accept2',
history: function() {}
},
{
hash:'accept4',
contentWidgetName:'vp.member.pw.pages.accept4',
history: function() {}
},
{
hash:'accept5',
contentWidgetName:'vp.member.pw.pages.accept5',
history: function() {}
},
{
hash:'accept6',
contentWidgetName:'vp.member.pw.pages.accept6',
history: function() {}
},
{
hash:'accept7',
contentWidgetName:'vp.member.pw.pages.accept7',
history: function() {}
}
]
});
});
