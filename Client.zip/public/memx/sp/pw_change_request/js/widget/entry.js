define([
'dojo/_base/declare',
'dojo/dom',
'dojo/text!./entry.html',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/ValueController',
'vpx/view/ValidationHandler',
'vps/member/WebApiConst',
'vps/member/IncCommonFunctions',
'vp/pw/common/IncInput',
'vp/pw/common/IncInputFs'
], function(declare, dom, templatePath, _AbstractPage, TransitionManager, ValueController,
ValidationHandler, WebApiConst) {

return declare('vp.member.pw.pages.entry', [_AbstractPage],
{

templateString: templatePath,
preventBack: true,
onStartup: function() {
var formId = 'FRM_c_U039210-0001';
var formNode = dom.byId(formId);

ValueController.updateForm(formId);

this.onNode(formNode, 'submit', function() {
ValidationHandler.init();
TransitionManager.transit({
webApiId: WebApiConst.API.VC0204001_RS0002,
formId: formId,
onValidationFailed: ValidationHandler.onValidationFailed,
doMove: true,
error: function(err){
if(err && err.response && err.response.data && err.response.data.body &&
err.response.data.body.validationErrors){
var newPassword = dom.byId('vp-view-VC0204-001_RS0001_newPassword');
var newPasswordKakunin = dom.byId('vp-view-VC0204-001_RS0001_newPasswordKakunin');
if(newPassword){
newPassword.value= "";
}
if(newPasswordKakunin){
newPasswordKakunin.value= "";
}
}
}
});
});
}
});
});

