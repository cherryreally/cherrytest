define([
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/ValueController',
'vp/alcor/view/Message',
'vp/alcor/view/inputcheck/AlcorValidators',
'vpx/sp/view/ActionPreparatorBr',
'vpx/sp/view/ActionPwChangeRequestAccordion',
'vp/alcor/control/StoreManager',
'vp/alcor/view/FuncControl',
'app/common/js/validation/ValidationRegexpConst',
'vps/member/DropdownList_nodisp',
'vps/member/EnableDeviceButton',
'vps/member/ConfirmMailPanel'
], function(declare, lang, dom, _AbstractPage, valueController, Message, AlcorValidators,
ActionPreparator, ActionPwChangeRequestAccordion, StoreManager, FuncControl, ValidationRegexpConst) {

return declare('vp.member.widget.IncInputFs', [_AbstractPage],
{

onStartup: function() {
ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareInputActions();
ActionPreparator.prepareLoginRadioActions();

ActionPwChangeRequestAccordion.initPwChangeAccordionInitialState();
ActionPwChangeRequestAccordion.initPwChangeAccordionHandler();

var queryResult = StoreManager.queryScreenData(function(entry) {
return entry && entry.data && entry.data.PwChangeReqInputDisplayServiceBean;
});
var token1 = dom.byId('vp-view-CONFIRM_MAIL_RS0001_confirm_mail_token1');
token1.value = queryResult[0].data.confirm_mail_token;

var pwChangeHyojiFlg = queryResult[0].data.PwChangeReqInputDisplayServiceBean.pwChangeHyojiFlg;
dom.byId('vp-view-VC0204-001_RS0001_url').value =
queryResult[0].data.CustomizedPwChangeReqInputServiceBean.url;
var month = dom.byId('vp-view-VC0204-001_RS0001_month');
var year = dom.byId('vp-view-VC0204-001_RS0001_year');
var cvv2 = dom.byId('vp-view-VC0204-001_RS0001_cvv2');
var useracct4 = dom.byId('vp-view-VC0204-001_RS0001_useracct4');
var tel1 = dom.byId('vp-view-VC0204-001_RS0001_tel1');
var tel2 = dom.byId('vp-view-VC0204-001_RS0001_tel2');
var tel3 = dom.byId('vp-view-VC0204-001_RS0001_tel3');
var newPassword = dom.byId('vp-view-VC0204-001_RS0001_newPassword');
var newPasswordKakunin = dom.byId('vp-view-VC0204-001_RS0001_newPasswordKakunin');
var henkouSelect = dom.byId('vp-view-VC0204-001_RS0001_henkouSelect_1');

this.addValidation({
node: month, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (month.value === '') {
return false;
}
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.106' })
});
this.addValidation({
node: month, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkNumber(month.value);
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.107' })
});
this.addValidation({
node: month, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(month.value, { minLength: 2, maxLength: 2 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.108' })
});
this.addValidation({
node: month, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (month.value < '01' || '12' < month.value ) {
return false;
}
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.113' })
});

this.addValidation({
node: year, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (year.value === '') {
return false;
}
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.109' })
});
this.addValidation({
node: year, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkNumber(year.value);
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.110' })
});
this.addValidation({
node: year, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(year.value, { minLength: 2, maxLength: 2 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.111' })
});

FuncControl.getResult({
functionControlKey:'Reauthentication_method',
type:'equals',
value:'1'
}).then(lang.hitch(this, function(equals) {
if (equals) {
var cvv2 = dom.byId('vp-view-VC0204-001_RS0001_cvv2');
this.addValidation({
node: cvv2, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (cvv2.value === '') {
return false;
}
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.112' })
});
this.addValidation({
node: cvv2, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkNumber(cvv2.value);
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.112' })
});
this.addValidation({
node: cvv2, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(cvv2.value, { minLength: 3, maxLength: 3 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.112' })
});
}
}));
FuncControl.getResult({
functionControlKey:'Reauthentication_method',
type:'equals',
value:'2'
}).then(lang.hitch(this, function(equals) {
if (equals) {
var useracct4 = dom.byId('vp-view-VC0204-001_RS0001_useracct4');
this.addValidation({
node: useracct4, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (useracct4.value === '') {
return false;
}
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.112' })
});
this.addValidation({
node: useracct4, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkNumber(useracct4.value);
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.112' })
});
this.addValidation({
node: useracct4, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(useracct4.value, { minLength: 4, maxLength: 4 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.cvv2.112' })
});
}
}));
this.addValidation({
node: tel1, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (tel1.value === '' && tel2.value === '' && tel3.value === '') {
return false;
}
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100001' })
});
this.addValidation({
node: tel1, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (tel1.value === '' && !(tel2.value === '' && tel3.value === '')) {
return false;
}
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100003' })
});
this.addValidation({
node: tel1, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkNumber(tel1.value);
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100004' })
});
this.addValidation({
node: tel1, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(tel1.value, { maxLength: 5 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100005' })
});
this.addValidation({
node: tel2, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (tel2.value === '' && !(tel1.value === '' && tel3.value === '')) {
return false;
}
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100006' })
});
this.addValidation({
node: tel2, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkNumber(tel2.value);
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100007' })
});
this.addValidation({
node: tel2, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(tel2.value, { maxLength: 4 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100008' })
});
this.addValidation({
node: tel3, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (tel3.value === '' && !(tel2.value === '' && tel1.value === '')) {
return false;
}
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100009' })
});
this.addValidation({
node: tel3, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkNumber(tel3.value);
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100010' })
});
this.addValidation({
node: tel3, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(tel3.value, { maxLength: 5 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100011' })
});
this.addValidation({
node: tel1, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return ((tel1.value.length + tel2.value.length + tel3.value.length) <= 11);
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100002' })
});
this.addValidation({
node: newPasswordKakunin, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (newPassword.value === '' && newPasswordKakunin.value === '') {
return false;
}
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100012' })
});
this.addValidation({
node: newPassword, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (newPassword.value === '' && newPasswordKakunin.value !== '') {
return false;
}
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100013' })
});
this.addValidation({
node: newPassword, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkString(newPassword.value,
{charType:ValidationRegexpConst.REGEXP_ID_CHAR});
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100014' })
});
this.addValidation({
node: newPassword, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
return AlcorValidators.checkLength(newPassword.value, { minLength: 6, maxLength: 20 });
}
return true;
},
checkOnChange: true,
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100057' })
});
this.addValidation({
node: newPasswordKakunin, 
validator: function() {
if (!pwChangeHyojiFlg || henkouSelect.checked) {
if (newPassword.value !== newPasswordKakunin.value) {
return false;
}
}
return true;
},
invalidMessage: Message.getMessage({ msgKey: '00.u039.E2100016' })
});

}
});
});

