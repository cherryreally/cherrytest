define.amd.jQuery = true;
define([
'dojo/_base/array',
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom',
'dojo/dom-attr',
'dojo/query',
'dojo/text!./info.html',
'dijit/registry',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/ValueController',
'vp/alcor/view/inputcheck/AlcorValidators',
'jquery',
'vpx/sp/view/ActionPreparatorBr',
'vpx/sp/view/MyPageViewPreparator',
'vpx/sp/view/widget/MyPageInfoWidget',
'vps/member/WebApiConst',
'vp/alcor/control/StoreManager', 
'vp/alcor/view/FuncControl', 
'vp/alcor/view/Message',
'vp/alcor/constants/AlcorConstants',
'vpx/sp/view/JquerySlides',
'vpx/view/SystemInfo',
'vps/member/DropdownList',
'vps/member/EnableDeviceButton',
'vps/member/IncCommonFunctions',
'vp/member/pages/infoCommonPoint' 
], function(array, declare, lang, dom, domAttr, query, templatePath, registry,
_AbstractPage, TransitionManager, ValueController, AlcorValidators,
$, ActionPreparator, MyPageViewPreparator, MyPageInfoWidget, WebApiConst, StoreManager, FuncControl, Message, AlcorConstants, JquerySlides,
SystemInfo) {

function _getErrorMessage(str) {
var errMsg = '';
Message.getMessage({ msgKey: str }).then(
function(msg) {
errMsg = msg;
}
);
return errMsg != '';
}


return declare('vp.member.pages.info', [_AbstractPage], {

_equal: function(a, b) {
return a == b && !(a === "" && b === 0 || a === 0 && b === "");
},

_present: function(value) {
return value !== null && value !== undefined &&
value !== "" && (!lang.isArray(value) || value.length !== 0);
},

_isIncluded: function(arr, value) {
return array.some(arr, function(item) {
return this._equal(item, value);
}, this);
},

_isMessage: function(array) {
var retrunList = [];
var j = 0;
for(var i = 0; i < array.length; i++) {
if (_getErrorMessage(array[i])) {
retrunList[j] = {"msgkey": array[i]};
j++;
}
}
return retrunList;
},

templateString: templatePath,
preventScreenDataCache: true,
initTransitOptions: {
webApiId: WebApiConst.API.VC0104001_RS0004,
doMove: true,
error: function() {
}
},
cssClass: 'mainWidgetBase',
buildRendering: function() {
this.inherited(arguments);
},
postCreate: function() {
return this.inherited(arguments);
},

onBeforeScreenDataStored: function(content) {

if (content && content.NoticeMsgDisplayServiceBean) {
var bean = content.NoticeMsgDisplayServiceBean;

if (bean.msg3dSecureList) {
bean.msg3dSecureList = this._isMessage(bean.msg3dSecureList);

var _3dSecureMsgKeys = ["00.notice.002", "00.notice.003"];
array.forEach(bean.msg3dSecureList, function(item) {
item._dispMsgFlag = this._isIncluded(_3dSecureMsgKeys, item.msgkey) ? "1" : "0";
}, this);
}
if (bean.msgAgreementLinkList) {
bean.msgAgreementLinkList = this._isMessage(bean.msgAgreementLinkList);
}
if (bean.msgCommonMsgList) {
bean.msgCommonMsgList = this._isMessage(bean.msgCommonMsgList);

var _commonMsgKeys = [
"00.u000.I1100101", "00.u000.I1100102", "00.u000.I1100103",
"00.u000.I1100104", "00.u000.I1100105", "00.u000.I1100106"
];
array.forEach(bean.msgCommonMsgList, function(item) {
item._dispMsgFlag = this._isIncluded(_commonMsgKeys, item.msgkey) ? "1" : "0";
}, this);

if (bean.msgCommonMsgList.length !== 0){
bean._dispImportantMsgFlag = "1";
}
}
if (bean.msgEmailList) {
bean.msgEmailList = this._isMessage(bean.msgEmailList);

var _msgEmailKeys = ["00.login.101", "00.login.102"];
array.forEach(bean.msgEmailList, function(item) {
item._dispMsgFlag = this._isIncluded(_msgEmailKeys, item.msgkey) ? "1" : "0";
}, this);
}
if (bean.msgKeisanList) {
bean.msgKeisanList = this._isMessage(bean.msgKeisanList);

var _vpHenkouKeys = [
"00.kei_mail.411", "00.kei_mail.412", "00.kei_mail.413",
"00.kei_mail.414", "00.kei_mail.415"
];
var _wmMailTopKeys = ["00.kei_mail.421", "00.u000.I1100005"];
var _updateIndexKeys = [
"00.u000.I1100008", "00.u000.I1100009", "00.u000.I1100010", "00.u000.I1100012",
"00.u000.I1100011", "00.u000.I1100013", "00.u000.I1100007"
];
array.forEach(bean.msgKeisanList, function(item) {
item._dispMsgFlag = "1";
if (this._isIncluded(_vpHenkouKeys, item.msgkey)) {
item._category = "vp_henkou";
} else if (this._isIncluded(_wmMailTopKeys, item.msgkey)) {
item._category = "wm_mail_top";
} else if (this._isIncluded(_updateIndexKeys, item.msgkey)) {
item._category = "update_index";
} else { 
item._dispMsgFlag = "0";
}
}, this);
}
if (bean.msgProviderList) {
bean.msgProviderList = this._isMessage(bean.msgProviderList);
}
if (bean.msgMobileEmailList) {
bean.msgMobileEmailList = this._isMessage(bean.msgMobileEmailList);
}
if (bean.msgCardCodeMsgList) {
bean.msgCardCodeMsgList = this._isMessage(bean.msgCardCodeMsgList);

if (bean.msgCardCodeMsgList.length !== 0){
bean._dispImportantMsgFlag = "1";
}
}
if (bean.msgSimpleMsgList) {
bean.msgSimpleMsgList = this._isMessage(bean.msgSimpleMsgList);

if (bean.msgSimpleMsgList.length !== 0){
bean._dispImportantMsgFlag = "1";
}
}
if (bean.msgNoticeInfoSASList) {
var retrunList = [];
var j = 0;
for(var i = 0; i < bean.msgNoticeInfoSASList.length; i++) {
retrunList[j] = {"msg": bean.msgNoticeInfoSASList[i]};
j++;
}
bean.msgNoticeInfoSASList = retrunList;
}
}

if (content && content.CampaignsInfoDisplayServiceBean) {
var bean = content.CampaignsInfoDisplayServiceBean;

if (bean.personalInfoList) {
var newPersonalInfoList = [];
for(var i = 0; i < bean.personalInfoList.length; i++) {
newPersonalInfoList[i] = {"bean": bean.personalInfoList[i]};
}
bean.personalInfoList = newPersonalInfoList;
}

if (bean.cardInfoList) {
var newCardInfoList = [];
for(var i = 0; i < bean.cardInfoList.length; i++) {
newCardInfoList[i] = {"bean": bean.cardInfoList[i]};
}
bean.cardInfoList = newCardInfoList;
}
if (bean.campaignInfoList) {
var newCampaignInfoList = [];
for(var i = 0; i < bean.campaignInfoList.length; i++) {
newCampaignInfoList[i] = {"bean": bean.campaignInfoList[i]};
}
bean.campaignInfoList = newCampaignInfoList;
}
if (bean.spCampaignInfoList) {
var newspCampaignInfoList = [];
for(var i = 0; i < bean.spCampaignInfoList.length; i++) {
newspCampaignInfoList[i] = {"bean": bean.spCampaignInfoList[i]};
}
bean.spCampaignInfoList = newspCampaignInfoList;
}
}

if(content && content.MyInfoDisplayServiceBean) {
var bean = content.MyInfoDisplayServiceBean;

if(bean.meisaiList) {
var meisaiListCount = 0;
for(var i = 0; i < bean.meisaiList.length; i++) {
++meisaiListCount;
}
bean.meisaiListCount = meisaiListCount;
}

if(bean.grade === "my_BONUS_1.gif"){
bean.grade = "img_bonuspoint_v1.gif";
}else if(bean.grade === "my_BONUS_2.gif"){
bean.grade = "img_bonuspoint_v2.gif";
}else if(bean.grade === "my_BONUS_3.gif"){
bean.grade = "img_bonuspoint_v3.gif";
}

bean._dispSeikyuBtnFlag = "0";
if (!this._present(bean.seikyuFlag) && !this._present(bean.mainteErrorFlag) &&
this._equal(bean.seikyuPtn, "1")) {
bean._dispSeikyuBtnFlag = "1";
}

if (this._present(bean.mainteErrorFlag)) {
bean.seikyuExpectedDate = "";
bean.seikyuMsg = "";
}

var _meisaiMsgKeys = ["00.mypage.020", "00.mypage.021"];
bean._dispMeisaiMsgFlag = this._isIncluded(_meisaiMsgKeys, bean.meisaiMsg) ? "1" : "0";

var _nextClassMsgKeys = ["00.mypage.040", "00.mypage.042", "00.mypage.044", "00.mypage.046"];
bean._dispNextClassMsgFlag =
this._isIncluded(_nextClassMsgKeys, bean.nextClass) ? "1" : "0";
var _nextYearMsgKeys = ["00.mypage.041", "00.mypage.043", "00.mypage.045", "00.mypage.047"];
bean._dispNextYearMsgFlag =
this._isIncluded(_nextYearMsgKeys, bean.nextYearMsg) ? "1" : "0";
bean._nextYearMsgArgs = this._equal(bean.nextYearMsg, "00.mypage.047") ? "" : bean.nextClassNeedMoney;

bean.seikyuExpectedDate_YYYYMMDD = bean.seikyuExpectedDate;

if (bean.seikyuExpectedDate) {
var seikyuDate =  bean.seikyuExpectedDate.split("/");
bean.seikyuExpectedDate = seikyuDate[1] + "月" + seikyuDate[2] + "日";
}
}

if (content && content.maintErrMsgReplaceBean) {
var errMsgBean = content.maintErrMsgReplaceBean;
var _seikyuErrMsgKeys = ["00.mypage.000", "00.mypage.900"];
errMsgBean._dispMaintErrMsgSeikyuFlag =
this._isIncluded(_seikyuErrMsgKeys, errMsgBean.maintErrMsgSeikyu) ? "1" : "0";
var _meisaiErrMsgKeys = ["00.mypage.001", "00.mypage.901"];
errMsgBean._dispMaintErrMsgMeisaiFlag =
this._isIncluded(_meisaiErrMsgKeys, errMsgBean.maintErrMsgMeisai) ? "1" : "0";
var _wpErrMsgKeys = ["00.mypage.002", "00.mypage.902"];
errMsgBean._dispMaintErrMsgWpFlag =
this._isIncluded(_wpErrMsgKeys, errMsgBean.maintErrMsgWP) ? "1" : "0";
}

if (content && content.ButtonsDisplayServiceBean){
var bean = content.ButtonsDisplayServiceBean;
if (bean.bunnerButtonList) {
var newBunnerButtonList = [];
for(var i = 0; i < bean.bunnerButtonList.length; i++) {
newBunnerButtonList[i] = {"innerList": bean.bunnerButtonList[i]};
}
bean.bunnerButtonList = newBunnerButtonList;
}
}

if (content && content.CardAssortmentDisplayServiceBean) {
var bean = content.CardAssortmentDisplayServiceBean;

if (bean.cardAssortmentList) {
var cardAssortmentList = bean.cardAssortmentList;
var oldTitleCode = "";

for(var i = 0; i < cardAssortmentList.length; i++) {
bean.cardAssortmentList[i].push("titleCodeFlag");
if (oldTitleCode !== cardAssortmentList[i][0].titleCode) {
cardAssortmentList[i][0].titleCodeFlag = 0;
} else {
cardAssortmentList[i][0].titleCodeFlag = 1;
}
oldTitleCode = cardAssortmentList[i][0].titleCode;
}
var newCardAssortmentList = [];
for(var i = 0; i < bean.cardAssortmentList.length; i++) {
newCardAssortmentList[i] = {"innerList": bean.cardAssortmentList[i]};
}
bean.cardAssortmentList = newCardAssortmentList;
}
}
return content;
},

onStartup: function() {
this.inherited(arguments);
var formId = 'FRM_c_U000100-0001';

var btnOff = dom.byId('riyoDispOff');
this.onNode(btnOff, 'click', function() {
var postData = {'displayOnOff': '1'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0002, 
postData: postData,
doMove: true
});
});
var btnOn = dom.byId('riyoDispOn');
this.onNode(btnOn, 'click', function() {
var postData = {'displayOnOff': '0'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0002, 
postData: postData,
doMove: true
});
});
var btnOff = dom.byId('meisaiDispOff');
this.onNode(btnOff, 'click', function() {
var postData = {'displayOnOff': '1'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0005, 
postData: postData,
doMove: true
});
});
var btnOn = dom.byId('meisaiDispOn');
this.onNode(btnOn, 'click', function() {
var postData = {'displayOnOff': '0'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0005, 
postData: postData,
doMove: true
});
});
var btnOff = dom.byId('pointDispOff');
this.onNode(btnOff, 'click', function() {
var postData = {'displayOnOff': '1'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0003, 
postData: postData,
doMove: true
});
});
var btnOn = dom.byId('pointDispOn');
this.onNode(btnOn, 'click', function() {
var postData = {'displayOnOff': '0'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0003, 
postData: postData,
doMove: true
});
});

var seikyuExpectedDate_YYYYMMDD=StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.MyInfoDisplayServiceBean.seikyuExpectedDate_YYYYMMDD;
var btn = dom.byId('vp-view-WebApiId_U000100_9');
this.onNode(btn, 'click', function() {
var p01Value = StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.dateReplaceBean.ExpectedDate;
if(seikyuExpectedDate_YYYYMMDD == "2021/3/1"){
p01Value = "202102";
}
TransitionManager.transit({
transitTo: '/memx/sp/web_meisai/top/index.html?p01=' + p01Value, 
doMove: true
});
});
var btn = dom.byId('vp-view-WebApiId_U000100_9_2');
this.onNode(btn, 'click', function() {
var p01Value = StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.dateReplaceBean.ExpectedDate;
if(seikyuExpectedDate_YYYYMMDD == "2021/3/1"){
p01Value = "202102";
}
TransitionManager.transit({
transitTo: '/memx/sp/web_meisai/top/index.html?p01=' + p01Value, 
doMove: true
});
});
var btn = dom.byId('vp-view-WebApiId_U000100_9_3');
this.onNode(btn, 'click', function() {
var p01Value = StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.dateReplaceBean.ExpectedDate;
if(seikyuExpectedDate_YYYYMMDD == "2021/3/1"){
p01Value = "202102";
}
TransitionManager.transit({
transitTo: '/memx/sp/web_meisai/top/index.html?p01=' + p01Value, 
doMove: true
});
});
var btn = dom.byId('vp-view-WebApiId_U000100_9_4');
this.onNode(btn, 'click', function() {
var p01Value = StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.dateReplaceBean.ExpectedDate;
if(seikyuExpectedDate_YYYYMMDD == "2021/3/1"){
p01Value = "202102";
}
TransitionManager.transit({
transitTo: '/memx/sp/web_meisai/top/index.html', 
doMove: true
});
});

var select = query('[name="selectExt"]')[0];
this.onNode(select, 'change', function() {
TransitionManager.transit({
transitTo: '/memx/sp/web_meisai/top/index.html?p01=' + select.value, 
doMove: true
});
});
var select2 = query('[name="selectExt2"]')[0];
this.onNode(select2, 'change', function() {
TransitionManager.transit({
transitTo: '/memx/sp/web_meisai/top/index.html?p01=' + select2.value, 
doMove: true
});
});

var buttonNode = dom.byId('vp-view-WebApiId_U000100_22_3');
this.onNode(buttonNode, 'click', function() {
TransitionManager.transit({
transitTo: '/memx/sp/seikyu/index.html', 
doMove: true
});
});

var buttonNode = dom.byId('vp-view-WebApiId_U000100_12_2');
this.onNode(buttonNode, 'click', function() {
TransitionManager.transit({
transitTo: '/memx/sp/seikyu/index.html', 
doMove: true
});
});
var buttonNode = dom.byId('vp-view-WebApiId_U000100_12_3');
this.onNode(buttonNode, 'click', function() {
TransitionManager.transit({
transitTo: '/memx/sp/seikyu/index.html', 
doMove: true
});
});

var buttonNode = dom.byId('vp-view-WebApiId_U000100_7');
this.onNode(buttonNode, 'click', function() {
TransitionManager.transit({
transitTo: '/memx/sp/wpc/shokai/index.html', 
doMove: true
});
});


var idlink;
var bplink;
StoreManager.keyStorePromise.then(function(keyStore) {
idlink = keyStore.get(AlcorConstants.LINK_ID_PREFIX + '00.U000.idvalue_sp') || {};
bplink = keyStore.get(AlcorConstants.LINK_ID_PREFIX + '00.U000.bonusp_sp') || {};
}, function(err) {
});


var buttonNode = dom.byId('vp-view-WebApiId_U000100_10');
this.onNode(buttonNode, 'click', function() {
window.open(bplink.url, "_blank");
});

var buttonNode = dom.byId('vp-view-WebApiId_U000100_ID');   
this.onNode(buttonNode, 'click', function() {
window.open(idlink.url, "_blank");
});

var data;
var spCampaignInfoListsSize;
data = StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data;
if(data && data.CampaignsInfoDisplayServiceBean && data.CampaignsInfoDisplayServiceBean.spCampaignInfoList){
spCampaignInfoListsSize = data.CampaignsInfoDisplayServiceBean.spCampaignInfoList.length;
}

$(function() {
if(spCampaignInfoListsSize > 1){
$('#slides').slidesjs({
width: 940,
height: 365,
play: {
active: true,
auto: true,
interval: 4000,
swap: true
}
});
}
});


ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareInputActions();
MyPageViewPreparator.initImportantMessageAccordion();
MyPageViewPreparator.initMypageAdScroller();
SystemInfo.prepareSystemInfo();
}
});
});
