define([
'dojo/_base/array',
'dojo/dom-attr',
'dojo/_base/declare',
'dojo/request/iframe',
'dojo/dom',
'dojo/_base/lang',
'dojo/text!./info2.html',
'dojo/has',
'dijit/registry',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/StoreManager',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/ValueController',
'vp/alcor/control/_LocationHandler',
'vp/alcor/util/Logger',
'vp/alcor/view/Message',
'vp/alcor/view/inputcheck/AlcorValidators',
'vp/alcor/view/FuncControl',
'vps/member/WebApiConst',
'vps/member/WebMeisaiPrepared',
'vpx/view/ActionPreparatorBr',
'vpx/view/ValidationFactory',
'vpx/view/ValidationHandler',
'./WebMeisaiConst',
'./WebMeisaiGrid',
'./WebMeisaiStore',
'dojo/query',
'vpx/view/ActionPreparatorU051',
'vps/member/DropdownList',
'vps/member/EnableDeviceButton',
'vps/member/IncCommonFunctions'
], function(array, domAttr, declare, iframe, dom, lang, template, has, registry,
_AbstractPage, StoreManager, TransitionManager, valueController, locationHandler, Logger, Message, AlcorValidators,
FuncControl, WebApiConst, WebMeisaiPrepared, ActionPreparator, ValidationFactory, ValidationHandler,
WebMeisaiConst, WebMeisaiGrid, WebMeisaiStore, query, ActionPreparatorU051) {

function isIE() {
var isIE11 = navigator.userAgent.indexOf('Trident') > -1;
return !!has('ie') || isIE11 || false;
}

return declare('vp.member.pages.info2', [_AbstractPage], {
templateString: template,
preventBack: true,

onStartup: function() {
var imgNodes = query('img[src$="/dummy.jpg"]');
array.forEach(imgNodes, function(imgNode) {
var nameAttr = domAttr.get(imgNode, 'name');
if (nameAttr && nameAttr.indexOf('%{') === -1) {
domAttr.set(imgNode, 'src', imgNode.src.replace('/common/dynamic/memx/img/dummy.jpg', nameAttr));
}
});

ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareInputActions();
ActionPreparator.prepareLoginRadioActions();
ActionPreparator.prepareAccordionSlideActions();

var response = StoreManager.fetchScreenData(WebApiConst.API.VC0502003_RS0001).data;
var paramMap = response.WebMeisaiTopDisplayServiceBean.paramMap;
var bean = StoreManager.fetchScreenData(WebApiConst.API.VC0502003_RS0001).data.WebMeisaiTopDisplayServiceBean;
var isPreEdit = bean.preEditFlag;
var pm_p1 = paramMap.p01;

this._grid = new WebMeisaiGrid({
pageSize: 100,
initData: {
dataList: bean.meisaiList,
total: parseInt(bean.webMeisaiTopK3Vo.allCnt)
},
initPage: Math.ceil(parseInt(bean.webMeisaiTopK3Vo.firstRow) / 100),
store: new WebMeisaiStore({
buildPostData: function () {
if ((this._last.page && this._last.count && this._last.prevPageRow && this._last.nextPageRow) === undefined) {
this._last.page = Math.ceil(parseInt(bean.webMeisaiTopK3Vo.firstRow) / 100);
this._last.count = 100;
this._last.prevPageRow = parseInt(bean.webMeisaiTopK3Vo.prevPageRow);
this._last.nextPageRow = parseInt(bean.webMeisaiTopK3Vo.nextPageRow);
}

return this.inherited(arguments);
},
webApiId: WebApiConst.API.VC0502003_RS0001,
bean: 'WebMeisaiTopDisplayServiceBean',
beanProperty: 'meisaiList',
statusBean: 'WebMeisaiTopDisplayServiceBean',
statusBeanProperty: 'webMeisaiTopK3Vo'
}),
formKbn: WebMeisaiConst.FORM_KBN.FUSHO,
isPreEdit: isPreEdit,
updateView: function() {
var isChangePage = query('tbody tr', this.domNode).length > 0;

this.inherited(arguments);
paramMap = StoreManager.fetchScreenData(WebApiConst.API.VC0502003_RS0001).data.WebMeisaiTopDisplayServiceBean.paramMap;
ActionPreparatorU051.prepareScreen();
StoreManager.putScreenData(WebApiConst.API.VC0502003_RS0001, response);

if (isChangePage) {
window.scrollTo(0, this.domNode.parentNode.offsetTop - 95);
}
},
query: {
p01: pm_p1
}
}, 'meisaiTable');

var commonBean = StoreManager.fetchScreenData(WebApiConst.API.VC0502003_RS0001).data.WebMeisaiCommonDisplayServiceBean;
var seikyuYM = commonBean.seikyuYM;

var finTabId = 'vp-view-VC0502-003_RS0002_U051111';
var finTab  = dom.byId(finTabId);
this.onNode(finTab, 'click', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0002,
preventScreenDataCache: true,
formId: formId,
doMove: true,
hash:'fin',
postData: {p01: seikyuYM},
success: function(res){
WebMeisaiPrepared.prepareFin(res);
}
}, true);
});
var detailTabId = 'vp-view-VC0502-003_RS0003_U051111';
var detailTab  = dom.byId(detailTabId);
this.onNode(detailTab, 'click', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0003,
preventScreenDataCache: true,
doMove: true,
hash:'detail',
postData: {p01: seikyuYM},
success: function(res){
WebMeisaiPrepared.prepareDetail(res);
}
}, true);
});

var formId = 'FRM_c_U051111-0001';
var formNode = registry.byId(formId) || dom.byId(formId);
this.onNode(formNode, 'submit', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0001,
preventScreenDataCache: true,
formId: formId,
doMove: true,
success: function(res){
WebMeisaiPrepared.prepareTop(res);
}
});
}, true);

var btnNodeId = 'vp-view-VC0502-003_RS0001_U051111_6';
var btnNode = registry.byId(btnNodeId) || dom.byId(btnNodeId);
this.onNode(btnNode, 'click', function() {
var p01Node = dom.byId('vp-view-VC0502-003_RS0001_com_p01');
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0001,
preventScreenDataCache: true,
postData: {p01: p01Node.value},
doMove: true,
success: function(res){
WebMeisaiPrepared.prepareTop(res);
}
});
}, true);

var printBtnId1 = 'vp-view-VC0502-003_RS0001_U051111_1';
var printBtn1 = registry.byId(printBtnId1) || dom.byId(printBtnId1);
this.onNode(printBtn1, 'click', function() {
var p03 = paramMap.p03;
window.open('/memx/web_meisai/top/index_prt.html?p01='+ pm_p1 + '&p03=' + p03,
"win5","toolbar=no,location=no,directories=no,scrollbars=yes,resizable=no,width=1000,height=600");
});

var printBtnId2 = 'vp-view-VC0502-003_RS0001_U051111_2';
var printBtn2 = registry.byId(printBtnId2) || dom.byId(printBtnId2);
this.onNode(printBtn2, 'click', function() {
var p03 = paramMap.p03;
window.open('/memx/web_meisai/top/index_prt.html?p01='+ pm_p1 + '&p03=' +  p03,
"win5","toolbar=no,location=no,directories=no,scrollbars=yes,resizable=no,width=1000,height=600");
});

var printBtnId3 = 'vp-view-VC0502-003_RS0001_U051111_3';
var printBtn3 = registry.byId(printBtnId3) || dom.byId(printBtnId3);
this.onNode(printBtn3, 'click', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS0006,
postData: {p01: bean.webMeisaiTopK3Vo.seikyuYm},
doMove: true,
sync : has('ie') < 9, 
success: function(res){
var transitTo = res.header.transitTo;
if (transitTo !== 'vp.member.pages.error') { 
var filepath = res &&
res.body &&
res.body.content &&
res.body.content.DownloadResultBean &&
res.body.content.DownloadResultBean.filepath;
if(filepath){
if (isIE()) {
iframe.create('csv-download-'+new Date().getTime(), null, filepath);
} else {
locationHandler.go(filepath);
}

}else{
Logger.write({
category: 'VP',
logLevel: 'WARN',
errorNo: 'U05106001',
errorMessage: 'Failed to retreive filepath'
});
}
}
}
});
});
var kanjoLinkId1 = 'vp-view-VC0502-003_RS0001_U051111_4';
var kanjoLink1 = registry.byId(kanjoLinkId1) || dom.byId(kanjoLinkId1);
this.onNode(kanjoLink1, 'click', function() {
TransitionManager.transit({
webApiId: WebApiConst.API.VC0502003_RS2006,
postData: {p01: bean.webMeisaiTopK3Vo.seikyuYm},
doMove: true,
sync : has('ie') < 9, 
success: function(res){
var transitTo = res.header.transitTo;
if (transitTo !== 'vp.member.pages.error') { 
var filepath = res &&
res.body &&
res.body.content &&
res.body.content.DownloadResultBean &&
res.body.content.DownloadResultBean.filepath;
if(filepath){
if (isIE()) {
iframe.create('kanjo-download-'+new Date().getTime(), null, filepath);
} else {
locationHandler.go(filepath);
}
}else{
Logger.write({
category: 'VP',
logLevel: 'WARN',
errorNo: 'U05106002',
errorMessage: 'Failed to retreive filepath'
});
}
}
}
});
});

var vo = bean.webMeisaiTopK3Vo;
if (vo && vo.finPrVoList) {
var tableList = document.getElementsByName('vp-view-VC0502-003_finPrVoList01');
array.forEach(tableList, function(table, i) {
if (vo.finPrVoList[i]) {
array.forEach(table.getElementsByTagName('td'), function(tdNode) {
tdNode.style.backgroundColor = vo.finPrVoList[i].finPrBackcolor;
});
}
});
}

var clo_Gid ="";
var clo_Ccd = "";
var clo_Eid = "";

FuncControl.getResult({
functionControlKey:'U051_CLO_Send_Data_Ctl',
type:'equals',
value:'1'
}).then(lang.hitch(this, function(isEqual) { 
if (isEqual) {
clo_Gid = bean.globalId;
clo_Ccd = bean.cardCode;
clo_Eid = bean.externalId;
}
}));

FuncControl.getResult({
functionControlKey:'U051_CLO_Send_Flag',
type:'equals',
value:'1'
}).then(lang.hitch(this, function(isEqual) { 
if (isEqual) {
var cloApiUrl = bean.cloApiUrl;
var cloDispUrl = bean.cloDispUrl;
var clo_gid = clo_Gid;
var clo_iid = clo_Eid;

jQuery(function($) {

var apiUrl = cloApiUrl;

var dispUrl = cloDispUrl;

$.ajax({
type: 'GET',
url: apiUrl,
dataType: 'jsonp',
jsonp: 'callbackFunc',
data: { 'GID' : clo_gid, 'IID' : clo_iid},
success: function(json){

if (json.result == '000' && (json.checkResult == 1 || json.checkResult == 2)) {

$('<iframe>', {
'src': dispUrl + '?' + $.param({'gid': clo_gid, 'iid': clo_iid}),
'frameborder': '0',
'width': '730',
'height': '270'
}).css({"overflow":"hidden"}).appendTo("#clo-iframe-target");

$('#clo-iframe-target').after('<br>');
}
}
});

});
}
}));


var moneyKanjoArea;
if(bean.webMeisaiTopK3Vo.moneyFlg==='1'){
var moneyKanjoAreaId = 'vp-view-VC0502-003_RS0001_moneyFlg_1';
moneyKanjoArea = registry.byId(moneyKanjoAreaId) || dom.byId(moneyKanjoAreaId);
} else {
var moneyKanjoAreaId = 'vp-view-VC0502-003_RS0001_moneyFlg_default';
moneyKanjoArea = registry.byId(moneyKanjoAreaId) || dom.byId(moneyKanjoAreaId);
}

FuncControl.getResult({
functionControlKey:'MSMoney',
type:'equals',
value:'1'
}).then(lang.hitch(this, function(isEqual) { 
if (isEqual) {
moneyKanjoArea.style.display = 'block';
} else {
FuncControl.getResult({
functionControlKey:'Kanjo',
type:'equals',
value:'1'
}).then(lang.hitch(this, function(isEqual) { 
if (isEqual) {
moneyKanjoArea.style.display = 'block';
} else {
moneyKanjoArea.style.display = 'none';
}
}));
}
}));

require([
'vp/member/pages/info13',
'dojo/text!vp/member/pages/info13.html',
'vp/member/pages/MeisaiStore',
'vp/member/pages/MeisaiGrid',
'vp/meisai/include/inc_meisai_shiharai_total',
'dojo/text!vp/meisai/include/inc_meisai_shiharai_total.html',
'dojo/text!vp/member/pages/MeisaiRecord.html'
]);

}
});
});
