define([
'dojo/_base/array',
'dojo/_base/declare',
'dojo/dom',
'dojo/_base/lang',
'dojo/text!./DummyInfoTop.html',
'dijit/registry',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/StoreManager',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/ValueController',
'vp/alcor/util/Logger',
'vp/alcor/view/Message',
'vp/alcor/view/inputcheck/AlcorValidators',
'vps/member/WebApiConst',
'vpx/view/ActionPreparatorBr',
'vpx/view/ValidationFactory',
'vpx/view/ValidationHandler',
'vps/member/WebMeisaiPrepared' 
], function(array, declare, dom, lang, template, registry,
_AbstractPage, StoreManager, TransitionManager, valueController, Logger, Message, AlcorValidators,
WebApiConst, ActionPreparator, ValidationFactory, ValidationHandler, WebMeisaiPrepared) {
return declare('vp.member.pages.DummyInfoTop', [_AbstractPage], {
templateString: template,
includeQueryParamOnInit:true,
cssClass: 'mainWidgetBase',
constructor: function(){
var url = location.href;
if (url && 0 < url.search(/[?&]seikyuYM=/)) {
this.initTransitOptions.webApiId = WebApiConst.API.VC0501002_RS0001;
} else if (url && 0 < url.search(/[?&]service=fin/)) {
this.initTransitOptions.webApiId = WebApiConst.API.VC0502003_RS0002;
} else if (url && 0 < url.search(/[?&]service=detail/)) {
this.initTransitOptions.webApiId = WebApiConst.API.VC0502003_RS0003;
} else {
this.initTransitOptions.webApiId = WebApiConst.API.VC0502003_RS0001;
}
},
initTransitOptions: {
webApiId: WebApiConst.API.VC0502003_RS0001,
doMove: true,
keepErrorInfoOverHTML: false,
success: function(res){
var url = location.href;
if (url && 0 < url.search(/[?&]service=fin/)) {
WebMeisaiPrepared.prepareFin(res);
} else if (url && 0 < url.search(/[?&]service=detail/)) {
WebMeisaiPrepared.prepareDetail(res);
} else {
WebMeisaiPrepared.prepareTop(res);
}
}
},
onStartup: function() {

ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareInputActions();
ActionPreparator.prepareLoginRadioActions();
}
});
});

