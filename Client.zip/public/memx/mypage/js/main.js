require([
'vp/alcor/control/TransitionManager',
'dojo/ready',
'vps/member/WebApiConst',
'vps/member/DefaultModules',
'dojo/parser'
], function(TransitionManager, ready, WebApiConst) {
TransitionManager.init({
webApiConst: WebApiConst,
lazyParsingMode: true,
acceptHash:[{
hash:'info',
contentWidgetName:'vp.member.pages.info',
history: function() {}
}]
});
});
