define([
'dojo/_base/array',
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom',
'dojo/query',
'dojo/text!./info.html',
'dijit/registry',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/ValueController',
'vpx/view/ActionPreparatorBr',
'vpx/view/MyPageViewPreparator',
'vpx/view/widget/MyPageInfoWidget',
'vpx/view/ValidationFactory',
'vpx/view/ValidationHandler',
'vps/member/WebApiConst',
'vp/alcor/control/StoreManager', 
'vp/alcor/view/FuncControl', 
'vp/alcor/view/Message',
'vp/alcor/constants/AlcorConstants',
'vpx/view/SystemInfo',
'vps/member/DropdownList',
'vps/member/EnableDeviceButton',
'vps/member/IncCommonFunctions',
'vp/member/pages/infoCommonPoint' 
], function(array, declare, lang, dom, query, templatePath, registry,
_AbstractPage, TransitionManager, ValueController,
ActionPreparator, MyPageViewPreparator, MyPageInfoWidget, ValidationFactory, ValidationHandler, WebApiConst, StoreManager, FuncControl, Message, AlcorConstants,
SystemInfo) {

function _getErrorMessage(str) {
var errMsg = '';
Message.getMessage({ msgKey: str }).then(
function(msg) {
errMsg = msg;
}
);
return errMsg != '';
}


return declare('vp.member.pages.info', [_AbstractPage], {

_equal: function(a, b) {
return a == b && !(a === "" && b === 0 || a === 0 && b === "");
},

_present: function(value) {
return value !== null && value !== undefined &&
value !== "" && (!lang.isArray(value) || value.length !== 0);
},

_isMessage: function(array) {
var retrunList = [];
var j = 0;
for(var i = 0; i < array.length; i++) {
if (_getErrorMessage(array[i])) {
retrunList[j] = {"msgkey": array[i]};
j++;
}
}
return retrunList;
},

templateString: templatePath,
preventScreenDataCache: true,
initTransitOptions: {
webApiId: WebApiConst.API.VC0104001_RS0004,
doMove: true,
error: function() {
StoreManager.putScreenData('__dummy__', {
TkImgLinkDisplayServiceBean: {}
});
}
},
cssClass: 'mainWidgetBase',
onBeforeScreenDataStored: function(content) {

if (content && content.NoticeMsgDisplayServiceBean) {
var bean = content.NoticeMsgDisplayServiceBean;

if (bean.msg3dSecureList) {
bean.msg3dSecureList = this._isMessage(bean.msg3dSecureList);
}
if (bean.msgAgreementLinkList) {
bean.msgAgreementLinkList = this._isMessage(bean.msgAgreementLinkList);
}
if (bean.msgCommonMsgList) {
bean.msgCommonMsgList = this._isMessage(bean.msgCommonMsgList);

if (bean.msgCommonMsgList.length !== 0){
bean._dispImportantMsgFlag = "1";
}
}
if (bean.msgEmailList) {
bean.msgEmailList = this._isMessage(bean.msgEmailList);
}
if (bean.msgKeisanList) {
bean.msgKeisanList = this._isMessage(bean.msgKeisanList);
}
if (bean.msgProviderList) {
bean.msgProviderList = this._isMessage(bean.msgProviderList);
}
if (bean.msgMobileEmailList) {
bean.msgMobileEmailList = this._isMessage(bean.msgMobileEmailList);
}
if (bean.msgCardCodeMsgList) {
bean.msgCardCodeMsgList = this._isMessage(bean.msgCardCodeMsgList);

if (bean.msgCardCodeMsgList.length !== 0){
bean._dispImportantMsgFlag = "1";
}
}
if (bean.msgSimpleMsgList) {
bean.msgSimpleMsgList = this._isMessage(bean.msgSimpleMsgList);

if (bean.msgSimpleMsgList.length !== 0){
bean._dispImportantMsgFlag = "1";
}
}
if (bean.msgNoticeInfoSASList) {
var retrunList = [];
var j = 0;
for(var i = 0; i < bean.msgNoticeInfoSASList.length; i++) {
retrunList[j] = {"msg": bean.msgNoticeInfoSASList[i]};
j++;
}
bean.msgNoticeInfoSASList = retrunList;
}
}

if (content && content.CampaignsInfoDisplayServiceBean) {
var bean = content.CampaignsInfoDisplayServiceBean;

if (bean.personalInfoList) {
var newPersonalInfoList = [];
for(var i = 0; i < bean.personalInfoList.length; i++) {
newPersonalInfoList[i] = {"bean": bean.personalInfoList[i]};
}
bean.personalInfoList = newPersonalInfoList;
}

if (bean.cardInfoList) {
var newCardInfoList = [];
for(var i = 0; i < bean.cardInfoList.length; i++) {
newCardInfoList[i] = {"bean": bean.cardInfoList[i]};
}
bean.cardInfoList = newCardInfoList;
}
if (bean.campaignInfoList) {
var newCampaignInfoList = [];
for(var i = 0; i < bean.campaignInfoList.length; i++) {
newCampaignInfoList[i] = {"bean": bean.campaignInfoList[i]};
}
bean.campaignInfoList = newCampaignInfoList;
}
}

if(content && content.MyInfoDisplayServiceBean) {
var bean = content.MyInfoDisplayServiceBean;

if(bean.meisaiList) {
var meisaiListCount = 0;
for(var i = 0; i < bean.meisaiList.length; i++) {
++meisaiListCount;
}
bean.meisaiListCount = meisaiListCount;
}

if(bean.grade === "my_BONUS_1.gif"){
bean.grade = "img_bonuspoint_v1.gif";
}else if(bean.grade === "my_BONUS_2.gif"){
bean.grade = "img_bonuspoint_v2.gif";
}else if(bean.grade === "my_BONUS_3.gif"){
bean.grade = "img_bonuspoint_v3.gif";
}

bean._dispSeikyuBtnFlag = "0";
if (!this._present(bean.seikyuFlag) && !this._present(bean.mainteErrorFlag) &&
this._equal(bean.seikyuPtn, "1")) {
bean._dispSeikyuBtnFlag = "1";
}

if (this._present(bean.mainteErrorFlag)) {
bean.seikyuExpectedDate = "";
bean.seikyuMsg = "";
}

var _nextYearMsgKeys = ["00.mypage.041", "00.mypage.043", "00.mypage.045", "00.mypage.047"];
bean._dispNextYearMsgFlag = array.some(_nextYearMsgKeys, function(key) {
return this._equal(bean.nextYearMsg, key);
}, this) ? "1" : "0";
bean._nextYearMsgArgs = this._equal(bean.nextYearMsg, "00.mypage.047") ? "" : bean.nextClassNeedMoney;

bean.seikyuExpectedDate_YYYYMMDD = bean.seikyuExpectedDate;

if (bean.seikyuExpectedDate) {
var seikyuDate =  bean.seikyuExpectedDate.split("/");
bean.seikyuExpectedDate = seikyuDate[1] + "月" + seikyuDate[2] + "日";
}

if (bean.tranDate) {
var tranDate =  bean.tranDate.split("年");
bean.wpTranDate = tranDate[1];
}
}

if (content && content.ButtonsDisplayServiceBean){
var bean = content.ButtonsDisplayServiceBean;
if (bean.bunnerButtonList) {
var newBunnerButtonList = [];
for(var i = 0; i < bean.bunnerButtonList.length; i++) {
newBunnerButtonList[i] = {"innerList": bean.bunnerButtonList[i]};
}
bean.bunnerButtonList = newBunnerButtonList;
}
}

if (content && content.CardAssortmentDisplayServiceBean) {
var bean = content.CardAssortmentDisplayServiceBean;
if (bean.cardAssortmentList) {
var cardAssortmentList = bean.cardAssortmentList;
var oldTitleCode = "";
var oldCardAssortmentListSize = 0;
for(var i = 0; i < cardAssortmentList.length; i++) {
var cardAssortmentListSize = bean.cardAssortmentList[i].length;
for(var j = 0; j < cardAssortmentListSize; j++) {
if (oldTitleCode !== cardAssortmentList[i][j].titleCode) {
cardAssortmentList[i][j].titleCodeFlag = "1";
if(oldTitleCode !== "") {
cardAssortmentList[i - 1][oldCardAssortmentListSize - 1].titleCodeButtonFlag = "1";
}else{
cardAssortmentList[i][cardAssortmentListSize-1].titleCodeButtonFlag = "1";

}
} else {
cardAssortmentList[i][j].titleCodeFlag = "0";
}
oldTitleCode = cardAssortmentList[i][j].titleCode;
oldCardAssortmentListSize = cardAssortmentListSize;
}
}

array.forEach(cardAssortmentList, function(itemList) {
array.forEach(itemList, function(item) {
item._dispInfoLinkFlag = "0";
if (!this._equal(item.titleUrl, "") && this._equal(item.titleDetailFlg, "1") && this._equal(item.titleCodeButtonFlag, "1")) {
item._dispInfoLinkFlag = "1";
}
}, this);
}, this);

var newCardAssortmentList = [];
for(var i = 0; i < bean.cardAssortmentList.length; i++) {
newCardAssortmentList[i] = {"innerList": bean.cardAssortmentList[i]};
}
bean.cardAssortmentList = newCardAssortmentList;
}
}

if (content && content.CorpCampaignsInfoDisplayServiceBean) {
var bean = content.CorpCampaignsInfoDisplayServiceBean;
if (bean.cardAssortmentList) {
var cardAssortmentList = bean.cardAssortmentList;
var oldTitleCode = "";
var oldCardAssortmentListSize = 0;
for(var i = 0; i < cardAssortmentList.length; i++) {
var cardAssortmentListSize = bean.cardAssortmentList[i].length;
for(var j = 0; j < cardAssortmentListSize; j++) {
if (oldTitleCode !== cardAssortmentList[i][j].titleCode) {
cardAssortmentList[i][j].titleCodeFlag = "1";
if(oldTitleCode !== "") {
cardAssortmentList[i - 1][oldCardAssortmentListSize - 1].titleCodeButtonFlag = "1";
}else{
cardAssortmentList[i][cardAssortmentListSize-1].titleCodeButtonFlag = "1";

}
} else {
cardAssortmentList[i][j].titleCodeFlag = "0";
}
oldTitleCode = cardAssortmentList[i][j].titleCode;
oldCardAssortmentListSize = cardAssortmentListSize;
}
}

array.forEach(cardAssortmentList, function(itemList) {
array.forEach(itemList, function(item) {
item._dispInfoLinkFlag = "0";
if (!this._equal(item.titleUrl, "") && this._equal(item.titleDetailFlg, "1") && this._equal(item.titleCodeButtonFlag, "1")) {
item._dispInfoLinkFlag = "1";
}
}, this);
}, this);

var newCardAssortmentList = [];
for(var i = 0; i < bean.cardAssortmentList.length; i++) {
newCardAssortmentList[i] = {"innerList": bean.cardAssortmentList[i]};
}
bean.cardAssortmentList = newCardAssortmentList;
}
}

if (content && content.CorpNoticeDisplayServiceBean) {
var bean = content.CorpNoticeDisplayServiceBean;
if (bean.cardAssortmentList) {
var cardAssortmentList = bean.cardAssortmentList;
var oldTitleCode = "";
var oldCardAssortmentListSize = 0;
for(var i = 0; i < cardAssortmentList.length; i++) {
var cardAssortmentListSize = bean.cardAssortmentList[i].length;
for(var j = 0; j < cardAssortmentListSize; j++) {
if (oldTitleCode !== cardAssortmentList[i][j].titleCode) {
cardAssortmentList[i][j].titleCodeFlag = "1";
if(oldTitleCode !== "") {
cardAssortmentList[i - 1][oldCardAssortmentListSize - 1].titleCodeButtonFlag = "1";
}else{
cardAssortmentList[i][cardAssortmentListSize-1].titleCodeButtonFlag = "1";

}
} else {
cardAssortmentList[i][j].titleCodeFlag = "0";
}
oldTitleCode = cardAssortmentList[i][j].titleCode;
oldCardAssortmentListSize = cardAssortmentListSize;
}
}

array.forEach(cardAssortmentList, function(itemList) {
array.forEach(itemList, function(item) {
item._dispInfoLinkFlag = "0";
if (!this._equal(item.titleUrl, "") && this._equal(item.titleDetailFlg, "1") &&  this._equal(item.titleCodeButtonFlag, "1")) {
item._dispInfoLinkFlag = "1";
}
}, this);
}, this);

var newCardAssortmentList = [];
for(var i = 0; i < bean.cardAssortmentList.length; i++) {
newCardAssortmentList[i] = {"innerList": bean.cardAssortmentList[i]};
}
bean.cardAssortmentList = newCardAssortmentList;
}
}

return content;
},
onStartup: function() {
var formId = 'FRM_c_U000100-0001';

var btnOff = dom.byId('pointDispOff');
this.onNode(btnOff, 'click', function() {
var postData = {'displayOnOff': '1'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0003, 
postData: postData,
doMove: true
});
});
var btnOn = dom.byId('pointDispOn');
this.onNode(btnOn, 'click', function() {
var postData = {'displayOnOff': '0'};
TransitionManager.transit({
webApiId: WebApiConst.API.VC0104001_RS0003, 
postData: postData,
doMove: true
});
});


var seikyuExpectedDate_YYYYMMDD=StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.MyInfoDisplayServiceBean.seikyuExpectedDate_YYYYMMDD;
var btn = dom.byId('vp-view-WebApiId_U000100_9');
this.onNode(btn, 'click', function() {
var p01Value = StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.dateReplaceBean.ExpectedDate;
if(seikyuExpectedDate_YYYYMMDD == "2021/3/1"){
p01Value = "202102";
}
TransitionManager.transit({
transitTo: '/memx/web_meisai/top/index.html?p01=' + p01Value, 
doMove: true
});
});
var btn = dom.byId('vp-view-WebApiId_U000100_9_3');
this.onNode(btn, 'click', function() {
var p01Value = StoreManager.fetchScreenData(WebApiConst.API.VC0104001_RS0004).data.dateReplaceBean.ExpectedDate;
if(seikyuExpectedDate_YYYYMMDD == "2021/3/1"){
p01Value = "202102";
}
TransitionManager.transit({
transitTo: '/memx/web_meisai/top/index.html?p01=' + p01Value, 
doMove: true
});
});
var select = query('[name="selectExt"]')[0];
this.onNode(select, 'change', function() {
TransitionManager.transit({
transitTo: '/memx/web_meisai/top/index.html?p01=' + select.value, 
doMove: true
});
});
var select2 = query('[name="selectExt2"]')[0];
this.onNode(select2, 'change', function() {
TransitionManager.transit({
transitTo: '/memx/web_meisai/top/index.html?p01=' + select2.value, 
doMove: true
});
});
var buttonNode = dom.byId('vp-view-VC0803-001_RS0001');
this.onNode(buttonNode, 'click', function() {
TransitionManager.transit({
transitTo: '/memx/wpc/shokai/index.html',
doMove: true
});
});

var idlink;
var bplink;
StoreManager.keyStorePromise.then(function(keyStore) {
idlink = keyStore.get(AlcorConstants.LINK_ID_PREFIX + '00.U000.idvalue') || {};
bplink = keyStore.get(AlcorConstants.LINK_ID_PREFIX + '00.U000.bonuspoint') || {};
}, function(err) {
});



ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareInputActions();
ActionPreparator.prepareAccordionSlideActions();
MyPageViewPreparator.initCampaignSlider();
MyPageViewPreparator.initMypageAdScroller();
SystemInfo.prepareSystemInfo();
}
});
});
