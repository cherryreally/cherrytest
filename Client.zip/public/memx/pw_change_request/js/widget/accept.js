define([
'dojo/_base/declare',
'dojo/io-query',
'vp/alcor/control/TransitionManager',
'vps/member/WebApiConst',
'dojo/text!./accept.html',
'vp/alcor/pages/_AbstractPage',
'vps/member/IncCommonFunctions'
], function(declare, ioQuery, TransitionManager, WebApiConst, temp, _AbstractPage) {
return declare('vp.member.pw.pages.accept', [_AbstractPage],
 {
templateString: temp,
constructor: function(){
var postData = {};
var tmpQuery = (location.href.split('?')[1] || '').split('#')[0] || '';
var query = ioQuery.queryToObject(tmpQuery);
if(query && query.strURL){
postData.url = query.strURL;
}
this.initTransitOptions.postData = postData;
},
initTransitOptions: {
webApiId: WebApiConst.API.VC0204001_RS0001,
doMove:true
}
});
});
