define([
], function() {

return {
init: function() {
this.name = window.navigator.userAgent.toLowerCase();
this.isIE = this.name.indexOf('msie') >= 0 || this.name.indexOf('trident') >= 0;
this.isChrome = this.name.indexOf('chrome') >= 0;
this.isFirefox = this.name.indexOf('firefox') >= 0;
this.isiPhone = this.name.indexOf('iphone') >= 0;
this.isiPod = this.name.indexOf('ipod') >= 0;
this.isiPad = this.name.indexOf('ipad') >= 0;
this.isiOS = this.isiPhone || this.isiPod || this.isiPad;
this.isAndroid = this.name.indexOf('android') >= 0;
this.isTablet = this.isiPad || (this.isAndroid && this.name.indexOf('mobile') < 0);
this.isTouchDevice = this.isiOS || this.isAndroid;
this.isSmartPhone = this.isiPhone || this.isiPod || (this.isAndroid && this.name.indexOf('mobile') >= 0);
if (this.isiOS) {
var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
this.iOSVersion = [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
}
if (this.isAndroid) {
var v = this.name.match(/android\s([0-9\.]*)/)[1].split('.');
this.AndroidVersion = [parseInt(v[0], 10), parseInt(v[1], 10), parseInt(v[2] || 0, 10)];
}
return this;
}
}.init();
});
