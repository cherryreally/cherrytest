define.amd.jQuery = true;
define([
'jquery',
'vpx/view/UserAgent'
], function($, UserAgent) {

function createObject(proto) {
function F() {}
F.prototype = proto;
return new F();
}


var MyPointerEventBase = {};
MyPointerEventBase.MYPOINTER_TYPE_MOUSE = 'mouse';
MyPointerEventBase.MYPOINTER_TYPE_TOUCH = 'touch';
MyPointerEventBase._getPointerType = function(event) {
return (event.pointerType !== undefined)
? event.pointerType : event.originalEvent.pointerType;
};
MyPointerEventBase.onTouchStart = function($target, handler) { return $target; };
MyPointerEventBase.offTouchStart = function($target) { return $target; };
MyPointerEventBase.onTouchEnd = function($target, handler) { return $target; };
MyPointerEventBase.offTouchEnd = function($target, handler) { return $target; };
MyPointerEventBase.onMouseEnter = function($target, handler) { return $target; };
MyPointerEventBase.offMouseEnter = function($target) { return $target; };
MyPointerEventBase.onMouseLeave = function($target, handler) { return $target; };
MyPointerEventBase.offMouseLeave = function($target) { return $target; };
MyPointerEventBase.onMouseClick = function($target, handler) { return $target; };
MyPointerEventBase.offMouseClick = function($target) { return $target; };


var MyPointerEvent_PointerEvent = createObject(MyPointerEventBase);
MyPointerEvent_PointerEvent.onTouchStart = function($target, handler) {
var self = this;
$target.on('pointerdown.MyPointerEvent.touchStart', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === 'touch' || pointerType === 'pen') {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_PointerEvent.offTouchStart = function($target) {
$target.off('pointerdown.MyPointerEvent.touchStart');
return $target;
};
MyPointerEvent_PointerEvent.onTouchEnd = function($target, handler) {
var self = this;
$target.on('pointerup.MyPointerEvent.touchEnd', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === 'touch' || pointerType === 'pen') {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_PointerEvent.offTouchEnd = function($target) {
$target.off('pointerup.MyPointerEvent.touchEnd');
return $target;
};
MyPointerEvent_PointerEvent.onMouseEnter = function($target, handler) {
var self = this;
$target.on('pointerenter.MyPointerEvent.mouseEnter', function(event) {
if (self._getPointerType(event) === 'mouse') {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_PointerEvent.offMouseEnter = function($target) {
$target.off('pointerenter.MyPointerEvent.mouseEnter');
return $target;
};
MyPointerEvent_PointerEvent.onMouseLeave = function($target, handler) {
var self = this;
$target.on('pointerleave.MyPointerEvent.mouseLeave', function(event) {
if (self._getPointerType(event) === 'mouse') {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_PointerEvent.offMouseLeave = function($target) {
$target.off('pointerleave.MyPointerEvent.mouseLeave');
return $target;
};
MyPointerEvent_PointerEvent.onMouseClick = function($target, handler) {
var self = this;
var lastMyPointerType;
$target.on('pointerup.MyPointerEvent.mouseClick', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === 'touch' || pointerType === 'pen') {
lastMyPointerType = self.MYPOINTER_TYPE_TOUCH;
} else {
lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
}
});
$target.on('click.MyPointerEvent.mouseClick', function(event) {
if (lastMyPointerType === self.MYPOINTER_TYPE_MOUSE) {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_PointerEvent.offMouseClick = function($target) {
$target.off('pointerup.MyPointerEvent.mouseClick');
$target.off('click.MyPointerEvent.mouseClick');
return $target;
};


var MyPointerEvent_MSPointerEvent = createObject(MyPointerEventBase);
MyPointerEvent_MSPointerEvent.onTouchStart = function($target, handler) {
var self = this;
$target.on('MSPointerDown.MyPointerEvent.touchStart', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === event.originalEvent.MSPOINTER_TYPE_TOUCH
|| pointerType === event.originalEvent.MSPOINTER_TYPE_PEN) {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_MSPointerEvent.offTouchStart = function($target) {
$target.off('MSPointerDown.MyPointerEvent.touchStart');
return $target;
};
MyPointerEvent_MSPointerEvent.onTouchEnd = function($target, handler) {
var self = this;
$target.on('MSPointerUp.MyPointerEvent.touchEnd', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === event.originalEvent.MSPOINTER_TYPE_TOUCH
|| pointerType === event.originalEvent.MSPOINTER_TYPE_PEN) {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_MSPointerEvent.offTouchEnd = function($target) {
$target.off('MSPointerUp.MyPointerEvent.touchEnd');
return $target;
};
MyPointerEvent_MSPointerEvent.onMouseEnter = function($target, handler) {
var self = this;
var lastMyPointerType;
$target.on('MSPointerOver.MyPointerEvent.mouseEnter MSPointerOut.MyPointerEvent.mouseEnter', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === event.originalEvent.MSPOINTER_TYPE_TOUCH
|| pointerType === event.originalEvent.MSPOINTER_TYPE_PEN) {
lastMyPointerType = self.MYPOINTER_TYPE_TOUCH;
} else {
lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
}
});
$target.on('mouseenter.MyPointerEvent.mouseEnter', function(event) {
if (lastMyPointerType === self.MYPOINTER_TYPE_MOUSE) {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_MSPointerEvent.offMouseEnter = function($target) {
$target.off('MSPointerOver.MyPointerEvent.mouseEnter MSPointerOut.MyPointerEvent.mouseEnter');
$target.off('mouseenter.MyPointerEvent.mouseEnter');
return $target;
};
MyPointerEvent_MSPointerEvent.onMouseLeave = function($target, handler) {
var self = this;
var lastMyPointerType;
$target.on('MSPointerOver.MyPointerEvent.mouseLeave MSPointerOut.MyPointerEvent.mouseLeave', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === event.originalEvent.MSPOINTER_TYPE_TOUCH
|| pointerType === event.originalEvent.MSPOINTER_TYPE_PEN) {
lastMyPointerType = self.MYPOINTER_TYPE_TOUCH;
} else {
lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
}
});
$target.on('mouseleave.MyPointerEvent.mouseLeave', function(event) {
if (lastMyPointerType === self.MYPOINTER_TYPE_MOUSE) {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_MSPointerEvent.offMouseLeave = function($target) {
$target.off('MSPointerOver.MyPointerEvent.mouseLeave MSPointerOut.MyPointerEvent.mouseLeave');
$target.off('mouseleave.MyPointerEvent.mouseLeave');
return $target;
};
MyPointerEvent_MSPointerEvent.onMouseClick = function($target, handler) {
var self = this;
var lastMyPointerType;
$target.on('MSPointerUp.MyPointerEvent.mouseClick', function(event) {
var pointerType = self._getPointerType(event);
if (pointerType === event.originalEvent.MSPOINTER_TYPE_TOUCH
|| pointerType === event.originalEvent.MSPOINTER_TYPE_PEN) {
lastMyPointerType = self.MYPOINTER_TYPE_TOUCH;
} else {
lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
}
});
$target.on('click.MyPointerEvent.mouseClick', function(event) {
if (lastMyPointerType === self.MYPOINTER_TYPE_MOUSE) {
return handler.apply(this, arguments);
}
});
return $target;
};
MyPointerEvent_MSPointerEvent.offMouseClick = function($target) {
$target.off('MSPointerUp.MyPointerEvent.mouseClick');
$target.off('click.MyPointerEvent.mouseClick');
return $target;
};


var MyPointerEvent_LegacyPC = createObject(MyPointerEventBase);
MyPointerEvent_LegacyPC.onMouseEnter = function($target, handler) {
$target.on('mouseenter.MyPointerEvent.mouseEnter', handler);
return $target;
};
MyPointerEvent_LegacyPC.offMouseEnter = function($target) {
$target.off('mouseenter.MyPointerEvent.mouseEnter');
return $target;
};
MyPointerEvent_LegacyPC.onMouseLeave = function($target, handler) {
$target.on('mouseleave.MyPointerEvent.mouseLeave', handler);
return $target;
};
MyPointerEvent_LegacyPC.offMouseLeave = function($target) {
$target.off('mouseleave.MyPointerEvent.mouseLeave');
return $target;
};
MyPointerEvent_LegacyPC.onMouseClick = function($target, handler) {
$target.on('click.MyPointerEvent.mouseClick', handler);
return $target;
};
MyPointerEvent_LegacyPC.offMouseClick = function($target) {
$target.off('click.MyPointerEvent.mouseClick');
return $target;
};


var MyPointerEvent_LegacyTouchDevice = createObject(MyPointerEventBase);
MyPointerEvent_LegacyTouchDevice.onTouchStart = function($target, handler) {
$target.on('touchstart.MyPointerEvent.touchStart', handler);
return $target;
};
MyPointerEvent_LegacyTouchDevice.offTouchStart = function($target) {
$target.off('touchstart.MyPointerEvent.touchStart');
return $target;
};
MyPointerEvent_LegacyTouchDevice.onTouchEnd = function($target, handler) {
$target.on('touchend.MyPointerEvent.touchEnd', handler);
return $target;
};
MyPointerEvent_LegacyTouchDevice.offTouchEnd = function($target, handler) {
$target.off('touchend.MyPointerEvent.touchEnd');
return $target;
};


var MyPointerEvent_NewerChrome = createObject(MyPointerEventBase);
MyPointerEvent_NewerChrome.onTouchStart = function($target, handler) {
$target.on('touchstart.MyPointerEvent.touchStart', handler);
return $target;
};
MyPointerEvent_NewerChrome.offTouchStart = function($target) {
$target.off('touchstart.MyPointerEvent.touchStart');
return $target;
};
MyPointerEvent_NewerChrome.onTouchEnd = function($target, handler) {
$target.on('touchend.MyPointerEvent.touchEnd', handler);
return $target;
};
MyPointerEvent_NewerChrome.offTouchEnd = function($target) {
$target.off('touchend.MyPointerEvent.touchEnd');
return $target;
};
MyPointerEvent_NewerChrome.onMouseEnter = function($target, handler) {
var self = this;
var lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
$target.on('touchend.MyPointerEvent.mouseEnter', function(event) {
lastMyPointerType = self.MYPOINTER_TYPE_TOUCH;
});
$target.on('mouseenter.MyPointerEvent.mouseEnter', function(event) {
if (lastMyPointerType === self.MYPOINTER_TYPE_MOUSE) {
return handler.apply(this, arguments);
}
lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
});
return $target;
};
MyPointerEvent_NewerChrome.offMouseEnter = function($target) {
$target.off('touchend.MyPointerEvent.mouseEnter');
$target.off('mouseenter.MyPointerEvent.mouseEnter');
return $target;
};
MyPointerEvent_NewerChrome.onMouseLeave = function($target, handler) {
$target.on('mouseleave.MyPointerEvent.mouseLeave', handler);
return $target;
};
MyPointerEvent_NewerChrome.offMouseLeave = function($target) {
$target.off('mouseleave.MyPointerEvent.mouseLeave');
return $target;
};
MyPointerEvent_NewerChrome.onMouseClick = function($target, handler) {
var self = this;
var lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
$target.on('touchend.MyPointerEvent.mouseClick', function(event) {
lastMyPointerType = self.MYPOINTER_TYPE_TOUCH;
});
$target.on('click.MyPointerEvent.mouseClick', function(event) {
if (lastMyPointerType === self.MYPOINTER_TYPE_MOUSE) {
return handler.apply(this, arguments);
}
lastMyPointerType = self.MYPOINTER_TYPE_MOUSE;
});
return $target;
};
MyPointerEvent_NewerChrome.offMouseClick = function($target) {
$target.off('touchend.MyPointerEvent.mouseClick');
$target.off('click.MyPointerEvent.mouseClick');
return $target;
};


var MyPointerEvent = {};
if (window.PointerEvent !== undefined) {
MyPointerEvent = MyPointerEvent_PointerEvent;
} else if ((window.MSPointerEvent !== undefined) && window.navigator.msPointerEnabled) {
MyPointerEvent = MyPointerEvent_MSPointerEvent;
} else {
if (UserAgent.isTouchDevice) {
MyPointerEvent = MyPointerEvent_LegacyTouchDevice;
} else {
MyPointerEvent = MyPointerEvent_LegacyPC;
}
}

return MyPointerEvent;
});
