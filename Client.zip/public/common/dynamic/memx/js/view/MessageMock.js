define([
'dojo/_base/declare'
], function(declare) {

return {
getMessage: function(params) {
return params.msgKey;
}
};
});
