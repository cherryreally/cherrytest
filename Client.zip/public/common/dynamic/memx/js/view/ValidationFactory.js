define([
'dojo/_base/declare',
'dojo/_base/array',
'dojo/query',
'vpx/view/MessageMock', 
'vp/alcor/view/inputcheck/AlcorValidators',
'app/common/js/validation/ValidationRegexpConst'
], function(declare, array, query, Message, AlcorValidators, ValidationRegexpConst) {

var MSGKEY_MAIN_MERCHANT_NUMBER8_FIGURES = '04.VE.E0000071';
var MSGKEY_MAIN_MERCHANT_NUMBER8_ATTRS = '04.VE.E0000072';

var MSGKEY_ACCOUNT_NUMBER_FIGURES = '04.VE.E0000088';
var MSGKEY_ACCOUNT_NUMBER_ATTRS = '04.VE.E0000089';

var MSGKEY_PERSON_NAME_KANJI_FIGURES = '04.VE.E0000107';
var MSGKEY_PERSON_NAME_KANJI_ATTRS = '04.VE.E0000108';

var MSGKEY_PERSON_NAME_KANA_FIGURES = '04.VE.E0000109';
var MSGKEY_PERSON_NAME_KANA_ATTRS = '04.VE.E0000110';

var MSGKEY_UNIT_NAME_KANJI_FIGURES = '04.VE.E0000125';
var MSGKEY_UNIT_NAME_KANJI_ATTRS = '04.VE.E0000126';

var MSGKEY_UNIT_NAME_KANA_FIGURES = '04.VE.E0000127';
var MSGKEY_UNIT_NAME_KANA_ATTRS = '04.VE.E0000128';

var MSGKEY_POST_NAME_KANJI_FIGURES = '04.VE.E0000129';
var MSGKEY_POST_NAME_KANJI_ATTRS = '04.VE.E0000130';

var MSGKEY_POST_NAME_KANA_FIGURES = '04.VE.E0000131';
var MSGKEY_POST_NAME_KANA_ATTRS = '04.VE.E0000132';

var MSGKEY_PHONE_NUMBER_UPPER5_FIGURES = '00.VC.E0000014';
var MSGKEY_PHONE_NUMBER_UPPER5_ATTRS1 = '00.VC.E0000015';
var MSGKEY_PHONE_NUMBER_UPPER5_ATTRS2 = '00.VC.E0000016';

var MSGKEY_PHONE_NUMBER_MIDDLE4_FIGURES = '00.VC.E0000017';
var MSGKEY_PHONE_NUMBER_MIDDLE4_ATTRS = '00.VC.E0000018';

var MSGKEY_PHONE_NUMBER_LOWER5_FIGURES = '00.VC.E0000019';
var MSGKEY_PHONE_NUMBER_LOWER5_ATTRS = '00.VC.E0000020';

var MSGKEY_PERSONAL_PHONE_NUMBER_UPPER5_FIGURES = '00.VC.E0000021';
var MSGKEY_PERSONAL_PHONE_NUMBER_UPPER5_ATTRS1 = '00.VC.E0000022';
var MSGKEY_PERSONAL_PHONE_NUMBER_UPPER5_ATTRS2 = '00.VC.E0000023';

var MSGKEY_PERSONAL_PHONE_NUMBER_MIDDLE4_FIGURES = '00.VC.E0000024';
var MSGKEY_PERSONAL_PHONE_NUMBER_MIDDLE4_ATTRS = '00.VC.E0000025';

var MSGKEY_PERSONAL_PHONE_NUMBER_LOWER5_FIGURES = '00.VC.E0000026';
var MSGKEY_PERSONAL_PHONE_NUMBER_LOWER5_ATTRS = '00.VC.E0000027';

var MSGKEY_EXT_PHONE_NUMBER_FIGURES = '04.VE.E0000084';
var MSGKEY_EXT_PHONE_NUMBER_ATTRS = '04.VE.E0000085';

var MSGKEY_FAX_NUMBER_UPPER5_FIGURES ='04.VE.E0000119';
var MSGKEY_FAX_NUMBER_UPPER5_ATTRS = '04.VE.E0000120';

var MSGKEY_FAX_NUMBER_MIDDLE4_FIGURES ='04.VE.E0000121';
var MSGKEY_FAX_NUMBER_MIDDLE4_ATTRS = '04.VE.E0000122';

var MSGKEY_FAX_NUMBER_LOWER5_FIGURES ='04.VE.E0000123';
var MSGKEY_FAX_NUMBER_LOWER5_ATTRS = '04.VE.E0000124';

var MSGKEY_EMAIL_ADDRESS_FIGURES = '00.VC.E0000030';
var MSGKEY_EMAIL_ADDRESS_ATTRS = '00.VC.E0000031';

var MSGKEY_HANDLE_NAME_FIGURES = '04.VE.E0000079';
var MSGKEY_HANDLE_NAME_ATTRS1 = '04.VE.E0000080';
var MSGKEY_HANDLE_NAME_ATTRS2 = '04.VE.E0000081';

var MSGKEY_ID_FIGURES = '04.VE.E0000073';
var MSGKEY_ID_ATTRS1 = '04.VE.E0000074';
var MSGKEY_ID_ATTRS2 = '04.VE.E0000075';
var MSGKEY_ID_ATTRS3 = '04.VE.E0000076';

var MSGKEY_PASSWORD_FIGURES = '00.VC.E0000028';
var MSGKEY_PASSWORD_ATTRS = '00.VC.E0000029';

var MSGKEY_TERM_OF_VALIDITY_MONTH_FIGURES = '00.VC.E0000005';
var MSGKEY_TERM_OF_VALIDITY_MONTH_ATTRS1 = '00.VC.E0000006';
var MSGKEY_TERM_OF_VALIDITY_MONTH_ATTRS2 = '00.VC.E0000007';

var MSGKEY_TERM_OF_VALIDITY_YEAR_FIGURES = '00.VC.E0000008';
var MSGKEY_TERM_OF_VALIDITY_YEAR_ATTRS = '00.VC.E0000009';

var MSGKEY_CVV2_FIGURES = '00.VC.E0000001';
var MSGKEY_CVV2_ATTRS = '00.VC.E0000002';

var MSGKEY_MEMBER_NUMBER_FIGURES = '00.VC.E0000047';
var MSGKEY_MEMBER_NUMBER_ATTRS = '00.VC.E0000048';

var MSGKEY_MEMBER_NUMBER4_FIGURES = '00.VC.E0000049';
var MSGKEY_MEMBER_NUMBER4_ATTRS = '00.VC.E0000050';

var MSGKEY_MEMBER_NUMBER_LOWER4_FIGURES = '00.VC.E0000003';
var MSGKEY_MEMBER_NUMBER_LOWER4_ATTRS = '00.VC.E0000004';

var MSGKEY_CARD_ENTRY_NUMBER_FIGURES = '00.VC.E0000003';
var MSGKEY_CARD_ENTRY_NUMBER_ATTRS = '00.VC.E0000052';

var MSGKEY_USER_ID_FIGURES = '00.VC.E0000053';
var MSGKEY_USER_ID_ATTRS = '00.VC.E0000054';

var MSGKEY_TERMINAL_ID_FIGURES = '00.VC.E0000055';
var MSGKEY_TERMINAL_ID_ATTRS = '00.VC.E0000056';

var MSGKEY_ZIP_NUMBER_UPPER3_FIGURES = '00.VC.E0000010';
var MSGKEY_ZIP_NUMBER_UPPER3_ATTRS = '00.VC.E0000011';

var MSGKEY_ZIP_NUMBER_LOWER4_FIGURES = '00.VC.E0000012';
var MSGKEY_ZIP_NUMBER_LOWER4_ATTRS = '00.VC.E0000013';

var MSGKEY_YEAR_FIGURES = '00.VC.E0000032';
var MSGKEY_YEAR_ATTRS = '00.VC.E0000033';

var MSGKEY_MONTH_FIGURES = '00.VC.E0000034';
var MSGKEY_MONTH_ATTRS1 = '00.VC.E0000035';
var MSGKEY_MONTH_ATTRS2 = '00.VC.E0000036';

var MSGKEY_DAY_FIGURES = '00.VC.E0000037';
var MSGKEY_DAY_ATTRS1 = '00.VC.E0000038';
var MSGKEY_DAY_ATTRS2 = '00.VC.E0000039';

var MSGKEY_MEMBER_HANDLE_NAME_FIGURES = 'MSGKEY_MEMBER_HANDLE_NAME_FIGURES';
var MSGKEY_MEMBER_HANDLE_NAME_ATTRS = '00.VC.E0000040';

var MSGKEY_PASSWORD_LENGTH1 = '00.VC0201001.EU0300052';
var MSGKEY_PASSWORD_LENGTH2 = '00.VC0201001.EU0300052';

var MSGKEY_QUANTITY_ATTRS = 'MSGKEY_QUANTITY_ATTRS';
var MSGKEY_QUANTITY_FIGURES = 'MSGKEY_QUANTITY_FIGURES';

var MSGKEY_PREMIUM_NUMBER_FIGURES = 'MSGKEY_PREMIUM_NUMBER_FIGURES';
var MSGKEY_PREMIUM_NUMBER_ATTRS = 'MSGKEY_PREMIUM_NUMBER_ATTRS';

var MSGKEY_CONTRACTOR_ADDRESS1_FIGURES = 'MSGKEY_CONTRACTOR_ADDRESS1_FIGURES';
var MSGKEY_CONTRACTOR_ADDRESS1_ATTRS = 'MSGKEY_CONTRACTOR_ADDRESS1_ATTRS';

var MSGKEY_CONTRACTOR_ADDRESS2_FIGURES = 'MSGKEY_CONTRACTOR_ADDRESS2_FIGURES';
var MSGKEY_CONTRACTOR_ADDRESS2_ATTRS = 'MSGKEY_CONTRACTOR_ADDRESS2_ATTRS';

var MSGKEY_REPORT_ADDRESS_NAME_FIGURES = 'MSGKEY_REPORT_ADDRESS_NAME_FIGURES';
var MSGKEY_REPORT_ADDRESS_NAME_ATTRS = 'MSGKEY_REPORT_ADDRESS_NAME_ATTRS';

var MSGKEY_PERSONAL_IDENTIFICATION_NUMBER4_FIGURES = 'MSGKEY_PERSONAL_IDENTIFICATION_NUMBER4_FIGURES';
var MSGKEY_PERSONAL_IDENTIFICATION_NUMBER4_ATTRS1 = 'MSGKEY_PERSONAL_IDENTIFICATION_NUMBER4_ATTRS1';
var MSGKEY_PERSONAL_IDENTIFICATION_NUMBER4_ATTRS2 = 'MSGKEY_PERSONAL_IDENTIFICATION_NUMBER4_ATTRS2';

var MSGKEY_MEMBER_ARBITRARY_ID_ATTRS1 = '00.VC.E0000044';
var MSGKEY_MEMBER_ARBITRARY_ID_ATTRS2 = '00.VC.E0000045';
var MSGKEY_MEMBER_ARBITRARY_ID_ATTRS3 = '00.VC.E0000046';

return {

createValidationRequired: function(node, msgKey) {

return {
node: node,
required: true,
missingMessage: Message.getMessage({ msgKey: msgKey })
};
},

createValidationRequiredRadio: function(node, msgKey) {

return {
node: node,
validator: function() {
var name = query('#' + node).attr('name');
var checkedNodeList = query('input[type="radio"][name="' + name + '"]').filter(function(node) {
return node.checked;
});
return checkedNodeList.length !== 0;
},
invalidMessage: Message.getMessage({ msgKey: msgKey })
};
},

createValidationRequiredCheckboxes: function(nodeList, msgKey) {

return {
node: nodeList[0],
validator: function() {
var checkedNodeList = new Array();
array.forEach(nodeList, function(node, i) {
if (query('#' + node).attr('checked') == 'true') {
checkedNodeList.push(node);
}
});
return checkedNodeList.length !== 0;
},
invalidMessage: Message.getMessage({ msgKey: msgKey })
};
},

createValidationListMainMerchantNumber8: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 8, maxLength: 8 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MAIN_MERCHANT_NUMBER8_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_NUMERICAL },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MAIN_MERCHANT_NUMBER8_ATTRS })
}
];
},

createValidationListAccountNumber: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 7, maxLength: 7 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ACCOUNT_NUMBER_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_NUMERICAL },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ACCOUNT_NUMBER_ATTRS })
}
];
},

createValidationListPersonNameKanji: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 25 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSON_NAME_KANJI_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_MULTIBYTECODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSON_NAME_KANJI_ATTRS })
}
];
},

createValidationListPersonNameKana: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 25 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSON_NAME_KANA_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_MULTIBYTECODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSON_NAME_KANA_ATTRS })
}
];
},

createValidationListUnitNameKanji: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 25 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_UNIT_NAME_KANJI_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_MULTIBYTECODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_UNIT_NAME_KANJI_ATTRS })
}
];
},

createValidationListUnitNameKana: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 25 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_UNIT_NAME_KANA_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_MULTIBYTECODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_UNIT_NAME_KANA_ATTRS })
}
];
},

createValidationListPostNameKanji: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 25 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_POST_NAME_KANJI_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_MULTIBYTECODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_POST_NAME_KANJI_ATTRS })
}
];
},

createValidationListPostNameKana: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 25 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_POST_NAME_KANA_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_MULTIBYTECODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_POST_NAME_KANA_ATTRS })
}
];
},

createValidationListZipNumberUpper3: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 3, maxLength: 3 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ZIP_NUMBER_UPPER3_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ZIP_NUMBER_UPPER3_ATTRS })
}
];
},


createValidationListZipNumberLower4: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 4, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ZIP_NUMBER_LOWER4_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ZIP_NUMBER_LOWER4_ATTRS })
}
];
},

createValidationListPhoneNumberUpper5: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 5 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PHONE_NUMBER_UPPER5_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PHONE_NUMBER_UPPER5_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_PHONE_REJECT_AREA_CODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PHONE_NUMBER_UPPER5_ATTRS2 }),
}
];
},

createValidationListPhoneNumberMiddle4: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PHONE_NUMBER_MIDDLE4_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PHONE_NUMBER_MIDDLE4_ATTRS })
}
];
},

createValidationListPhoneNumberLower5: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 5 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PHONE_NUMBER_LOWER5_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PHONE_NUMBER_LOWER5_ATTRS })
}
];
},

createValidationListExtPhoneNumber: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 10 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_EXT_PHONE_NUMBER_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_INNER_LINE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_EXT_PHONE_NUMBER_ATTRS })
}
];
},

createValidationListPersonalPhoneNumberUpper5: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 5 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSONAL_PHONE_NUMBER_UPPER5_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSONAL_PHONE_NUMBER_UPPER5_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_MOBILE_PHONE_AREA_CODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSONAL_PHONE_NUMBER_UPPER5_ATTRS2 }),
}
];
},

createValidationListPersonalPhoneNumberMiddle4: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSONAL_PHONE_NUMBER_MIDDLE4_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSONAL_PHONE_NUMBER_MIDDLE4_ATTRS })
}
];
},

createValidationListPersonalPhoneNumberLower5: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 5 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSONAL_PHONE_NUMBER_LOWER5_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PERSONAL_PHONE_NUMBER_LOWER5_ATTRS })
}
];
},

createValidationListFaxNumberUpper5: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 5 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_FAX_NUMBER_UPPER5_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_FAX_NUMBER_UPPER5_ATTRS })
}
];
},

createValidationListFaxNumberMiddle4: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_FAX_NUMBER_MIDDLE4_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_FAX_NUMBER_MIDDLE4_ATTRS })
}
];
},

createValidationListFaxNumberLower5: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 5 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_FAX_NUMBER_LOWER5_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_FAX_NUMBER_LOWER5_ATTRS })
}
];
},

createValidationListEmailAddress: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 80 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_EMAIL_ADDRESS_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkEmail,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_EMAIL_ADDRESS_ATTRS })
}
];
},

createValidationListHandleName: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 20 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_HANDLE_NAME_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_MULTIBYTECODE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_HANDLE_NAME_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { errIllegalEmailChar: true },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_HANDLE_NAME_ATTRS2 })
}
];
},

createValidationListID: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 8, maxLength: 16 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ID_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_ID_CHAR },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ID_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_ID_REJECT_ONLY_NUM },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ID_ATTRS2 })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_ID_REJECT_PATTERN },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_ID_ATTRS3 })
}
];
},

createValidationListMemberHandleName: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 60 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_HANDLE_NAME_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { errIllegalEmailChar: true },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_HANDLE_NAME_ATTRS })
}
];
},

createValidationListPassword: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 6, maxLength: 20 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PASSWORD_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkString,
constraints: { charType: AlcorValidators.REGEXP_NUMERICAL },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PASSWORD_ATTRS })
}
];
},

createValidationListPasswordLength1: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 6, maxLength: 20 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PASSWORD_LENGTH1 })
}
];
},
createValidationListPasswordLength2: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 6, maxLength: 20 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PASSWORD_LENGTH2 })
}
];
},
createValidationListMemberNumber4: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 4, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_NUMBER4_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_NUMBER4_ATTRS })
}
];
},

createValidationListMemberNumberLower4: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 4, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_NUMBER_LOWER4_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_NUMBER_LOWER4_ATTRS })
}
];
},

createValidationListCCV2: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 3, maxLength: 3 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_CVV2_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_CVV2_ATTRS })
}
];
},

createValidationListValidityYear: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_YEAR_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_EXPIRATION_MONTH_CHAR },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_YEAR_ATTRS })
}
];
},

createValidationListValidityMonth: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 2 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MONTH_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_EXPIRATION_MONTH_CHAR },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MONTH_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkNumber,
constraints: { minValue: 1, maxValue: 12 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MONTH_ATTRS2 })
}
];
},

createValidationListValidityDay: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 1, maxLength: 2 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_DAY_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_EXPIRATION_MONTH_CHAR },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_DAY_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkNumber,
constraints: { minValue: 1, maxValue: 31 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_DAY_ATTRS2 })
}
];
},

createValidationQuantity: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_QUANTITY_ATTRS })
},
{
node: node,
validator: AlcorValidators.checkNumber,
constraints: { minValue: 1, maxValue: 99 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_QUANTITY_FIGURES })
}
];
},

createValidationPremiumNumber: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 4, maxLength: 4 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PREMIUM_NUMBER_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkNumber,
invalidMessage: Message.getMessage({ msgKey: MSGKEY_PREMIUM_NUMBER_ATTRS })
}
];
},

createValidationListTermOfValidityYear: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 2, maxLength: 2 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_TERM_OF_VALIDITY_YEAR_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_EXPIRATION_MONTH_CHAR },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_TERM_OF_VALIDITY_YEAR_ATTRS })
}
];
},

createValidationListTermOfValidityMonth: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkLength,
constraints: { minLength: 2, maxLength: 2 },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_TERM_OF_VALIDITY_MONTH_FIGURES })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_EXPIRATION_MONTH_CHAR },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_TERM_OF_VALIDITY_MONTH_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_EXPIRATION_MONTH_RANGE },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_TERM_OF_VALIDITY_MONTH_ATTRS2 })
}
];
},


createValidationListMemberArbitraryID: function(node) {
return [
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_ID_CHAR },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_ARBITRARY_ID_ATTRS1 })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_ID_REJECT_ONLY_NUM },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_ARBITRARY_ID_ATTRS2 })
},
{
node: node,
validator: AlcorValidators.checkRegExp,
constraints: { regExp: ValidationRegexpConst.REGEXP_ID_REJECT_PATTERN },
invalidMessage: Message.getMessage({ msgKey: MSGKEY_MEMBER_ARBITRARY_ID_ATTRS3 })
}
];
}
};
});
