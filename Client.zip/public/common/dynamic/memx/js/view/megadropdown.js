define.amd.jQuery = true;
define([
'dojo/_base/declare',
'jquery',
'dojo/domReady!',
'vpx/view/JqueryOnOnlyOnce',
'vpx/view/jquery-ui.min',
'vpx/view/jquery.magnific-popup.min'
], function (declare, $, domReady) {

var $win = $(window);
var $doc = $(document);

function isSP() {
return 0 <= location.href.indexOf('/memx/sp/') || 0 <= location.href.indexOf('/memx_s/sp/');
}

function getCommonHeaderElem() {
return $('#Head #header');
}

var megaMenuSelector = '#Head .megaMenu';
function getMegaMenu() {
return $(megaMenuSelector);
}
var megaMenuItemsSelector = '#Head .megaMenu_item';
function getMegaMenuItems() {
return $(megaMenuItemsSelector);
}

function getSearchAreaElem() {
return $('#Head #searchArea');
}

function getHeaderOverlayElem() {
return $('#Head #header_overlay');
}

function getHeaderIDlineElem() {
return $('#Head .IDline');
}

function getHeaderMegaMenubtnElem() {
return $('#Head .megaMenubtn');
}

var subMenuDropdownSelector = '#Head .subMenu_dropdown';
function getSubMenuDropdownElem() {
return $(subMenuDropdownSelector);
}

if (isSP()) {
$doc.onOnlyOnce('click.subMenuItemMenu', '#Head .subMenu_item-menu', function () {
var $header = getCommonHeaderElem();
let $hamburgerMenuSp = $('.hamburgerMenuSp');
$header.toggleClass('isSpMenuOpen');
$('.jsAccordionToggle').toggleClass('notEvents');
$('.jsAccordionToggle' + '.jsAccordion_active').click();
if ($header.hasClass('isSpMenuOpen')) {
$hamburgerMenuSp.show();
setTimeout(function () { 
$hamburgerMenuSp.addClass('isOpenMegaMenu');
getHeaderOverlayElem().addClass('isShow'); 
getHeaderIDlineElem().addClass('IDline-openMenuFixed');
getHeaderMegaMenubtnElem().addClass('megaMenubtn-openMenuFixed');
}, 0);
} else {
$hamburgerMenuSp.removeClass('isOpenMegaMenu');
getHeaderOverlayElem().removeClass('isShow'); 
getHeaderIDlineElem().removeClass('IDline-openMenuFixed');
getHeaderMegaMenubtnElem().removeClass('megaMenubtn-openMenuFixed');
}
return false;
});

$doc.onOnlyOnce('transitionend.hamburgerMenuSp', '#Head .hamburgerMenuSp', function () {
let $this = $(this);
if (!$this.hasClass('isOpenMegaMenu')) {
$this.hide();
}
});
}

var setHoverTimeOut;
$doc.onOnlyOnce('mouseleave.megaMenu', megaMenuSelector, function () {
clearTimeout(setHoverTimeOut);
var $headerOverlay = getHeaderOverlayElem();
if ($headerOverlay.hasClass('isShow')) {
if (isSP() && $('.jsAccordion_active').length === 0) {
$headerOverlay.removeClass('isShow'); 
} else {
if (getSearchAreaElem().is(':hidden')) {
$headerOverlay.removeClass('isShow'); 
}
}
}
var $megaMenu_items = getMegaMenuItems();
$megaMenu_items.removeClass('megaMenu_item-isMenuOpen');
});

if (window.ontouchstart !== undefined) {
$('body').onOnlyOnce('touchstart.bodyOnOverlay', function (e) {
var $headerOverlay = getHeaderOverlayElem();
if ($headerOverlay.hasClass('isShow')) {
var $searchArea = getSearchAreaElem();
if (
!$searchArea.has(e.target).length &&
!$('.subMenu_item-search').has(e.target).length &&
!getMegaMenu().has(e.target).length
) {
if ($searchArea.is(':visible')) {
$searchArea.slideUp();
$headerOverlay.removeClass('isShow');
}
getMegaMenuItems().removeClass('megaMenu_item-isMenuOpen');
if (e.cancelable) {
e.preventDefault();
}
}
}
});
$doc.onOnlyOnce('click.megaMenuItems', megaMenuItemsSelector, function (e) {
if ($(e.target).hasClass('megaMenu_itemTitle')) {
var $this = $(this);
if ($this.hasClass('megaMenu_item-isMenuOpen')) {
if (getSearchAreaElem().is(':hidden')) {
getHeaderOverlayElem().removeClass('isShow'); 
}
$this.removeClass('megaMenu_item-isMenuOpen');
} else {
getMegaMenuItems().removeClass('megaMenu_item-isMenuOpen');
getHeaderOverlayElem().addClass('isShow'); 
$this.addClass('megaMenu_item-isMenuOpen');
}
return false;
}
});
} else {
$doc.onOnlyOnce('mouseenter.megaMenuItems', megaMenuItemsSelector, function () {
var $megaMenu_items = getMegaMenuItems();
var $this = $(this);
var wait = 400;
if ($this.siblings('.megaMenu_item-isMenuOpen').length) {
wait = 150;
}
setHoverTimeOut = setTimeout(function () { 
var camp_tab = document.querySelector(".linkMenu");
if ($this[0] != camp_tab) {
getHeaderOverlayElem().addClass('isShow'); 
} else if ($this[0] == camp_tab && getHeaderOverlayElem().hasClass('isShow') && getSearchAreaElem().is(':hidden')) {
getHeaderOverlayElem().removeClass('isShow');
}
$megaMenu_items.not($this).removeClass('megaMenu_item-isMenuOpen');
$this.addClass('megaMenu_item-isMenuOpen');
}, wait);
});
}

$doc.onOnlyOnce('click.subMenuItemSearch', '#Head .subMenu_item-search', function () {
var $searchArea = getSearchAreaElem();
var $headerOverlay = getHeaderOverlayElem();
var $megaMenu_items = getMegaMenuItems();
if ($searchArea.is(':visible')) { 
$headerOverlay.removeClass('isShow');
$searchArea.slideToggle('up');
$megaMenu_items.removeClass('megaMenu_item-isMenuOpen'); 
} else { 
$headerOverlay.addClass('isShow');
$searchArea.slideToggle('up');
}
return false;
});

$doc.onOnlyOnce('click.searchAreaOutside', function (e) {
var $searchArea = getSearchAreaElem();
var $headerOverlay = getHeaderOverlayElem();
if ($headerOverlay.hasClass('isShow')) {
if (!$searchArea.has(e.target).length &&
!$('.subMenu_item-search').has(e.target).length &&
!getMegaMenu().has(e.target).length) {
if ($searchArea.is(':visible')) { 
$searchArea.slideUp();
}
var $megaMenu_items = getMegaMenuItems();
$megaMenu_items.removeClass('megaMenu_item-isMenuOpen');
$headerOverlay.removeClass('isShow'); 
$('.hamburgerMenuSp').removeClass('isOpenMegaMenu');
getCommonHeaderElem().removeClass('isSpMenuOpen');
getHeaderIDlineElem().removeClass('IDline-openMenuFixed');
getHeaderMegaMenubtnElem().removeClass('megaMenubtn-openMenuFixed');
}
}
});

if (isSP()) {
$doc.onOnlyOnce('click.subMenuUserInfoTitle', '#Head .subMenu_userInfo_title', function () {
$doc.off('click.subMenuUserInfoTitle');
$(this).magnificPopup({
type: 'inline',
preloader: false,
showCloseBtn: false,
fixedContentPos: true,
fixedBgPos: false,
callbacks: {
beforeOpen: function () {
},
open: function () {
$('.js-modal_close').on('click', function (e) {
e.preventDefault();
$.magnificPopup.close();
});
}
},
}).trigger('click');
return false;
});
}

$doc.onOnlyOnce('click.subMenuDropdown', '#userInfo + span', function () {
getSubMenuDropdownElem().toggleClass('isShow');
});
$doc.onOnlyOnce('click.subMenuDropdownItemLink', '#Head .subMenu_dropdown_item_link', function (e) {
e.stopPropagation();
});

$doc.onOnlyOnce('click.subMenuDropdownOutside', function (e) {
$subMenu_dropdown = getSubMenuDropdownElem();
if (!$subMenu_dropdown.is(e.target)) {
if (!$subMenu_dropdown.has(e.target).length) {
$subMenu_dropdown.removeClass('isShow');
}
}
});

if (isSP()) {
$doc.onOnlyOnce('click.jsAccordionToggle', '#Head .jsAccordionToggle', function () {
$(this).next().slideToggle();
$(this).toggleClass('jsAccordion_active');
if ($(this).hasClass('jsAccordion_active')) {
$(this).parent('.megaMenu_item').css('border', 'none');
} else {
$(this).parent('.megaMenu_item').attr('style', '');
}

var $this = $(this);
if ($(this).hasClass('megaMenu_itemTitle')) {
$('.jsAccordion_active').not($this).next().slideToggle();
$('.jsAccordionToggle').not($this).removeClass('jsAccordion_active');
if ($(this).hasClass('jsAccordion_active')) {
getHeaderOverlayElem().addClass('isShow'); 
$(this).next().children().scrollTop(0);
var windowHeight = $(window).height();
var smbcLine_height = $('#smbcLine').outerHeight();
var header_height = $('#header').outerHeight();
var head_height = windowHeight - smbcLine_height - header_height;
$('.megaMenu_subMenu').css('max-height', head_height);
} else {
getHeaderOverlayElem().removeClass('isShow'); 
}
}
});
}
$doc.onOnlyOnce('click.megaMenu_subClsBtn', '#Head .megaMenu_subClsBtn', function () {
if (isSP()) {
$('.jsAccordion_active').click();
if (getHeaderOverlayElem().hasClass('isShow')) {
getHeaderOverlayElem().removeClass('isShow');
}
}
});

$doc.onOnlyOnce('click.membersService', '#Head .membersServic_buttonPC', function () {
$(this).closest('.membersService').toggleClass('opened');
return false;
});
$doc.onOnlyOnce('click.membersServiceOutside', function (e) {
if (!$(e.target).closest('.membersService').length) {
$('#Head .membersService.opened').removeClass('opened');
}
});

$win.onOnlyOnce('scroll.stickyHeader', function () {
var $header = getCommonHeaderElem();
var $headerParent = $header.parent();
var $scrollamount = isSP() ? $("#smbcLine").outerHeight() + $("#header > .headerInner").outerHeight() : $("#smbcLine").outerHeight();
var $stickyamount;
if ($(this).scrollTop() > $scrollamount) {
if (!$header.hasClass('header-fixed')) {
$headerParent.css('height', $headerParent.outerHeight());
$header.addClass('header-fixed');
$stickyamount = $('.megaMenubtn').outerHeight() + $('.IDline').outerHeight();
}

$header.css('left', - $win.scrollLeft());
} else {
$header.removeClass('header-fixed').css('left', '');
$headerParent.css('height', '');
$stickyamount = $('.megaMenubtn').outerHeight() + $('#header > .headerInner').outerHeight() + $('.IDline').outerHeight();
}
});

});
