﻿define.amd.jQuery = true;
define([
'dojo/_base/declare',
'jquery',
'dojo/request',
'dojo/json',
'vpx/view/TemporaryMeasures',
'vpx/view/JqueryTooltipster',
'vpx/view/JqueryOnOnlyOnce',
'vpx/view/jquery-ui.min',
'dojo/domReady!'
], function(declare, $, request, json, TemporaryMeasures) {

var ATTR_NAME_PLACEHOLDER = 'data-action-preparator-placeholder';

var ATTR_VALUE_PLACEHOLDER_HAS_FAKE = 'has_fake';

var ATTR_NAME_MEMBER_NUMBER_FOCUS_ID = 'data-action-preparator-member-number-focus-id';
var ATTR_NAME_MEMBER_NUMBER_FOCUS_NEXT = 'data-action-preparator-member-number-focus-next';

var ATTR_NAME_CLIP_TARGET_TITLE = 'data-action-preparator-clip-target-title';
var ATTR_NAME_CLIP_TARGET_TEXT = 'data-action-preparator-clip-target-text';
var ATTR_NAME_CLIP_TARGET_ID = 'data-action-preparator-clip-target-id';
var ATTR_NAME_CLIP_TARGET = 'data-action-preparator-clip-target';
var ATTR_NAME_CLIP_EDIT_METHOD = 'data-action-preparator-clip-edit-method';

var KEYCODE = {
SPACEBAR: 32
};

function _isIE() {
var ua = navigator.userAgent.toLowerCase();
return (ua.indexOf('msie') != -1) || (ua.indexOf('trident') != -1);
}

function _isIE8() {
var ua = navigator.userAgent;
var av = window.navigator.appVersion.toLowerCase();
return (ua.match(/msie/i) && av.indexOf('msie 8.') != -1);
}

function _isIE9() {
var ua = navigator.userAgent;
var av = window.navigator.appVersion.toLowerCase();
return (ua.match(/msie/i) && av.indexOf('msie 9.') != -1);
}

function _isIE10() {
var ua = navigator.userAgent;
var av = window.navigator.appVersion.toLowerCase();
return (ua.match(/msie/i) && av.indexOf('msie 10.') != -1);
}

function _isFirefox() {
var ua = navigator.userAgent.toLowerCase();
return (ua.indexOf('firefox') != -1);
}

function _isNumeric(keyCode) {
return ((keyCode >= 96 && keyCode <= 105) || (keyCode >= 48 && keyCode <= 57)) ? true : false;
}

function _prepareRadioButtons() {

function updateRadioButtonStyle($radio) {
if ($radio.prop('checked')) {
if ($radio.next().hasClass('default_radio')) {
$radio.next().addClass('default_radio_on').removeClass('default_radio');
}
if ($radio.next().hasClass('single_radio')) {
$radio.next().addClass('single_radio_on').removeClass('single_radio');
}
if (! $radio.next().hasClass('not_check_bg')) {
$radio.parent('div').addClass('js_add_check_bg');
}
} else {
if ($radio.next().hasClass('default_radio_on')) {
$radio.next().addClass('default_radio').removeClass('default_radio_on');
}
if ($radio.next().hasClass('single_radio_on')) {
$radio.next().addClass('single_radio').removeClass('single_radio_on');
}
if (! $radio.next().hasClass('not_check_bg')) {
$radio.parent('div').removeClass('js_add_check_bg');
}
}
var ua = navigator.userAgent;
if (ua.match(/Safari/) || ua.match(/Opera/) || ua.match(/Chrome/)) {
if ($radio.next('label').attr('for') != '') {
if ($radio.next('label').hasClass('default_radio')) {
$radio.addClass('default_input');
$radio.next('label').removeClass('default_radio').addClass('default_radio_2');
} else if ($radio.next('label').hasClass('default_radio_on')) {
$radio.addClass('default_input');
$radio.next('label').removeClass('default_radio_on').addClass('default_radio_2');
} else if ($radio.next('label').hasClass('single_radio')) {
$radio.addClass('single_input');
$radio.next('label').removeClass('single_radio').addClass('single_radio_2');
} else if ($radio.next('label').hasClass('single_radio_on')) {
$radio.addClass('single_input');
$radio.next('label').removeClass('single_radio_on').addClass('single_radio_2');
}
}
}
};

$('input[type=radio]').each(function() {
updateRadioButtonStyle($(this));
});

$(document).onOnlyOnce('change.prepareRadioButtons', 'input[type=radio]', function() {
$('input[type=radio][name=' + $(this).attr('name') + ']').each(function() {
updateRadioButtonStyle($(this));
});
});

if (_isIE8()) {
function getRadioButtonRelevantToLabel($label) {
var $radio = $('#' + $label.attr('for'));
return $radio.is('input[type=radio]') ? $radio : undefined;
}

$(document).onOnlyOnce('click.prepareRadioButtons', 'label', function() {
var $radio = getRadioButtonRelevantToLabel($(this));
if ($radio) {
$radio.prop('checked', true);
$('input[type=radio][name=' + $radio.attr('name') + ']').each(function() {
$(this).trigger('change');
});
}
});
}
}

function _prepareCheckBoxes() {

var ua = navigator.userAgent;
if (ua.match(/Safari/) || ua.match(/Opera/) || ua.match(/Chrome/)) {
$('input[type=checkbox]').each(function() {
if ($(this).next('label').attr('for') != '') {
if ($(this).next('label').hasClass('default_checkbox')) {
$(this).addClass('default_input');
$(this).next('label').removeClass('default_checkbox').addClass('default_checkbox_2');
} else if ($(this).next('label').hasClass('single_checkbox')) {
$(this).addClass('single_input');
$(this).next('label').removeClass('single_checkbox').addClass('single_checkbox_2');
} else if ($(this).next('label').hasClass('default_checkbox_on')) {
$(this).addClass('default_input');
$(this).next('label').removeClass('default_checkbox_on').addClass('default_checkbox_2');
} else if($(this).next('label').hasClass('single_checkbox_on')) {
$(this).addClass('single_input');
$(this).next('label').removeClass('single_checkbox_on').addClass('single_checkbox_2');
}
}
});
}

function updateCheckBoxStyle($checkbox) {
if ($checkbox.prop('checked')) {
if ($checkbox.next().hasClass('default_checkbox')) {
$checkbox.next().addClass('default_checkbox_on').removeClass('default_checkbox');
}
if ($checkbox.next().hasClass('single_checkbox')) {
$checkbox.next().addClass('single_checkbox_on').removeClass('single_checkbox');
}
if ($checkbox.parent('div').hasClass('attention_text_box')) {
$checkbox.parent('div').addClass('js_add_check_bg');
}
} else {
if ($checkbox.next().hasClass('default_checkbox_on')) {
$checkbox.next().addClass('default_checkbox').removeClass('default_checkbox_on');
}
if ($checkbox.next().hasClass('single_checkbox_on')) {
$checkbox.next().addClass('single_checkbox').removeClass('single_checkbox_on');
}
if ($checkbox.parent('div').hasClass('attention_text_box')) {
$checkbox.parent('div').removeClass('js_add_check_bg');
}
}
}

$('input[type=checkbox]').each(function() {
updateCheckBoxStyle($(this));
});

$(document).onOnlyOnce('change.prepareCheckBoxes', 'input[type=checkbox]', function() {
updateCheckBoxStyle($(this));
});

if (_isIE8()) {
function getCheckBoxRelevantToLabel($label) {
var $checkbox = $('#' + $label.attr('for'));
return $checkbox.is('input[type=checkbox]') ? $checkbox : undefined;
}

$(document).onOnlyOnce('click.prepareCheckBoxes', 'label', function() {
var $checkbox = getCheckBoxRelevantToLabel($(this));
if ($checkbox) {
$checkbox.prop('checked', !$checkbox.prop('checked'));
$checkbox.trigger('change');
}
});
}
}

function _prepareAllSelectionCheckBox(key, target) {

$(key).onOnlyOnce('change.prepareAllSelectionCheckBox', function() {
$(target).prop('checked', $(this).prop('checked')).trigger('change');
});
}

function _preparePlaceHolders() {

if (!(_isIE8() || _isIE9())) {
return;
}

var prepareFields = function($realField, $fakeField) {

if ($realField.is(':focus') && !$fakeField.is(':focus')) {
$realField.show();
$fakeField.hide();
} else if (!$realField.is(':focus') && $fakeField.is(':focus')) {
$realField.show();
$fakeField.hide();
$realField.focus();
} else {
if ($realField.val().length > 0) {
$realField.show();
$fakeField.hide();
} else {
$realField.hide();
$fakeField.show();
}
}
};

$('input[type=text], input[type=password]').each(function() {

$realField = $(this);

if (!$realField.attr('placeholder')) {
return;
}

if ($realField.attr(ATTR_NAME_PLACEHOLDER) == ATTR_VALUE_PLACEHOLDER_HAS_FAKE) {
return;
}

var $fakeField = $('<input type="text" readonly="readonly">');

if ($realField.attr('class')) {
$fakeField.addClass($realField.attr('class'));
}
if ($realField.attr('size')) {
$fakeField.attr('size', $realField.attr('size'));
}
if ($realField.attr('placeholder')) {
$fakeField.val($realField.attr('placeholder'));
}
if ($realField.attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_ID)) {
$fakeField.attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_ID, $realField.attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_ID));
}
if ($realField.attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_NEXT)) {
$fakeField.attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_NEXT, $realField.attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_NEXT));
}

if ($realField.attr('type') == 'text') {
$realField.attr(ATTR_NAME_PLACEHOLDER, ATTR_VALUE_PLACEHOLDER_HAS_FAKE);
$realField.addClass('ie_no_submit_target');
$fakeField.addClass('ie_no_readyonly');
$realField.after($fakeField);

} else if ($realField.attr('type') == 'password') {
$realField.attr(ATTR_NAME_PLACEHOLDER, ATTR_VALUE_PLACEHOLDER_HAS_FAKE);
$realField.addClass('ie_no_submit_target_pw');
$fakeField.addClass('ie_no_readyonly_pw');

var $wrapBlock = $('<div/>');
$wrapBlock.addClass('input_cell');
$wrapBlock.css('display', 'inline-block');
$realField.after($wrapBlock);
$wrapBlock.append($realField);
$wrapBlock.append($fakeField);
}

$realField.onOnlyOnce('focus.preparePlaceHolders blur.preparePlaceHolders change.preparePlaceHolders', function() {
prepareFields($(this), $(this).next('input'));
});
$realField.onOnlyOnce('propertychange.preparePlaceHolders', function(e) {
if (e.originalEvent.propertyName === "value") {
prepareFields($(this), $(this).next('input'));
}
});

$fakeField.onOnlyOnce('focus.preparePlaceHolders', function() {
prepareFields($(this).prev('input'), $(this));
});

prepareFields($realField, $fakeField);
});
}

function _prepareBalloon(target, message) {

if (_isIE8()) {
message =
'<div class="jq_balloon_parent">' +
'<div class="jq_balloon_arrow"></div>' +
'<div class="jq_balloon_obj">' + message + '</div>' +
'</div>';

$(target).onOnlyOnce('mouseenter.prepareBalloon', function() {
var pos = $(this).offset();
pos.top -= 10;
pos.left += 30;
$('body').append(message);
$('.jq_balloon_parent').css({
display : 'block',
top : pos.top + 'px',
left : pos.left + 'px' 
});

var thisWidth = $('.jq_balloon_parent').width();
var scrollLeft = parseInt($(window).scrollLeft());

$('.jq_balloon_parent').css('cssText', 'width:'+(thisWidth+scrollLeft)+'px !important; top:' + pos.top + 'px; left:'+pos.left + 'px; display:block');
});

$(target).onOnlyOnce('mouseleave.prepareBalloon', function() {
$('.jq_balloon_parent').remove();
});

$('.jq_balloon_parent').onOnlyOnce('click.prepareBalloon', function() {
$(this).remove();
});
} else {
$(target).attr('title', message);
}
}

function _prepareTooltipBalloon() {
request.get("/common/dynamic/memx/js/view/TooltipsBalloon.js", {
handleAs: 'json'
}).then(
function(data) {
$.each(data.Balloon, function(index, entry) {
_prepareBalloon("#"+entry.id, entry.message);
});
$('.tooltip').tooltipster();
},
function(error) {
console.log(error);
});
}

function _prepareClip() {

$('[id=fade_in_out_clip_pop]').on('click', function(e){
var id = $(this).attr(ATTR_NAME_CLIP_TARGET_ID);

var title = $('[' + ATTR_NAME_CLIP_TARGET_TITLE + "='" + id + "']").text();
var msg = title + "をコピーしました"

$('.jq_popup_parent').remove();

var pop = '<div class="jq_popup_parent">' +
'<div class="jq_popup_obj">' + msg + '</div>'+
'</div>'

$('body').append(pop);

var target = $(this).attr(ATTR_NAME_CLIP_TARGET);

var text

if (target == "children") {
text = $('[' + ATTR_NAME_CLIP_TARGET_TEXT + "='" + id + "']").children(":first").text();
} else {
text = $('[' + ATTR_NAME_CLIP_TARGET_TEXT + "='" + id + "']").text();
}

var method = $(this).attr(ATTR_NAME_CLIP_EDIT_METHOD);

if (method =="removespace") {
text = text.replace(/\s+/g, "");
}

if (_isIE()) {
window.clipboardData.setData('Text', text );
} else {
var ta = document.createElement("textarea");
ta.value = text;
document.body.appendChild(ta);
ta.select();
document.execCommand("copy");
ta.parentElement.removeChild(ta);
}

$('.jq_popup_parent').fadeIn("slow", function () {
$(this).delay(1000).fadeOut("slow");
});

return false;
});

$(document).onOnlyOnce('click.prepareClip', '.jq_popup_arrow input', function() {
$('.jq_popup_parent').remove();
});

}

function _prepareMemberNumberFocus() {

$('[' + ATTR_NAME_MEMBER_NUMBER_FOCUS_ID + ']').onOnlyOnce('keyup.prepareMemberNumberFocus', function(e) {

var value = $(this).val();
var next = $(this).attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_NEXT);

if (!_isNumeric(e.keyCode)
|| value.length < 4
|| value.match(/[^0-9]+/)
|| next === undefined) {
return;
}

$('[' + ATTR_NAME_MEMBER_NUMBER_FOCUS_ID + "='" + next + "']").focus();
});
}

function _passwordDisplay() {
var pwd = document.getElementById('vp-view-VC0201-001_RS0004_password');
var pwdCheck = document.getElementById('password_check');
if(pwdCheck) {
pwdCheck.addEventListener('change', function() {
if(pwdCheck.checked) {
pwd.setAttribute('type', 'text');
} else {
pwd.setAttribute('type', 'password');
}
}, false);
}
};

function _passwordDisplayPantel() {
var pwd = document.getElementById('vp-view-VC0201-001_RS0022_password');
var pwdCheck = document.getElementById('password_check_pantel');
if(pwdCheck) {
pwdCheck.addEventListener('change', function() {
if(pwdCheck.checked) {
pwd.setAttribute('type', 'text');
} else {
pwd.setAttribute('type', 'password');
}
}, false);
}
};

function _passwordDisplayRecreate() {
var pwd = document.getElementById('vp-view-VC0201-001_RS0012_password');
var pwdCheck = document.getElementById('password_check_recreate');
if(pwdCheck) {
pwdCheck.addEventListener('change', function() {
if(pwdCheck.checked) {
pwd.setAttribute('type', 'text');
} else {
pwd.setAttribute('type', 'password');
}
}, false);
}
};

function _passwordDisplayKakunin() {
var pwd = document.getElementById('vp-view-VC0201-001_RS0004_password_kakunin');
var pwdCheck = document.getElementById('password_check_kakunin');
if(pwdCheck) {
pwdCheck.addEventListener('change', function() {
if(pwdCheck.checked) {
pwd.setAttribute('type', 'text');
} else {
pwd.setAttribute('type', 'password');
}
}, false);
}
};

function _passwordDisplayKakuninPantel() {
var pwd = document.getElementById('vp-view-VC0201-001_RS0022_password_kakunin');
var pwdCheck = document.getElementById('password_check_kakunin_pantel');
if(pwdCheck) {
pwdCheck.addEventListener('change', function() {
if(pwdCheck.checked) {
pwd.setAttribute('type', 'text');
} else {
pwd.setAttribute('type', 'password');
}
}, false);
}
};

function _passwordDisplayKakuninRecreate() {
var pwd = document.getElementById('vp-view-VC0201-001_RS0012_password_kakunin');
var pwdCheck = document.getElementById('password_check_kakunin_recreate');
if(pwdCheck) {
pwdCheck.addEventListener('change', function() {
if(pwdCheck.checked) {
pwd.setAttribute('type', 'text');
} else {
pwd.setAttribute('type', 'password');
}
}, false);
}
};

function _prepareAutoZenkaku() {
$('.ActionAutoZenkaku').onOnlyOnce('blur.ActionAutoZenkaku', function () {
var str = $(this).val();

str = str.replace(/[!"#\$%&'\(\)\*\+,\-\.\/:;<=>\?@\[\\\]\^_`\{\|\}\dA-Za-z]/g, function (s) {
return String.fromCharCode(s.charCodeAt(0) + 0xFEE0);
});

var map = {
' ': '　', 
'~': '～', 
'｡': '。', '､': '、', 'ｰ': 'ー', '｢': '「', '｣': '」', '･': '・', 
'ｶﾞ': 'ガ', 'ｷﾞ': 'ギ', 'ｸﾞ': 'グ', 'ｹﾞ': 'ゲ', 'ｺﾞ': 'ゴ',
'ｻﾞ': 'ザ', 'ｼﾞ': 'ジ', 'ｽﾞ': 'ズ', 'ｾﾞ': 'ゼ', 'ｿﾞ': 'ゾ',
'ﾀﾞ': 'ダ', 'ﾁﾞ': 'ヂ', 'ﾂﾞ': 'ヅ', 'ﾃﾞ': 'デ', 'ﾄﾞ': 'ド',
'ﾊﾞ': 'バ', 'ﾋﾞ': 'ビ', 'ﾌﾞ': 'ブ', 'ﾍﾞ': 'ベ', 'ﾎﾞ': 'ボ',
'ﾊﾟ': 'パ', 'ﾋﾟ': 'ピ', 'ﾌﾟ': 'プ', 'ﾍﾟ': 'ペ', 'ﾎﾟ': 'ポ',
'ｳﾞ': 'ヴ', 'ﾜﾞ': 'ヷ', 'ｦﾞ': 'ヺ',
'ｱ': 'ア', 'ｲ': 'イ', 'ｳ': 'ウ', 'ｴ': 'エ', 'ｵ': 'オ',
'ｶ': 'カ', 'ｷ': 'キ', 'ｸ': 'ク', 'ｹ': 'ケ', 'ｺ': 'コ',
'ｻ': 'サ', 'ｼ': 'シ', 'ｽ': 'ス', 'ｾ': 'セ', 'ｿ': 'ソ',
'ﾀ': 'タ', 'ﾁ': 'チ', 'ﾂ': 'ツ', 'ﾃ': 'テ', 'ﾄ': 'ト',
'ﾅ': 'ナ', 'ﾆ': 'ニ', 'ﾇ': 'ヌ', 'ﾈ': 'ネ', 'ﾉ': 'ノ',
'ﾊ': 'ハ', 'ﾋ': 'ヒ', 'ﾌ': 'フ', 'ﾍ': 'ヘ', 'ﾎ': 'ホ',
'ﾏ': 'マ', 'ﾐ': 'ミ', 'ﾑ': 'ム', 'ﾒ': 'メ', 'ﾓ': 'モ',
'ﾔ': 'ヤ', 'ﾕ': 'ユ', 'ﾖ': 'ヨ',
'ﾗ': 'ラ', 'ﾘ': 'リ', 'ﾙ': 'ル', 'ﾚ': 'レ', 'ﾛ': 'ロ',
'ﾜ': 'ワ', 'ｦ': 'ヲ', 'ﾝ': 'ン',
'ｧ': 'ァ', 'ｨ': 'ィ', 'ｩ': 'ゥ', 'ｪ': 'ェ', 'ｫ': 'ォ',
'ｯ': 'ッ', 'ｬ': 'ャ', 'ｭ': 'ュ', 'ｮ': 'ョ'
};
str = str.replace(new RegExp('(' + Object.keys(map).join('|') + ')', 'g'), function (match) {
return map[match];
});

$(this).val(str);
});
}

function _prepareDatepicker() {
$('.ActionDatepicker').each(function (idx, elem) {
var $elem = $(elem);
var options = {
buttonImage: '/common/dynamic/memx/img/icon-calendar.png', 
buttonText: 'カレンダーから選択する', 
buttonImageOnly: true, 
showOn: 'button', 
dateFormat: 'yymmdd' 
};

var minDays = $elem.attr('data-datepicker-min-days');
if (minDays !== undefined && minDays !== '') {
var minDate = new Date();
minDate.setDate(minDate.getDate() - parseInt(minDays));
options.minDate = minDate;
}

var maxDays = $elem.attr('data-datepicker-max-days');
if (maxDays !== undefined && maxDays !== '') {
var maxDate = new Date();
maxDate.setDate(maxDate.getDate() + parseInt(maxDays));
options.maxDate = maxDate;
}

$elem.datepicker(options);
});
}

function _prepareFollowBtnArea() {
var key = 'followBtnArea';
var target = $(document).find(".followBtnArea");
if (!target.length) {
return;
}
if(sessionStorage.getItem(key)){
target.hide();
} else {
target.show();
}
$(document).find(".followBtnArea_cloase").on("click",function(){
sessionStorage.setItem(key, 'hide');
target.hide();
});
}

function _prepareModalwindow() {
$('.js-modal-open').each(function(){
$(this).on('click',function(){
var target = $(this).data('target');
var modal = document.getElementById(target);
$(modal).fadeIn();
return false;
});
});
$('.js-modal-close').on('click',function(){
$('.js-modal').fadeOut();
return false;
}); 
$('.modalWrap .modalBtnClose').on('click',function(){
$('.js-modal').fadeOut();
return false;
}); 
}

function _adaptModalShift(target, btn) {

btn.onOnlyOnce('click.adaptModalShift', function() {
target.fadeIn();

var win = $(window).height();
var mHeight = target.children().height();
if (win > mHeight) {
var thisPos = ((win - mHeight) / 2) - 40;
} else {
var thisPos = 10;
}

target.children().css({marginTop:thisPos});

});

$('.close_btn').onOnlyOnce('click.adaptModalShift', function() {
target.fadeOut();
});
}

function _searchAreaToggle(_target, _e) {
var speed = 200;
if ($(_target).hasClass('btnClose')) {
_target = $("#header .btnSearch").get(0);
}
$(_target).toggleClass('active');
if ($(_target).hasClass('active')) {
$('#searchArea').slideDown(speed);
}else{
$('#searchArea').slideUp(speed);
}
}

function SmoothScroll(_target, _e) {
var speed, href, target, position;
speed = 500;
href = $(_target).attr('href');
target = $(href == "#" || href == "" ? 'html' : href);
position = target.offset().top;

$('html, body').animate({
scrollTop: position
}, speed, "swing");
return false;
}

var ADJUSTING_SPAN_OF_SCROLL_LOCATION = 40; 
var CAMPAIGN_CONTENTS_WRAP_PADDING_TOP = 20; 
var SCROLLING_TIME = 500; 

var stickyHeaderLocation;

function adjustCampaignContentsWrapPadding() {
$('.ActionCampaignContentsWrap').css('paddingTop', getStickyHeaderHeight() + CAMPAIGN_CONTENTS_WRAP_PADDING_TOP + 'px');
}

function getStickyHeaderHeight() {
return $('.ActionStickyHeader').height();
}

function getContentEndLocation() {
var $campaignContentsWrap = $('.ActionCampaignContentsWrap');
return $campaignContentsWrap.height() + $campaignContentsWrap.offset().top;
}

function getHeaderHeight() {
var $header = $('#header');
var $headerContent = $header.find('div.rwdLeft');
if(0 < $headerContent.length) {
return $header.outerHeight(true);
} else {
return 0;
}
}

function cloneStickyHeader() {
var $stickyHeader = $('.ActionStickyHeader');
var $clonedHeader = $('.ActionCloned');
var currentScroll = $(window).scrollTop();
if($stickyHeader.length <= 1 && $clonedHeader.length < 1 && 0 < currentScroll) {
$stickyHeader.clone(true).insertAfter($stickyHeader).removeClass('ActionStickyHeader').addClass('ActionCloned').css('zIndex', '-1');
$('.ActionCloned .ActionContentHeader').removeClass('ActionContentHeader');
}
}

function getStickyHeaderLocation() {
return $('.ActionCampaignContentsWrap').offset().top - getHeaderHeight();
}


function switchStickyHeaderState() {
var $stickyHeader = $('.ActionStickyHeader');
var currentScrollTop = $(window).scrollTop();

if(stickyHeaderLocation <= currentScrollTop) {
$stickyHeader.addClass('act');
} else {
$stickyHeader.removeClass('act');
$stickyHeader.attr('style', '');
}
}


function switchActiveStateOfStickyHeadLink() {
var $stickyHeaderLinks = $('.ActionStickyHeader').find('.ActionContentHeader');

var $contents = $('.ActionContent');
var eachContentsPosition = [];
$contents.each(function(index) {
eachContentsPosition[index] = $(this).offset().top;
});

var currentScrollTop = $(window).scrollTop();
var offset = (getStickyHeaderHeight() + getHeaderHeight() + ADJUSTING_SPAN_OF_SCROLL_LOCATION);

$stickyHeaderLinks.removeClass('act');
for(var i = 0; i < $stickyHeaderLinks.length + 1; ++i) {
if(i !== $stickyHeaderLinks.length) {
if(currentScrollTop < eachContentsPosition[i] - offset) {
if(i !== 0) {
$stickyHeaderLinks.eq(i - 1).addClass('act');
}
break;
}
} else if(currentScrollTop < getContentEndLocation() - getStickyHeaderHeight() - ADJUSTING_SPAN_OF_SCROLL_LOCATION) {
$stickyHeaderLinks.eq(i - 1).addClass('act');
break;
}
}
}

function adjustStickyHeaderLocation() {
var $stickyHeaderAct = $('.ActionStickyHeader.act');
var $baseContent = $('.wrapper .wrap_inner div.container .cont_inner');
var baseContentOffset = $baseContent.offset().left;
var leftValue = baseContentOffset + 'px';
$stickyHeaderAct.css('left', leftValue);
}

function _syncCheck($org) {
$('.ActionSyncCheckbox[data-action-sync-group="' + $org.attr('data-action-sync-group') + '"]:checkbox').prop('checked', $org.prop('checked'));
}
function _allCheck() {
$('.ActionAllCheckTarget').prop('disabled', $('.ActionAllCheckCheckbox:checkbox:checked').length != $('.ActionAllCheckCheckbox:checkbox').length);
}

return {

prepareLoginRadioActions: function() {
},

prepareAccordionActions: function() {
},

prepareInputActions: function() {
if ($('input[type=radio]').length > 0) {
_prepareRadioButtons();
}

if ($('input[type=checkbox]').length > 0) {
_prepareCheckBoxes();
}

if ($('.all_check').length > 0) {
_prepareAllSelectionCheckBox('.all_check', '.with_check');
}

if ($('input[type=text], input[type=password]').length > 0) {
_preparePlaceHolders();
}
_prepareTooltipBalloon();

_prepareMemberNumberFocus();

_passwordDisplay();
_passwordDisplayPantel();
_passwordDisplayRecreate();

_passwordDisplayKakunin();
_passwordDisplayKakuninPantel();
_passwordDisplayKakuninRecreate();

_prepareClip();

_prepareAutoZenkaku();

_prepareDatepicker();

TemporaryMeasures.setTemporaryMeasures();

_prepareFollowBtnArea();

_prepareModalwindow();

$('.ActionSyncCheckbox:checkbox').onOnlyOnce('change.prepareSyncCheck', function () {
_syncCheck($(this));
});
$('.ActionAllCheckCheckbox:checkbox').onOnlyOnce('change.prepareAllCheck', function () {
_allCheck();
});
_syncCheck($('.ActionSyncCheckbox:checkbox:eq(0)'));
_allCheck();
},

prepareAccordionSlideActions: function() {

$('span.on').parents('div').children('.acdiBody').hide();
$('span.off').parents('div').children('.acdiBody').show();
$('.default_radio').closest('li').next('.changePanel').hide();
$('.default_radio_2').closest('li').next('.changePanel').hide();
$('.default_checkbox').closest('li').next('.changePanel').hide();
$('.default_checkbox_2').closest('li').next('.changePanel').hide();
$('tr.slide_tr').hide();

if (_isIE8() || _isIE9()) {
$(document).onOnlyOnce('click.prepareAccordionSlideActions', 'p', function() {
if ($(this).children('span.acdiBtn').hasClass('on')) {
$(this).attr('class', $(this).attr('class').replace('acid_on', 'acid_off'));
if ($(this).children('span.acdiBtn').length > 0) {
$(this).children('span.acdiBtn').attr('class', $(this).children('span.acdiBtn').attr('class').replace('on', 'off'));
$(this).children('span.acdiBtn').text( '表示しない');
$(this).children('span.acdiBtn').closest('div').children('.acdiBody').show();
}
} else if ($(this).children('span.acdiBtn').hasClass('off')) {
$(this).attr('class', $(this).attr('class').replace('acid_off', 'acid_on'));
if ($(this).children('span.acdiBtn').length > 0) {
$(this).children('span.acdiBtn').attr('class', $(this).children('span.acdiBtn').attr('class').replace('off', 'on'));
$(this).children('span.acdiBtn').text( '表示する');
$(this).children('span.acdiBtn').closest('div').children('.acdiBody').hide();
}
}
});

$(document).onOnlyOnce('click.prepareAccordionSlideActions', 'span', function(e) {
$tishSpan = $(this);
if ($(this).hasClass('on')) {
e.stopPropagation();
if ($(this).parents('.acdiCrt').length > 0) {
$(this).parents('.acdiCrt').attr('class', $(this).parents('.acdiCrt').attr('class').replace('acid_on', 'acid_off'));
}
$(this).attr('class', $(this).attr('class').replace('on', 'off'));
$(this).text( '表示しない');
$(this).closest('div').children('.acdiBody').show();
} else if ($(this).hasClass('off')) {
e.stopPropagation();
if ($(this).parents('.acdiCrt').length > 0) {
$(this).parents('.acdiCrt').attr('class', $(this).parents('.acdiCrt').attr('class').replace('acid_off', 'acid_on'));
}
$(this).attr('class', $(this).attr('class').replace('off', 'on'));
$(this).text( '表示する');
$(this).closest('div').children('.acdiBody').hide();
}
});

} else {
$(document).onOnlyOnce('click.prepareAccordionSlideActions', 'p', function() {
if ($(this).children('span.acdiBtn').hasClass('on')) {
$(this).attr('class', $(this).attr('class').replace('acid_on', 'acid_off'));
if ($(this).children('span.acdiBtn').length > 0) {
$(this).children('span.acdiBtn').attr('class', $(this).children('span.acdiBtn').attr('class').replace('on', 'off'));
$(this).children('span.acdiBtn').text( '表示しない');
$(this).children('span.acdiBtn').css('opacity', '1');
$(this).children('span.acdiBtn').closest('div').children('.acdiBody').slideDown();
}
} else if ($(this).children('span.acdiBtn').hasClass('off')) {
$(this).attr('class', $(this).attr('class').replace('acid_off', 'acid_on'));
if ($(this).children('span.acdiBtn').length > 0) {
$(this).children('span.acdiBtn').attr('class', $(this).children('span.acdiBtn').attr('class').replace('off', 'on'));
$(this).children('span.acdiBtn').text( '表示する');
$(this).children('span.acdiBtn').css('opacity', '1');
$(this).children('span.acdiBtn').closest('div').children('.acdiBody').slideUp();
}
}
});

$(document).onOnlyOnce('click.prepareAccordionSlideActions', 'span', function(e) {
if ($(this).hasClass('on')) {
e.stopPropagation();
if ($(this).parents('.acdiCrt').length > 0) {
$(this).parents('.acdiCrt').attr('class', $(this).parents('.acdiCrt').attr('class').replace('acid_on', 'acid_off'));
}
$(this).attr('class', $(this).attr('class').replace('on', 'off'));
$(this).text( '表示しない');
$(this).css('opacity', '1');
$(this).closest('div').children('.acdiBody').slideDown();
} else if ($(this).hasClass('off')) {
e.stopPropagation();
if ($(this).parents('.acdiCrt').length > 0) {
$(this).parents('.acdiCrt').attr('class', $(this).parents('.acdiCrt').attr('class').replace('acid_off', 'acid_on'));
}
$(this).attr('class', $(this).attr('class').replace('off', 'on'));
$(this).text( '表示する');
$(this).css('opacity', '1');
$(this).closest('div').children('.acdiBody').slideUp();
}
});

$(document).onOnlyOnce('mouseenter.prepareAccordionSlideActions', 'span', function() {
if ($(this).hasClass('on') || $(this).hasClass('off')) {
$(this).css('opacity', '0.7');
}
});
$(document).onOnlyOnce('mouseleave.prepareAccordionSlideActions', 'span', function() {
if ($(this).hasClass('on') || $(this).hasClass('off')) {
$(this).css('opacity', '1');
}
});
}

function updateSlideAlongWithCheckBox($checkBox, duration) {
var $panel = $checkBox.closest('li').next('li.changePanel');
if ($checkBox.prop('checked')) {
$panel.slideDown(duration);
} else {
$panel.slideUp(duration);
}
}

$('input[type=checkbox]').each(function() {
updateSlideAlongWithCheckBox($(this), 0);
});

$('input[type=checkbox]').onOnlyOnce('change.prepareAccordionSlideActions', function() {
updateSlideAlongWithCheckBox($(this));
});

function updateSlideAlongWithCheckBoxByAttrData($checkBox, duration) {
var $panel = $checkBox.closest('body').find('[data-slide-name="' + $checkBox.data('slide-target') + '"]');
if ($checkBox.css('display') !== 'block') {
duration = 0;
}
if ($checkBox.prop('checked')) {
$panel.slideDown(duration);
} else {
$panel.slideUp(duration);
}
}

$('[data-slide-target]:checkbox').each(function() {
updateSlideAlongWithCheckBoxByAttrData($(this), 0);
});

$('[data-slide-target]:checkbox').onOnlyOnce('change.prepareAccordionSlideActionsFromAttrData', function() {
updateSlideAlongWithCheckBoxByAttrData($(this));
});

function updateSlideAlongWithRadio($radio, duration) {
var $panel = $radio.closest('li').next('li.changePanel');
if ($radio.prop('checked')) {
$panel.slideDown(duration);
} else {
$panel.slideUp(duration);
}
}

$('input[type=radio]').each(function() {
updateSlideAlongWithRadio($(this), 0);
});

$('input[type=radio]').onOnlyOnce('change.prepareAccordionSlideActions', function() {
$('input[type=radio][name=' + $(this).attr('name') + ']').each(function() {
updateSlideAlongWithRadio($(this));
});
});

function updateSlideAlongWithRadioByAttrData($radio, duration) {
var $panel = $('[data-slide-name="' + $radio.data('slide-target') + '"]');
var displayFlg = $radio.data('slide-display-flg');
if (displayFlg) {
$panel.each(function() {
if ($(this).css('visibility') == 'hidden') {
$(this).css({
'visibility': '',
'position': ''
}).hide().slideDown(duration);
}
});
} else {
$panel.slideUp(duration, function() {
$panel.css({
'visibility': 'hidden',
'position': 'absolute'
}).show();
});
}
}

$('input[type=radio][data-slide-target][data-slide-display-flg]:checked').each(function() {
updateSlideAlongWithRadioByAttrData($(this), 0);
});

$('input[type=radio][data-slide-target][data-slide-display-flg]').onOnlyOnce('change.prepareAccordionSlideActionsFromAttrData', function() {
updateSlideAlongWithRadioByAttrData($(this));
});

if ($('input[type=radio][data-slide-target][data-slide-display-flg]').size()) {
$('[data-slide-name] .validate_error_line').each(function() {
var target = this;
var observer = new MutationObserver(function() {
if ($(target).text().trim().length) {
$(target).closest('[data-slide-name]').css({
'visibility': '',
'position': ''
}).show();
}
});
observer.observe(target, {childList: true, subtree: true});
});
$('[data-slide-name] input').onOnlyOnce('invalid.prepareAccordionSlideActionsFromAttrData', function() {
$(this).closest('[data-slide-name]').css({
'visibility': '',
'position': ''
}).show();
});
}

},
prepareButtonLineFeedActions: function() {
var userAgent = window.navigator.userAgent.toLowerCase();
var appVersion = window.navigator.appVersion.toLowerCase();

var browser = '';
if (userAgent.indexOf('msie') != -1) {
browser = 'ie';
}
else if (userAgent.indexOf('chrome') != -1) {
browser = 'another';
}
else if (userAgent.indexOf('safari') != -1) {
browser = 'another';
}
else if (userAgent.indexOf('firefox') != -1) {
browser = 'another';
}
else if (userAgent.indexOf('opera') != -1) {
browser = 'another';
}
else {
browser = 'unown';
}

$.fn.textWidth = function() {
var _t = $(this);
var html_org = _t.html();
if (_t[0].nodeName=='INPUT') {
html_org = _t.val();
}
var html_calcS = '<span>' + html_org + '</span>';
$('body').append(html_calcS);
var _lastspan = $('span').last();
_lastspan.css({
'font-size'  : _t.css('font-size'),
'font-family': _t.css('font-family')
});
var width =_lastspan.width()+3.8;
_lastspan.remove();
return width;
};

function rensoku(text, input, cnt) {
var output_text = text;
var pre_space = '';
var nex_space = '';
for (var i=0; i<=cnt/2; i++) {
pre_space += input;
}
for (var i=0; i<=cnt/2; i++) {
nex_space += input;
}
return pre_space + output_text + nex_space;
}

function buttonLineFeed(input_this) {
$this = input_this;
var b_value      = $this.val();
var b_width      = $this.width();
var b_font_width = $this.textWidth();
var b_space_size = $this.val(' ').textWidth();
var b_val_split  = b_value.split('<lf>');
var out_val      = '';
var input_space  = '';
for (var cnt=0; cnt<b_val_split.length; cnt++) {
var split_val_size = $this.val(b_val_split[cnt]).textWidth();
if (b_width > split_val_size) {
var in_space_size = 0;
if ((b_width-split_val_size)%b_space_size == 0) {
in_space_size = (b_width-split_val_size)/b_space_size;
}
else {
in_space_size = ((b_width-split_val_size) - ((b_width-split_val_size)%b_space_size))/b_space_size;
in_space_size+=1;
}
if (cnt == b_val_split.length-1) {
in_space_size = 0;
}
out_val += rensoku(b_val_split[cnt], ' ', in_space_size);
}
}
$this.css('word-wrap', 'break-word');
$this.val(out_val);
};

$('input[type=button]').each(function() {
if ($(this).val().indexOf('<lf>') != -1 && $(this).hasClass('btn_big_size')) {
if (browser == 'ie') {
buttonLineFeed($(this));
}
if (browser == 'another') {
$(this).val($(this).val().replace('<lf>', '\n'));
}
if (browser == 'unown') {
buttonLineFeed($(this));
}
}
});
$('input[type=submit]').each(function() {
if ($(this).val().indexOf('<lf>') != -1 && $(this).hasClass('btn_big_size')) {
if (browser == 'ie') {
buttonLineFeed($(this));
}
if (browser == 'another') {
$(this).val($(this).val().replace('<lf>', '\n'));
}
if (browser == 'unown') {
buttonLineFeed($(this));
}
}
});
},

prepareTooltipActions: function() {
},

prepareHeaderActions: function() {
$('#header .btnSearch, #header .searchWrap .btnClose').on('click', function(_e) {
_e.preventDefault();
_searchAreaToggle(this, _e);
});
},

prepareScrollActions: function() {
$('a[href^="#"]' + 'a[href!="#"]').on('click touchstart', function(_e) {
return SmoothScroll(this, _e);
});
},

showPane: function(id) {
$('#' + id).slideDown();
},

hidePane: function(id) {
$('#' + id).slideUp();
},

setButtonActivity: function(id, activity) {
var $button = $('#' + id);
if (activity) {
$button.prop('disabled', false);
$button.removeClass('disabled');
} else {
$button.prop('disabled', true);
$button.addClass('disabled');
}
},

campaignStickyHeader: function() {
var timer;
var coolTime = 15; 

function refreshView() {
var flag = true;
if(flag) {
flag = false;
clearTimeout(timer);

cloneStickyHeader();
adjustCampaignContentsWrapPadding();
stickyHeaderLocation = getStickyHeaderLocation();
switchStickyHeaderState();
switchActiveStateOfStickyHeadLink();
adjustCampaignContentsWrapPadding();

timer = setTimeout(function() {
adjustCampaignContentsWrapPadding();
stickyHeaderLocation = getStickyHeaderLocation();
switchStickyHeaderState();
switchActiveStateOfStickyHeadLink();
adjustCampaignContentsWrapPadding();
flag = true;
}, coolTime);
}
}

$(document).ready(function() {
adjustCampaignContentsWrapPadding();
stickyHeaderLocation = getStickyHeaderLocation();
switchStickyHeaderState();
switchActiveStateOfStickyHeadLink();

var isAppendedStyleTag = false;
$('body').on('touchmove', function() {
if(!isAppendedStyleTag) {
$('body').append('<style type="text/css">.CampaignToggleWrap a:hover {background: #ffffff;}</style>');
isAppendedStyleTag = true;
}
});

$('body').on('touchmove', function() {
refreshView();
});
$(window).on('scroll resize orientationchange', function() {
refreshView();
adjustStickyHeaderLocation();
});

$(window).on('orientationchange', function() {
$('.ActionStickyHeader').hide();
setTimeout(function() {
$('.ActionStickyHeader').show();
}, 1000);
});


$('.ActionContentHeader').on('click', function(event) {
event.preventDefault();
var scrollPosition = $($(this).attr('href')).offset().top
- (getStickyHeaderHeight() + getHeaderHeight() + ADJUSTING_SPAN_OF_SCROLL_LOCATION) + 1;
$('html, body').animate({scrollTop:scrollPosition}, SCROLLING_TIME);
});
});
},

campaignContentsDisplaySwitcher: function() {
$(document).ready(function() {
var $toggleText = $('.ActionCampaignTerminatedToggle');
var $terminatedContents = $('.ActionCampaignterminated');

$terminatedContents.hide();
$toggleText.removeClass('on');


$toggleText.on('click', function(event) {
event.preventDefault();

$(this).toggleClass('on');

if($(this).hasClass('on')) {
$terminatedContents.show();
} else {
$terminatedContents.hide();
}

});
});
}

};
});

