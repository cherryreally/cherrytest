define.amd.jQuery = true;
define([
'dojo/_base/declare',
'jquery',
'dojo/domReady!'
], function(declare, jQuery) {

(function($) {

$.fn.onOnlyOnce = function() {

var events, selector, handler;

events = arguments[0];

if (typeof arguments[1] == 'string') {
selector = arguments[1];
handler = arguments[2];
} else if ($.isFunction(arguments[1])) {
handler = arguments[1];
}

if (selector) {
return $(this).off(events, selector).on(events, selector, handler);
} else {
return $(this).off(events).on(events, handler);
}
};

})(jQuery);
});
