define.amd.jQuery = true;
define([
'dojo/_base/declare',
'jquery',
'dojo/request',
'dojo/json',
'vpx/sp/view/TemporaryMeasures',
'vpx/view/JqueryOnOnlyOnce',
'vpx/sp/view/picker',
'vpx/sp/view/picker.date',
'dojo/domReady!',
'vpx/sp/view/jqueryPanelslider'
], function(declare, $, request, json, TemporaryMeasures) {

var ATTR_NAME_PLACEHOLDER = 'data-action-preparator-placeholder';

var ATTR_VALUE_PLACEHOLDER_HAS_FAKE = 'has_fake';

var ATTR_NAME_MEMBER_NUMBER_FOCUS_ID = 'data-action-preparator-member-number-focus-id';
var ATTR_NAME_MEMBER_NUMBER_FOCUS_NEXT = 'data-action-preparator-member-number-focus-next';

var ATTR_NAME_CLIP_TARGET_TITLE = 'data-action-preparator-clip-target-title';
var ATTR_NAME_CLIP_TARGET_TEXT = 'data-action-preparator-clip-target-text';
var ATTR_NAME_CLIP_TARGET_ID = 'data-action-preparator-clip-target-id';
var ATTR_NAME_CLIP_TARGET = 'data-action-preparator-clip-target';
var ATTR_NAME_CLIP_EDIT_METHOD = 'data-action-preparator-clip-edit-method';

function _isIE() {
var ua = navigator.userAgent;
return (ua.match(/msie/i) != null);
}

function _isIE8() {
var ua = navigator.userAgent;
var av = window.navigator.appVersion.toLowerCase();
return (ua.match(/msie/i) && av.indexOf('msie 8.') != -1);
}

function _isIE9() {
var ua = navigator.userAgent;
var av = window.navigator.appVersion.toLowerCase();
return (ua.match(/msie/i) && av.indexOf('msie 9.') != -1);
}

function _isIE10() {
var ua = navigator.userAgent;
var av = window.navigator.appVersion.toLowerCase();
return (ua.match(/msie/i) && av.indexOf('msie 10.') != -1);
}

function _isNumeric(keyCode) {
return ((keyCode >= 96 && keyCode <= 105) || (keyCode >= 48 && keyCode <= 57)) ? true : false;
}

function _prepareBalloon(message) {
var get_message = message;
message =
'<div class="jq_balloon_parent">'+
'<div class="jq_balloon_obj">' + message + '</div>'+
'<div class="jq_balloon_arrow"><button class="negative_btn btn_auto_size">×</button></div></div>';

$('body').append(message);

var winH = $(window).height();
var balloonH = $('.jq_balloon_obj').height();
balloonH = balloonH+$('.jq_balloon_arrow').height();

var posTopPX = (winH - balloonH - 20) / 2;
if (posTopPX > 100) {
$('.jq_balloon_obj').css({marginTop:posTopPX});
}

$(document).onOnlyOnce('click.prepareBalloon', '.jq_balloon_arrow button', function() {
$('.jq_balloon_parent').remove();
message = '';
});
$(document).onOnlyOnce('click.prepareBalloon', '.jq_balloon_parent', function() {
$(this).remove();
message = '';
});

$(window).onOnlyOnce('orientationchange.prepareBalloon resize.prepareBalloon', function() {
if (!message == '') {
$('.jq_balloon_obj').remove();
$('.jq_balloon_parent').remove();
$('body').append(message);
var winH = $(window).height();
var balloonH = $('.jq_balloon_obj').height();
balloonH = balloonH+$('.jq_balloon_arrow').height();

var posTopPX = (winH - balloonH - 20) / 2;
if (posTopPX > 100) {
$('.jq_balloon_obj').css({marginTop:posTopPX});
}

$(document).onOnlyOnce('click.prepareBalloon', '.jq_balloon_arrow button', function() {
$('.jq_balloon_parent').remove();
message = '';
});
$(document).onOnlyOnce('click.prepareBalloon', '.jq_balloon_parent', function() {
$(this).remove();
message = '';
});
}
});
}

function _prepareTooltipBalloon() {
request.get("/common/dynamic/memx/js/sp/view/TooltipsBalloon.js", {
handleAs: 'json'
}).then(
function(data) {
$.each(data.Balloon, function(index, entry){
$('#'+entry.id).click(function() {
_prepareBalloon(entry.message);
});
});
},
function(error) {
console.log(error);
});
}

function _prepareClip() {

$('[id=fade_in_out_clip_pop]').on('click', function(e){
var id = $(this).attr(ATTR_NAME_CLIP_TARGET_ID);

var title = $('[' + ATTR_NAME_CLIP_TARGET_TITLE + "='" + id + "']").text();
var msg = title + "をコピーしました"

$('.jq_popup_parent').remove();

var pop = '<div class="jq_popup_parent">' +
'<div class="jq_popup_obj">' + msg + '</div>'+
'</div>'

$('body').append(pop);

var target = $(this).attr(ATTR_NAME_CLIP_TARGET);

var text

if (target == "children") {
text = $('[' + ATTR_NAME_CLIP_TARGET_TEXT + "='" + id + "']").children(":first").text();
} else {
text = $('[' + ATTR_NAME_CLIP_TARGET_TEXT + "='" + id + "']").text();
}

var method = $(this).attr(ATTR_NAME_CLIP_EDIT_METHOD);

if (method =="removespace") {
text = text.replace(/\s+/g, "");
}

var ta = document.createElement("textarea");
ta.value = text;
document.body.appendChild(ta);
ta.select();
document.execCommand("copy");
ta.parentElement.removeChild(ta);

$('.jq_popup_parent').fadeIn("slow", function () {
$(this).delay(1000).fadeOut("slow");
});
});

$(document).onOnlyOnce('click.prepareClip', '.jq_popup_arrow input', function() {
$('.jq_popup_parent').remove();
});

}

function _prepareMemberNumberFocus() {

$('[' + ATTR_NAME_MEMBER_NUMBER_FOCUS_ID + ']').onOnlyOnce('keyup.prepareMemberNumberFocus', function(e) {

var value = $(this).val();
var next = $(this).attr(ATTR_NAME_MEMBER_NUMBER_FOCUS_NEXT);

if (!_isNumeric(e.keyCode)
|| value.length < 4
|| value.match(/[^0-9]+/)
|| next === undefined) {
return;
}

$('[' + ATTR_NAME_MEMBER_NUMBER_FOCUS_ID + "='" + next + "']").focus();
});
}

function _prepareShowPassword() {
var $dispSwitches = $('[data-action-show-password-target]');
$dispSwitches.each(function() {
var $dispSwitch = $(this);
var $target = $('input[data-action-show-password-name="' + $dispSwitch.data('action-show-password-target') + '"]');
if (!$target.length) {return}
if ($dispSwitch.is('input[type="checkbox"]')) {
$dispSwitch.onOnlyOnce('change.actionShowPassword', function() {
if (this.checked) {
_showPassword($(this), $target);
} else {
_hidePassword($(this), $target);
}
});
} else if ($dispSwitch.is('[data-action-show-password-type="toggle"]')) {
$dispSwitch.onOnlyOnce('click.actionShowPassword', function() {
if ($target.is('[type="password"]')) {
_showPassword($(this), $target);
} else if ($target.is('[type="text"]')) {
_hidePassword($(this), $target);
}
});
} else if ($dispSwitch.is('[data-action-show-password-type="press"]')) {
$dispSwitch.onOnlyOnce('mousedown.actionShowPassword touchstart.actionShowPassword', function() {
_showPassword($(this), $target);
});
$dispSwitch.onOnlyOnce('mouseup.actionShowPassword mouseleave.actionShowPassword touchend.actionShowPassword', function() {
_hidePassword($(this), $target);
});
}
});
function _showPassword($dispSwitch, $target) {
$dispSwitch.removeClass('show_pw_switch_off');
$dispSwitch.addClass('show_pw_switch_on');
$target.attr('type', 'text');
}
function _hidePassword($dispSwitch, $target) {
$dispSwitch.removeClass('show_pw_switch_on');
$dispSwitch.addClass('show_pw_switch_off');
$target.attr('type', 'password');
}
}

function _prepareAutoZenkaku() {
$('.ActionAutoZenkaku').onOnlyOnce('blur.ActionAutoZenkaku', function () {
var str = $(this).val();

str = str.replace(/[!"#\$%&'\(\)\*\+,\-\.\/:;<=>\?@\[\\\]\^_`\{\|\}\dA-Za-z]/g, function (s) {
return String.fromCharCode(s.charCodeAt(0) + 0xFEE0);
});

var map = {
' ': '　', 
'~': '～', 
'｡': '。', '､': '、', 'ｰ': 'ー', '｢': '「', '｣': '」', '･': '・', 
'ｶﾞ': 'ガ', 'ｷﾞ': 'ギ', 'ｸﾞ': 'グ', 'ｹﾞ': 'ゲ', 'ｺﾞ': 'ゴ',
'ｻﾞ': 'ザ', 'ｼﾞ': 'ジ', 'ｽﾞ': 'ズ', 'ｾﾞ': 'ゼ', 'ｿﾞ': 'ゾ',
'ﾀﾞ': 'ダ', 'ﾁﾞ': 'ヂ', 'ﾂﾞ': 'ヅ', 'ﾃﾞ': 'デ', 'ﾄﾞ': 'ド',
'ﾊﾞ': 'バ', 'ﾋﾞ': 'ビ', 'ﾌﾞ': 'ブ', 'ﾍﾞ': 'ベ', 'ﾎﾞ': 'ボ',
'ﾊﾟ': 'パ', 'ﾋﾟ': 'ピ', 'ﾌﾟ': 'プ', 'ﾍﾟ': 'ペ', 'ﾎﾟ': 'ポ',
'ｳﾞ': 'ヴ', 'ﾜﾞ': 'ヷ', 'ｦﾞ': 'ヺ',
'ｱ': 'ア', 'ｲ': 'イ', 'ｳ': 'ウ', 'ｴ': 'エ', 'ｵ': 'オ',
'ｶ': 'カ', 'ｷ': 'キ', 'ｸ': 'ク', 'ｹ': 'ケ', 'ｺ': 'コ',
'ｻ': 'サ', 'ｼ': 'シ', 'ｽ': 'ス', 'ｾ': 'セ', 'ｿ': 'ソ',
'ﾀ': 'タ', 'ﾁ': 'チ', 'ﾂ': 'ツ', 'ﾃ': 'テ', 'ﾄ': 'ト',
'ﾅ': 'ナ', 'ﾆ': 'ニ', 'ﾇ': 'ヌ', 'ﾈ': 'ネ', 'ﾉ': 'ノ',
'ﾊ': 'ハ', 'ﾋ': 'ヒ', 'ﾌ': 'フ', 'ﾍ': 'ヘ', 'ﾎ': 'ホ',
'ﾏ': 'マ', 'ﾐ': 'ミ', 'ﾑ': 'ム', 'ﾒ': 'メ', 'ﾓ': 'モ',
'ﾔ': 'ヤ', 'ﾕ': 'ユ', 'ﾖ': 'ヨ',
'ﾗ': 'ラ', 'ﾘ': 'リ', 'ﾙ': 'ル', 'ﾚ': 'レ', 'ﾛ': 'ロ',
'ﾜ': 'ワ', 'ｦ': 'ヲ', 'ﾝ': 'ン',
'ｧ': 'ァ', 'ｨ': 'ィ', 'ｩ': 'ゥ', 'ｪ': 'ェ', 'ｫ': 'ォ',
'ｯ': 'ッ', 'ｬ': 'ャ', 'ｭ': 'ュ', 'ｮ': 'ョ'
};
str = str.replace(new RegExp('(' + Object.keys(map).join('|') + ')', 'g'), function (match) {
return map[match];
});

$(this).val(str);
});
}

function _prepareDatepicker() {
$('.ActionDatepicker').each(function (idx, elem) {
var $elem = $(elem);
var options = {
format: 'yyyymmdd' 
};

var minDays = $elem.attr('data-datepicker-min-days');
if (minDays !== undefined && minDays !== '') {
var minDate = new Date();
minDate.setDate(minDate.getDate() - parseInt(minDays));
options.min = minDate;
}

var maxDays = $elem.attr('data-datepicker-max-days');
if (maxDays !== undefined && maxDays !== '') {
var maxDate = new Date();
maxDate.setDate(maxDate.getDate() + parseInt(maxDays));
options.max = maxDate;
}

$elem.pickadate(options);
});
}

function _prepareFollowBtnArea() {
var key = 'followBtnArea';
var target = $(document).find(".followBtnArea");
if (!target.length) {
return;
}
if(sessionStorage.getItem(key)){
target.hide();
} else {
target.show();
}
$(document).find(".followBtnArea_cloase").on("click",function(){
sessionStorage.setItem(key, 'hide');
target.hide();
});

$(window).scroll(function () {
_floatingFooterAnime();
});
$(window).resize(function() {
_floatingFooterAnime();
});
}

function _floatingFooterAnime() {
const scroll = $(window).scrollTop();
const windowH = window.innerHeight;
const footerPos = $('#footerArea').offset().top;

let floatingPos = (scroll + windowH) - footerPos;

if (floatingPos < 0) {
floatingPos = 0;
}

$('.followBtnArea')[0].style.setProperty('bottom', floatingPos + 'px', 'important');
}

function _prepareModalwindow() {
$('.js-modal-open').each(function(){
$(this).on('click',function(){
var target = $(this).data('target');
var modal = document.getElementById(target);
$(modal).fadeIn();
return false;
});
});
$('.js-modal-close').on('click',function(){
$('.js-modal').fadeOut();
return false;
}); 
$('.modalWrap .modalBtnClose').on('click',function(){
$('.js-modal').fadeOut();
return false;
}); 
}

function _prepareAddValidateErrorClass() {
var $targets = $('input.prepare_is_validate_error');
$targets.each(function() {
var $target = $(this);
var targetId = $target.attr('id');
var errorMessageNode = $('#vp-view-err_' + targetId.replace(/vp-view-.*RS\d+_/, '')).get(0);
if (!errorMessageNode) {
errorMessageNode = $('#vp-view-err_' + targetId).get(0);
if (!errorMessageNode) {return}
}
new MutationObserver(function() {
if ($(errorMessageNode).text().trim().length) {
$target.addClass('action_validate_error');
} else {
$target.removeClass('action_validate_error');
}
}).observe(errorMessageNode, {childList: true});
$target.removeClass('prepare_is_validate_error');
});
}

function _prepareRadioButtons() {

function updateRadioButtonStyle($radio) {
if ($radio.is(':checked')) {
if ($radio.next().hasClass('default_radio')) {
$radio.next().addClass('default_radio_on').removeClass('default_radio');
}
if ($radio.next().hasClass('single_radio')) {
$radio.next().addClass('single_radio_on').removeClass('single_radio');
}
if (!($radio.next().hasClass('default_radio') || $radio.next().hasClass('not_check_bg'))) {
$radio.parent('div').addClass('js_add_check_bg');
}
} else {
if ($radio.next().hasClass('default_radio_on')) {
$radio.next().addClass('default_radio').removeClass('default_radio_on');
}
if ($radio.next().hasClass('single_radio_on')) {
$radio.next().addClass('single_radio').removeClass('single_radio_on');
}
if (!($radio.next().hasClass('default_radio_on') || $radio.next().hasClass('not_check_bg'))) {
$radio.parent('div').removeClass('js_add_check_bg');
}
}
}

$('input[type=radio]').each(function() {
updateRadioButtonStyle($(this));
});

$(document).onOnlyOnce('change.prepareRadioButtons', 'input[type=radio]', function() {
$('input[type=radio][name=' + $(this).attr('name') + ']').each(function() {
updateRadioButtonStyle($(this));
});
});
}

function _prepareCheckBoxes() {

function updateCheckBoxStyle($checkbox) {
if ($checkbox.is(':checked')) {
if ($checkbox.next().hasClass('default_checkbox')) {
$checkbox.next().addClass('default_checkbox_on').removeClass('default_checkbox');
}
if ($checkbox.next().hasClass('single_checkbox')) {
$checkbox.next().addClass('single_checkbox_on').removeClass('single_checkbox');
}
} else {
if ($checkbox.next().hasClass('default_checkbox_on')) {
$checkbox.next().addClass('default_checkbox').removeClass('default_checkbox_on');
}
if ($checkbox.next().hasClass('single_checkbox_on')) {
$checkbox.next().addClass('single_checkbox').removeClass('single_checkbox_on');
}
}
}

$('input[type=checkbox]').each(function() {
updateCheckBoxStyle($(this));
});

$(document).onOnlyOnce('change.updateCheckBoxStyle', 'input[type=checkbox]', function() {
updateCheckBoxStyle($(this));
});
}

function _adaptCheckHiLight($target) {

$target.onOnlyOnce('change.adaptCheckHiLight', function() {
if ($(this).is(':checked')) {
$(this).parent().addClass('js_add_check_bg');
} else {
$(this).parent().removeClass('js_add_check_bg');
}
});
}

function _prepareAllSelectionCheckBox(key, target) {

var ua = navigator.userAgent;

if (ua.match(/msie/i)) {
$(key).next().onOnlyOnce('click.prepareAllSelectionCheckBox', function() {
if ($(key).is(':checked')) {
$(target).each(function() {
$(this).prop({
checked : 'checked'
});
$(this).next().addClass('default_checkbox_on').removeClass('default_checkbox');
if (!$(this).next().hasClass('default_radio_on')) {
$(this).parent().addClass('js_add_check_bg');
}
});
} else {
$(target).each(function() {
$(this).removeAttr('checked');
$(this).next().addClass('default_checkbox').removeClass('default_checkbox_on');
if (!$(this).next().hasClass('default_radio_on')) {
$(this).parent().removeClass('js_add_check_bg');
}
});
}
});
}
else {
$(key).onOnlyOnce('change.prepareAllSelectionCheckBox', function() {
if ($(key).is(':checked')) {
$(target).each(function() {
if (!$(this).is(':checked')) {
$(this).prop({
checked : 'checked'
});
$(this).next().addClass('default_checkbox_on').removeClass('default_checkbox');
if (!$(this).next().hasClass('default_radio_on')) {
$(this).parent().addClass('js_add_check_bg');
}
}
});
} else {
$(target).each(function() {
$(this).removeAttr('checked');
$(this).next().addClass('default_checkbox').removeClass('default_checkbox_on');
if (!$(this).next().hasClass('default_radio_on')) {
$(this).parent().removeClass('js_add_check_bg');
}
});
}
});
}
}

function _prepareAgreementAcBtn() {

$('.agreement_parent').hide();

$('.accordion_title').onOnlyOnce('click.prepareAgreementAcBtn', function() {
var targetImg = $(this).children().children().children().attr('src');
if (targetImg.indexOf('plus_icon.png') != -1) {
$(this).children().children().children().attr('src', $(this).children().children().children().attr('src').replace('plus_icon', 'minus_icon'));
$(this).next().slideToggle();
}
else {
$(this).children().children().children().attr('src', $(this).children().children().children().attr('src').replace('minus_icon', 'plus_icon'));
$(this).next().slideToggle();
}
});
}

function _prepareSpButtonAction(target) {

$(target).onOnlyOnce('touchstart.prepareSpButtonAction', function() {
$(this).attr('class', $(this).attr('class').replace('_btn', '_btn_hover'));
}).onOnlyOnce('touchend.prepareSpButtonAction', function() {
$(this).attr('class', $(this).attr('class').replace('_btn_hover', '_btn'));
});
}

function _preparePlaceHolders() {

if (!(_isIE8() || _isIE9())) {
return;
}

var prepareFields = function($realField, $fakeField) {

if ($fakeField.is(':focus')) {
$realField.show();
$fakeField.hide();
$realField.focus();
}

if ($realField.val() != '' || $realField.is(':focus')) {
$realField.show();
$fakeField.hide();
} else {
$realField.hide();
$fakeField.show();
}
};

$('input[type=text], input[type=password]').each(function() {

$realField = $(this);

if (!$realField.attr('placeholder')) {
return;
}

if ($realField.attr(ATTR_NAME_PLACEHOLDER) == ATTR_VALUE_PLACEHOLDER_HAS_FAKE) {
return;
}

var $fakeField = $('<input type="text" readonly="readonly">');

if ($realField.attr('class')) {
$fakeField.addClass($realField.attr('class'));
}
if ($realField.attr('size')) {
$fakeField.attr('size', $realField.attr('size'));
}
if ($realField.attr('placeholder')) {
$fakeField.val($realField.attr('placeholder'));
}

if ($realField.attr('type') == 'text') {
$realField.attr(ATTR_NAME_PLACEHOLDER, ATTR_VALUE_PLACEHOLDER_HAS_FAKE);
$realField.addClass('ie_no_submit_target');
$fakeField.addClass('ie_no_readyonly');
$realField.after($fakeField);

} else if ($realField.attr('type') == 'password') {
$realField.attr(ATTR_NAME_PLACEHOLDER, ATTR_VALUE_PLACEHOLDER_HAS_FAKE);
$realField.addClass('ie_no_submit_target_pw');
$fakeField.addClass('ie_no_readyonly_pw');
$realField.after($fakeField);
}

$realField.onOnlyOnce('blur.preparePlaceHolders change.preparePlaceHolders propertychange.preparePlaceHolders', function() {
prepareFields($(this), $(this).next('input'));
});

$fakeField.onOnlyOnce('focus.preparePlaceHolders', function() {
prepareFields($(this).prev('input'), $(this));
});

prepareFields($realField, $fakeField);
});
}

function _adaptLoginRadioSelector() {

$('input[name=vp-view-WebApiId_GMVE0501001K350001_3]').onOnlyOnce('change.adaptLoginRadioSelector', function() {
if ($(this).is(':checked')) {
$('input[name=vp-view-WebApiId_GMVE0501001K350001_3]').parent().removeClass('js_add_check_bg');
$(this).parent().addClass('js_add_check_bg');
} else {
$(this).parent().removeClass('js_add_check_bg');
}
});
}

function SmoothScroll(_target, _e) {
var speed, href, target, position;
speed = 500;
href = $(_target).attr('href');
target = $(href == "#" || href == "" ? 'html' : href);
position = target.offset().top;
var url = location.href;
if (url.match("/pop/") != null) {
$('html, body').animate({
scrollTop: position
}, speed, "swing");
} else {
$('html, body').animate({
scrollTop: position - 76
}, speed, "swing");
}
return false;
}

function _closeSlidePanel() {

$.panelslider.close();
$('#view2').css({visibility: 'visible' , height: 'auto'});
setTimeout(function() {
if ($('body').attr('style').indexOf('margin-left') != -1) {
$('body').css('margin-left', 0);
}
}, 210);
}

var ADJUSTING_SPAN_OF_SCROLL_LOCATION = 16; 
var CAMPAIGN_CONTENTS_WRAP_PADDING_TOP = 20; 
var SCROLLING_TIME = 500; 

var stickyHeaderLocation;

function adjustCampaignContentsWrapPadding() {
$('.ActionCampaignContentsWrap').css('paddingTop', getStickyHeaderHeight() + CAMPAIGN_CONTENTS_WRAP_PADDING_TOP + 'px');
}


function getStickyHeaderHeight() {
return $('.ActionStickyHeader').eq(0).outerHeight(true);
}

function getContentEndLocation() {
var $campaignContentsWrap = $('.ActionCampaignContentsWrap');
return $campaignContentsWrap.height() + $campaignContentsWrap.offset().top;
}

function getHeaderHeight() {
var $header = $('#header');
var $smbcLine = $('#smbcLine');
var $headerContent = $header.find('div.rwdLeft');
if(0 < $headerContent.length) {
return $header.outerHeight(true) + $smbcLine.outerHeight(true);
} else {
return 0;
}
}

function cloneStickyHeader() {
var $stickyHeader = $('.ActionStickyHeader');
var $clonedHeader = $('.ActionCloned');
var currentScroll = $(window).scrollTop();
if($stickyHeader.length <= 1 && $clonedHeader.length < 1 && 0 < currentScroll) {
$stickyHeader.clone(true).insertAfter($stickyHeader).addClass('act');
}
}

function getStickyHeaderLocation() {
return $('.ActionCampaignContentsWrap').offset().top - getHeaderHeight();
}


function switchStickyHeaderState() {
var $stickyHeader = $('.ActionStickyHeader.act');
var currentScrollTop = $(window).scrollTop();

if(stickyHeaderLocation <= currentScrollTop) {
if($stickyHeader.css('display') === 'none') {
$stickyHeader.show();
var xCurrentScroll = $('.ActionStickyHeader:not(.act)').scrollLeft();
$stickyHeader.scrollLeft(xCurrentScroll);
}
} else {
if($stickyHeader.css('display') === 'block') {
var currentScrollLeft = $('.ActionStickyHeader.act').scrollLeft();
$('.ActionStickyHeader:not(.act)').scrollLeft(currentScrollLeft);
$stickyHeader.find('.ActionContentHeader').removeClass('act');
$stickyHeader.hide();
}
}
}


function autoScrollToActiveStickyHeaderLink() {
var $target = $('.ActionStickyHeader.act .act');
var StickyHeaderWidth = $('.ActionStickyHeader').width(); 
var StickyHeaderScroll = $('.ActionStickyHeader').scrollLeft(); 

if (0 < $target.length) {
var targetWidth = $target.width(); 

var targetPosition = $target.position().left + StickyHeaderScroll;
}

if (targetPosition < StickyHeaderScroll) {
$('.ActionStickyHeader').not(':animated').animate({scrollLeft:targetPosition}, 50);
} else if (StickyHeaderScroll + StickyHeaderWidth < targetPosition + targetWidth) {
$('.ActionStickyHeader').not(':animated').animate({scrollLeft:targetPosition + targetWidth - StickyHeaderWidth}, 50);
}
}

function switchActiveStateOfStickyHeadLink() {
var $stickyHeaderLinks = $('.ActionStickyHeader.act').find('.ActionContentHeader');
var $originalStickyHeaderLinks = $('.ActionStickyHeader:not(.act)').find('.ActionContentHeader');

var $contents = $('.ActionContent');
var eachContentsPosition = [];
$contents.each(function(index) {
eachContentsPosition[index] = $(this).offset().top;
});

var currentScrollTop = $(window).scrollTop();
var offset = (getStickyHeaderHeight() + getHeaderHeight() + ADJUSTING_SPAN_OF_SCROLL_LOCATION);

$originalStickyHeaderLinks.removeClass('act');
for(var i = 0; i < $stickyHeaderLinks.length + 1; ++i) {
if(i !== $stickyHeaderLinks.length) {
if(currentScrollTop < eachContentsPosition[i] - offset) {
if(i !== 0) {
_addActiveClass($stickyHeaderLinks.eq(i - 1));
}
break;
}
} else if(currentScrollTop < getContentEndLocation() - getStickyHeaderHeight() - ADJUSTING_SPAN_OF_SCROLL_LOCATION) {
_addActiveClass($stickyHeaderLinks.eq(i - 1));
break;
}
}

function _addActiveClass($target) {
if(!$target.hasClass('act')) {
$stickyHeaderLinks.removeClass('act');
$target.addClass('act');

autoScrollToActiveStickyHeaderLink();
}
}
}


function multiRowStyleStickyHeader() {
var ua = window.navigator.userAgent.toLowerCase();
var linkLength = $('.ActionCampaignContentsWrap .ActionStickyHeader:eq(0) .ActionContentHeader').length;
if((0 <= ua.indexOf('android 4.0.3') || 0 <= ua.indexOf('android 4.0.4')) && 5 < linkLength) {
$('.CampaignToggleWrap').addClass('MultiRowLayout');
$('.CampaignToggleItem').addClass('MultiRowLayout');
}

}

function _syncCheck($org) {
$('.ActionSyncCheckbox[data-action-sync-group="' + $org.attr('data-action-sync-group') + '"]:checkbox').prop('checked', $org.prop('checked')).trigger('change', [true]);
}
function _allCheck() {
var $targets = $('.ActionAllCheckTarget');
if ($('.ActionAllCheckCheckbox:checkbox:checked').length == $('.ActionAllCheckCheckbox:checkbox').length){
$targets.prop('disabled', false).removeClass('disabled_btn');
} else {
$targets.prop('disabled', true).addClass('disabled_btn');
}
}

function _prepareCardCdArea() {
try {
let cardCode = $('[data-action-card-cd]:eq(0)').text();

$('[data-action-card-cd-area-wlist]').each(function () {
let $this = $(this);
let list = $this.attr('data-action-card-cd-area-wlist').split(',');
$this[list.indexOf(cardCode) >= 0 ? 'show' : 'hide']();
});

$('[data-action-card-cd-area-blist]').each(function () {
let $this = $(this);
let list = $this.attr('data-action-card-cd-area-blist').split(',');
$this[list.indexOf(cardCode) >= 0 ? 'hide' : 'show']();
});
} catch (ex) {
$('[data-action-card-cd-area-wlist], [data-action-card-cd-area-blist]').each(function () {
$(this).hide();
});
}
}

return {
prepareLoginRadioActions: function() {
_adaptLoginRadioSelector();
},

prepareCheckStyleActions: function() {
_adaptCheckHiLight($('.common_accordion_parent').find('input[type=checkbox]'));
},

prepareAccordionActions: function() {
_prepareSpButtonAction();

$('#index_toggle_target').hide();

$('#add_input_form').onOnlyOnce('click.prepareAccordionActions', function() {
$(this).parent().hide();
$('#index_toggle_target').slideDown();
});

$('#remove_input_form').onOnlyOnce('click.prepareAccordionActions', function() {
$('#index_toggle_target').css({marginTop:'0'});
$('#index_toggle_target').slideUp();
$('#add_input_form').parent().show();
});

$('.default_radio').closest('li').next('.changePanel').hide();
$('.default_checkbox').closest('li').next('.changePanel').hide();

if ($('.common_accordion_parent').length > 0) {

function initAcdiBtnImg($acdiBtn) {
var $img = $acdiBtn.children('img');
var imgSrc = $img.attr('src');
if (imgSrc) {
if (imgSrc.indexOf('minus') == -1) {
$acdiBtn.removeClass('off').addClass('on');
} else {
$acdiBtn.removeClass('on').addClass('off');
}
}
}

function tglAcdiBtnImg($acdiBtn) {
var $img = $acdiBtn.children('img');
var imgSrc = $img.attr('src');
if (imgSrc) {
if (imgSrc.indexOf('minus') == -1) {
$img.attr('src', imgSrc.replace('plus', 'minus'));
$acdiBtn.removeClass('on').addClass('off');
} else {
$img.attr('src', imgSrc.replace('minus', 'plus'));
$acdiBtn.removeClass('off').addClass('on');
}
}
}

$('.common_accordion_parent').each(function() {
$(this).children().children('button').each(function() {
var $acdiBtn = $(this);
initAcdiBtnImg($acdiBtn);
if ($acdiBtn.children('img').attr('src').indexOf('minus') == -1) {
$acdiBtn.parent().next().hide();
}
});

$(this).children('table').children('tbody').children('tr').children('td, .accordion_btn_table').children('button').each(function() {
var $acdiBtn = $(this);
initAcdiBtnImg($acdiBtn);
if ($acdiBtn.children('img').attr('src').indexOf('minus') == -1) {
$acdiBtn.parent('td').parent('tr').next('tr').next('.accordion_add_tr').hide();
$acdiBtn.parent('td').parent('tr').next('.accordion_add_tr').hide();
$acdiBtn.parent().parent('tr').next('.accordion_add_tr').hide();
}
});

$(this).children('.accordion_btn_parent').onOnlyOnce('click.prepareAccordionActions', function() {
var $this = $(this);
var $acdiBtn = $this.children('button');
if ($acdiBtn.children('img').attr('src').indexOf('minus') != -1) {
$this.next().slideUp();
} else {
$this.next().slideDown();
}
tglAcdiBtnImg($acdiBtn);
});

$(this).children('.accordion_btn_parent2').onOnlyOnce('click.prepareAccordionActions', function() {
var $this = $(this);
var $acdiBtn = $this.children('button');
if ($acdiBtn.children('img').attr('src').indexOf('minus') != -1) {
$this.children('button').children('img').attr('src', $(this).children('button').children('img').attr('src').replace('minus', 'plus'));
$this.next().slideUp();
} else {
$this.children('button').children('img').attr('src', $(this).children('button').children('img').attr('src').replace('plus', 'minus'));
$this.next().slideDown();
}
tglAcdiBtnImg($acdiBtn);
});

$(this).children('table').children('tbody').children('tr').children('.accordion_btn_table').onOnlyOnce('click.prepareAccordionActions', function() {
var $this = $(this);
var $acdiBtn = $this.children('button');
if ($acdiBtn.children('img').attr('src').indexOf('minus') != -1) {
$this.parent('tr').next('tr').next('.accordion_add_tr').hide();
$this.parent('tr').next('.accordion_add_tr').hide();
} else {
$this.parent('tr').next('tr').next('.accordion_add_tr').show();
$this.parent('tr').next('.accordion_add_tr').show();
}
tglAcdiBtnImg($acdiBtn);
});

});
}

function updateSlideAlongWithCheckBox($checkBox, duration) {
var $panel = $checkBox.closest('li').next('li.changePanel');
if ($checkBox.prop('checked')) {
$panel.slideDown(duration);
} else {
$panel.slideUp(duration);
}
}

$('input[type=checkbox]').each(function() {
updateSlideAlongWithCheckBox($(this), 0);
});

$('input[type=checkbox]').onOnlyOnce('change.prepareAccordionSlideActions', function() {
updateSlideAlongWithCheckBox($(this));
});

function updateSlideAlongWithCheckBoxByAttrData($checkBox, duration) {
var $panel = $checkBox.closest('body').find('[data-slide-name="' + $checkBox.data('slide-target') + '"]');
if ($checkBox.css('display') !== 'block') {
duration = 0;
}
if ($checkBox.prop('checked')) {
$panel.slideDown(duration);
} else {
$panel.slideUp(duration);
}
}

$('[data-slide-target]:checkbox').each(function() {
updateSlideAlongWithCheckBoxByAttrData($(this), 0);
});

$('[data-slide-target]:checkbox').onOnlyOnce('change.prepareAccordionSlideActionsFromAttrData', function() {
updateSlideAlongWithCheckBoxByAttrData($(this));
});

function updateSlideAlongWithRadio($radio, duration) {
var $panel = $radio.closest('li').next('li.changePanel');
if ($radio.prop('checked')) {
$panel.slideDown(duration);
} else {
$panel.slideUp(duration);
}
}

$('input[type=radio]').onOnlyOnce('change.prepareAccordionActions', function() {
$('input[type=radio][name=' + $(this).attr('name') + ']').each(function() {
updateSlideAlongWithRadio($(this));
});
});

$('input[type=radio]').each(function() {
updateSlideAlongWithRadio($(this), 0);
});

$('.changePanel').each(function() {
var $panel = $(this);
var isValueSet = false;

var $decisionTarget = $panel.find('input').filter(function() {

var $input = $(this);
var inputType = $input.prop('type');

if (inputType === 'hidden' || $input.prop('readonly')) {
return false;
}

if(inputType === 'radio' || inputType === 'checkbox' || inputType === 'text' || inputType === 'password') {
return true;
} else {
return false;
}
});

$decisionTarget.each(function() {
var $input = $(this);
var type = $input.prop('type');

switch(type) {
case 'text':
if($input.val() !== '') {
isValueSet = true;
}
break;

case 'password':
if($input.val() !== '') {
isValueSet = true;
}
break;

case 'radio':
if(0 < $input.filter(':checked').length) {
isValueSet = true;
}
break;

case 'checkbox':
if(0 < $input.filter(':checked').length) {
isValueSet = true;
}
break;
}

if (isValueSet === true) {
return false;
}
});

if (isValueSet) {
$panel.prev().find('input[type=radio]').prop('checked', true).trigger('change');
}
});

$('#in_val_button').onOnlyOnce('click.prepareAccordionActions', function() {
$('#vp-view-WebApiId_U087210_16').val('9');
});

function updateSlideAlongWithRadioByAttrData($radio, duration) {
var $panel = $('[data-slide-name="' + $radio.data('slide-target') + '"]');
var displayFlg = $radio.data('slide-display-flg');
if (displayFlg) {
$panel.each(function() {
if ($(this).css('visibility') == 'hidden') {
$(this).css({
'visibility': '',
'position': ''
}).hide().slideDown(duration);
}
});
} else {
$panel.slideUp(duration, function() {
$panel.css({
'visibility': 'hidden',
'position': 'absolute'
}).show();
});
}
}

$('input[type=radio][data-slide-target][data-slide-display-flg]:checked').each(function() {
updateSlideAlongWithRadioByAttrData($(this), 0);
});

$('input[type=radio][data-slide-target][data-slide-display-flg]').onOnlyOnce('change.prepareAccordionSlideActionsFromAttrData', function() {
updateSlideAlongWithRadioByAttrData($(this));
});

if ($('input[type=radio][data-slide-target][data-slide-display-flg]').length) {
$('[data-slide-name] .validate_error_line').each(function() {
var target = this;
var observer = new MutationObserver(function() {
if ($(target).text().trim().length) {
$(target).closest('[data-slide-name]').css({
'visibility': '',
'position': ''
}).show();
}
});
observer.observe(target, {childList: true, subtree: true});
});
$('[data-slide-name] input').onOnlyOnce('invalid.prepareAccordionSlideActionsFromAttrData', function() {
$(this).closest('[data-slide-name]').css({
'visibility': '',
'position': ''
}).show();
});
}

},
prepareInputActions: function() {

if ($('input[type=radio]').length > 0) {
_prepareRadioButtons();
}
if ($('input[type=checkbox]').length > 0) {
_prepareCheckBoxes();
}
if ($('.all_check').length > 0) {
_prepareAllSelectionCheckBox('.all_check', '.with_check');
}
if ($('input[type=text], input[type=password]').length > 0) {
_preparePlaceHolders();
}
_prepareMemberNumberFocus();

_prepareShowPassword();

_prepareAgreementAcBtn();
_prepareTooltipBalloon();

_prepareClip();

_prepareAutoZenkaku();

_prepareDatepicker();

TemporaryMeasures.setTemporaryMeasures();

_prepareFollowBtnArea();

_prepareModalwindow();

_prepareAddValidateErrorClass();

$('.ActionSyncCheckbox:checkbox').onOnlyOnce('change.prepareSyncCheck', function (evt, skip) {
if (!skip) {
_syncCheck($(this));
}
});
$('.ActionAllCheckCheckbox:checkbox').onOnlyOnce('change.prepareAllCheck', function () {
_allCheck();
});
_syncCheck($('.ActionSyncCheckbox:checkbox:eq(0)'));
_allCheck();

_prepareCardCdArea();
},

prepareButtonLineFeedActions: function() {
var userAgent = window.navigator.userAgent.toLowerCase();
var appVersion = window.navigator.appVersion.toLowerCase();

var browser = '';
if (userAgent.indexOf('msie') != -1) {
browser = 'ie';
}
else if (userAgent.indexOf('chrome') != -1) {
browser = 'another';
}
else if (userAgent.indexOf('safari') != -1) {
browser = 'another';
}
else if (userAgent.indexOf('firefox') != -1) {
browser = 'another';
}
else if (userAgent.indexOf('opera') != -1) {
browser = 'another';
}
else {
browser = 'unown';
}

$.fn.textWidth = function(){
var _t = $(this);
var html_org = _t.html();
if (_t[0].nodeName=='INPUT') {
html_org = _t.val();
}
var html_calcS = '<span>' + html_org + '</span>';
$('body').append(html_calcS);
var _lastspan = $('span').last();
_lastspan.css({
'font-size'  : _t.css('font-size'),
'font-family': _t.css('font-family')
});
var width =_lastspan.width()+3.8;
_lastspan.remove();
return width;
};

function rensoku(text, input, cnt) {
var output_text = text;
var pre_space = '';
var nex_space = '';
for(var i=0; i<=cnt/2; i++){
pre_space += input;
}
for(var i=0; i<=cnt/2; i++){
nex_space += input;
}
return pre_space + output_text + nex_space;
}

function buttonLineFeed(input_this) {
$this = input_this;
var b_value      = $this.val();
var b_width      = $this.width();
var b_font_width = $this.textWidth();
var b_space_size = $this.val(' ').textWidth();
var b_val_split  = b_value.split('<lf>');
var out_val      = '';
var input_space  = '';
for (var cnt=0; cnt<b_val_split.length; cnt++) {
var split_val_size = $this.val(b_val_split[cnt]).textWidth();
if (b_width > split_val_size) {
var in_space_size = 0;
if ((b_width-split_val_size)%b_space_size == 0) {
in_space_size = (b_width-split_val_size)/b_space_size;
}
else {
in_space_size = ((b_width-split_val_size) - ((b_width-split_val_size)%b_space_size))/b_space_size;
in_space_size+=1;
}
if (cnt == b_val_split.length-1) {
in_space_size = 0;
}
out_val += rensoku(b_val_split[cnt], ' ', in_space_size);
}
}
$this.css('word-wrap', 'break-word');
$this.css('line-height', '20px');
$this.val(out_val);
};

$('input[type=button]').each(function() {
if ($(this).val().indexOf('<lf>') != -1 && $(this).hasClass('btn_big_size')) {
if (browser == 'ie') {
buttonLineFeed($(this));
}
if(browser == 'another') {
$(this).val($(this).val().replace('<lf>', '\n'));
}
if(browser == 'unown') {
buttonLineFeed($(this));
}
}
});
$('input[type=submit]').each(function() {
if($(this).val().indexOf('<lf>') != -1 && $(this).hasClass('btn_big_size')){
if (browser == 'ie') {
buttonLineFeed($(this));
}
if (browser == 'another') {
$(this).val($(this).val().replace('<lf>', '\n'));
}
if (browser == 'unknown') {
buttonLineFeed($(this));
}
}
});
},

prepareSelectDisabledActions: function() {

$('input[type=radio]').onOnlyOnce('change.prepareSelectDisabledActions', function() {
$('input[type=radio][name=' + $(this).attr('name') + ']').each(function() {
if ($(this).prop('checked')) {
if ($(this).next().hasClass('disabled_radio')) {
$(this).closest('div.disabled_div').find('input.disabled_input').attr('disabled', 'disabled');
}
} else {
if ($(this).next().hasClass('disabled_radio')) {
$(this).closest('div.disabled_div').find('input.disabled_input').removeAttr('disabled');
}
}
});
});
},

prepareMenuActions: function() {
},

openMenuPanel: function() {
},

closeMenuPanel: function () {
},

openSearchPanel: function() {
},

closeSearchPanel: function () {
},

prepareFooterActions: function() {
var duration = 500;
$('#footer .footNavArea dl dt, #footer .footAreaBottom dl dt').on('click', function() {
var this_dt = $(this);
if (this_dt.hasClass('act')) {
this_dt.removeClass('act');
this_dt.next('dd').slideUp(duration);
} else {
this_dt.addClass('act');
this_dt.next('dd').slideDown(duration);
}
});
},

prepareScrollActions: function() {
$('a[href^="#"]' + 'a[href!="#"]').on('click touchstart', function(_e) {
return SmoothScroll(this, _e);
});
},

showPane: function(id) {
$('#' + id).slideDown();
},

hidePane: function(id) {
$('#' + id).slideUp();
},

setButtonActivity: function(id, activity) {
var $button = $('#' + id);
if (activity) {
$button.prop('disabled', false);
$button.removeClass('disabled');
} else {
$button.prop('disabled', true);
$button.addClass('disabled');
}
},

campaignStickyHeader: function() {
var timer;
var coolTime = 15; 

function refreshView() {
var flag = true;
if(flag) {
flag = false;
clearTimeout(timer);

cloneStickyHeader();
adjustCampaignContentsWrapPadding();
stickyHeaderLocation = getStickyHeaderLocation();
switchStickyHeaderState();
switchActiveStateOfStickyHeadLink();
adjustCampaignContentsWrapPadding();

timer = setTimeout(function() {
adjustCampaignContentsWrapPadding();
stickyHeaderLocation = getStickyHeaderLocation();
switchStickyHeaderState();
switchActiveStateOfStickyHeadLink();
adjustCampaignContentsWrapPadding();
flag = true;
}, coolTime);
}
}

$(document).ready(function() {
multiRowStyleStickyHeader();
adjustCampaignContentsWrapPadding();
stickyHeaderLocation = getStickyHeaderLocation();
switchStickyHeaderState();
switchActiveStateOfStickyHeadLink();
refreshView();

$('body').on('touchmove', function() {
refreshView();
});

$('.ActionContentHeader').on('click', function(event) {
event.preventDefault();
var scrollPosition = $($(this).attr('href')).offset().top
- (getStickyHeaderHeight() + getHeaderHeight() + ADJUSTING_SPAN_OF_SCROLL_LOCATION) + 1;
$('html, body').animate({scrollTop:scrollPosition}, SCROLLING_TIME);
});
});
},

campaignContentsDisplaySwitcher: function() {
$(document).ready(function() {
var $toggleText = $('.ActionCampaignTerminatedToggle');
var $terminatedContents = $('.ActionCampaignterminated');

$terminatedContents.hide();
$toggleText.removeClass('on');


$toggleText.on('click', function(event) {
event.preventDefault();

$(this).toggleClass('on');

if($(this).hasClass('on')) {
$terminatedContents.show();
} else {
$terminatedContents.hide();
}

});
});
}
};
});
