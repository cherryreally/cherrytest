define.amd.jQuery = true;
define([
'dojo/cookie',
'jquery'
], function(cookie, $) {

function _parseUA() {
var matches = window.navigator.userAgent.toLowerCase().match(/com\.smbc_card\.vpass\.(android|ios)_v([\d\.]+)/);
if (!matches) {
return null;
}

var version = matches[2].split('.');
return {
'os': matches[1],
'version': {
'origin': matches[2],
'major': version[0] ? parseInt(version[0]) : 0,
'minor': version[1] ? parseInt(version[1]) : 0,
'build': version[2] ? parseInt(version[2]) : 0,
}
};
}

function _isVApp() {
var ua = _parseUA();
if (ua === null) {
return false;
}

return (ua.version.major >= 3 || (ua.version.major == 2 && ua.version.minor >= 5));
}

function _isBCApp() {
var matches = window.navigator.userAgent.toLowerCase().match(/smbcapp\.(android|ios|unknown)_v([\d\.]+)/);
if (!matches) {
return false;
}

return true;
}

function _isLMApp() {
var lmapp = cookie('cc-lmapp');
if (!lmapp) {
return false;
}

return true;
}

function _isEmbeddedApp() {
return !!cookie('embedded-app');
}

function _isIOSApp() {
var ua = _parseUA();
return ua !== null && ua.os === 'ios';
}

function _isAndroidApp() {
var ua = _parseUA();
return ua !== null && ua.os === 'android';
}

function _isAppWV() {
return _isVApp() || _isBCApp() || _isLMApp() || _isEmbeddedApp();
}

function _prepareVAppWebView() {
if (!_isAppWV()) {
return;
}

if (_isLMApp()) {
if (!$(document.body).hasClass('LMApp')) { 
$(document.body).addClass('LMApp');
$(document.head).append('<link rel="stylesheet" href="/common/dynamic/memx/css/sp/LMApp.css">');
}
} else if (_isEmbeddedApp()) { 
if (!$(document.body).hasClass('EmbeddedApp')) { 
$(document.body).addClass('EmbeddedApp');
$(document.head).append('<link rel="stylesheet" href="/common/dynamic/memx/css/sp/EmbeddedApp.css">');
}
} else if (!$(document.body).hasClass('VAppWebView')) {
$(document.body).addClass('VAppWebView');
if (_isBCApp()) {
$(document.body).addClass('BCAppWebView');
}

$(document.head).append('<link rel="stylesheet" href="/common/dynamic/memx/css/sp/VAppWebView.css">');
}
}

function _prepareForceLogin() {
console.log('forcelogin');
if (!_isAppWV()) {
return;
}

var $forceLoginForm = $('#FRM_cGMVC800100U010001-0001');
var $forceLoginMsgA = $('#vpapp_android_area');
var $forceLoginMsgI = $('#vpapp_ios_area');
$forceLoginForm.children().addClass('VAppWebViewHide');
if (_isIOSApp()) {
$forceLoginMsgI.addClass('VAppWebViewShow-b');
} else {
$forceLoginMsgA.addClass('VAppWebViewShow-b');
}
}

return {
isVApp: function () {
return _isAppWV();
},
prepareVAppWebView: function () {
_prepareVAppWebView();
},
prepareForceLogin: function () {
_prepareForceLogin();
}
};

});
