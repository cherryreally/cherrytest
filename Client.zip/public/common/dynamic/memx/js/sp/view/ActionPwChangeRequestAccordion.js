﻿define.amd.jQuery = true;
define([
'dojo/_base/declare',
'jquery',
'dojo/request',
'dojo/json',
'vpx/view/MyPointerEvent'
], function (declare, $, request, json, MyPointerEvent) {

var ANIMATION_TIME = 500;

function _openPwChangeAccordion(animationTime) {
$('.ActionAccordionTarget').slideDown(animationTime);
}

function _closePwChangeAccordion(animationTime) {
$('.ActionAccordionTarget').slideUp(animationTime);
}

var nocheck = 'nocheck';

function _isToOpen() {
var $checkedRadio = $('.ActionPwChangeRadios input[type=radio]:checked');
if($checkedRadio.length < 1) {
return nocheck;
}
if($checkedRadio.hasClass('ActionAccordionToggle')) {
return true;
} else {
return false;
}
}

return {

initPwChangeAccordionHandler: function() {
$(".ActionPwChangeRadios input[type=radio]").change(function () {
var toOpen = _isToOpen();
if(toOpen === nocheck) {
return;
} else if(toOpen) {
_openPwChangeAccordion(ANIMATION_TIME);
} else {
_closePwChangeAccordion(ANIMATION_TIME);
}
});
},

initPwChangeAccordionInitialState: function() {
var toOpen = _isToOpen();
if(toOpen === nocheck) {
return;
} else if(toOpen) {
$(".ActionAccordionTarget").show();
} else {
$(".ActionAccordionTarget").hide();
}
}

};
});

