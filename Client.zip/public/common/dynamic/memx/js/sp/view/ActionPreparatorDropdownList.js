define.amd.jQuery = true;
define([
'jquery',
'vpx/view/JqueryOnOnlyOnce'
], function($) {

var ID_DROPDOWN_LIST_DISPLAY_AREA = 'DropdownListDisplayArea';
var ID_DROPDOWN_LIST_DISPLAY_AREA_D = 'DropdownListDisplayArea_d';
var ATTR_NAME_ACCORDION_TRIGGER = 'data-action-preparator-accordion-trigger';
var ATTR_NAME_ACCORDION_TARGET = 'data-action-preparator-accordion-target';
var ATTR_NAME_ACCORDION_BUTTON = 'data-action-preparator-accordion-button';

function initAcdiBtnImg($acdiBtn) {
var $img = $acdiBtn.children('img');
var imgSrc = $img.attr('src');
if (imgSrc) {
if (imgSrc.indexOf('minus') == -1) {
$acdiBtn.removeClass('off').addClass('on');
} else {
$acdiBtn.removeClass('on').addClass('off');
}
}
}

function tglAcdiBtnImg($acdiBtn) {
var $img = $acdiBtn.children('img');
var imgSrc = $img.attr('src');
if (imgSrc) {
if (imgSrc.indexOf('minus') == -1) {
$img.attr('src', imgSrc.replace('plus', 'minus'));
$acdiBtn.removeClass('on').addClass('off');
} else {
$img.attr('src', imgSrc.replace('minus', 'plus'));
$acdiBtn.removeClass('off').addClass('on');
}
}
}

function _prepareAccordions(areaId) {
$('#' + areaId + ' [' + ATTR_NAME_ACCORDION_TRIGGER + ']').onOnlyOnce('click.' + areaId, function() {
var targetId = $(this).attr(ATTR_NAME_ACCORDION_TRIGGER);
var $target = $('#' + areaId + ' [' + ATTR_NAME_ACCORDION_TARGET + '=' + targetId + ']');
var $button = $('#' + areaId + ' [' + ATTR_NAME_ACCORDION_BUTTON + '=' + targetId + ']').parent();
if ($button.hasClass('off')) {
$target.slideUp();
} else {
$target.slideDown();
}
tglAcdiBtnImg($button);
});
initAcdiBtnImg($('#' + areaId + ' [' + ATTR_NAME_ACCORDION_BUTTON + '=' + $('#' + areaId + ' [' + ATTR_NAME_ACCORDION_TRIGGER + ']').attr(ATTR_NAME_ACCORDION_TRIGGER) + ']').parent());
}

return {
prepareActions : function() {
_prepareAccordions(ID_DROPDOWN_LIST_DISPLAY_AREA);
_prepareAccordions(ID_DROPDOWN_LIST_DISPLAY_AREA_D);
}
};
});
