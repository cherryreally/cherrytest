define([
'dojo/_base/declare',
'dojo/dom',
'dojo/text!./DeviceButton.html',
'dojo/dom-style',
'vp/alcor/util/UAUtil',
'vp/alcor/pages/_AbstractPage'
], function(declare, dom, template, domStyle, UAUtil, _AbstractPage) {
return declare('vps.member.DisableDeviceButton', [_AbstractPage], {
templateString: template,
_sp:"switch_sp",
onStartup: function() {
if (dom.byId('switch_sp')){
domStyle.set(this._sp, "display", "none");
}
}
});
});
