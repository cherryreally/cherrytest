define([
'jquery'
], function($) {

function _setTemporaryMeasures() {

var currentUrl = location.href;


}

return {
setTemporaryMeasures: function () {
return _setTemporaryMeasures();
}
};

});
