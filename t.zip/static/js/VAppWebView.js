(function() {
	function _isVApp() {
		var matches = window.navigator.userAgent.toLowerCase().match(/com\.smbc_card\.vpass\.(android|ios)_v([\d\.]+)/);
		if (!matches) {
			return false;
		}

		var os = matches[1];
		var version = matches[2].split('.');
		var major = version[0] ? parseInt(version[0]) : 0;
		var minor = version[1] ? parseInt(version[1]) : 0;
		var build = version[2] ? parseInt(version[2]) : 0;

		return (major >= 3 || (major == 2 && minor >= 5));
	}

	function _isBCApp() {
		 var matches = window.navigator.userAgent.toLowerCase().match(/smbcapp\.(android|ios|unknown)_v([\d\.]+)/);
		 if (!matches) {
			 return false;
		 }

		return true;
	}

	// Lineミニアプリ
	function _isLMApp() {
		if(document.cookie){
			var tmp = document.cookie.split('; ');
			for(var i = 0; i < tmp.length; i++){
				var kv = tmp[i].split('=', 2);
				if (kv[0] == 'cc-lmapp') {
					return true;
				}
			}
		}

		return false;
	}

	function _isAppWV() {
		return _isVApp() || _isBCApp() || _isLMApp();
	}

	function _prepareVAppWebView() {
		if (!_isAppWV()) {
			return;
		}

		if (_isLMApp()) {
			if (!$(document.body).hasClass('LMApp')) { // Lineミニアプリの場合
				$(document.body).addClass('LMApp');
				// CSS読み込みタグの追加
				$(document.head).append('<link rel="stylesheet" href="/static/responsive/css/LMApp.css">');
			}
		} else if (!$(document.body).hasClass('VAppWebView')) {
			// bodyにclassを付加
			$(document.body).addClass('VAppWebView');
			if (_isBCApp()) {
				$(document.body).addClass('BCAppWebView');
			}

			// CSS読み込みタグの追加
			$(document.head).append('<link rel="stylesheet" href="/static/responsive/css/VAppWebView.css">');
		}
	}

	if (_isAppWV()) {
		var poling = setInterval(function() {
			if (document.body) {
				clearInterval(poling);
				_prepareVAppWebView();
			}
		}, 100);
	}

})();
