var com = com || {};
com.smbc_card = com.smbc_card || {};

(function(ns) {
    
    ns.LayoutModeCookie = {
        COOKIE_LAYOUT_MODE: 'layout_mode',
        LAYOUT_MODE_PC: 'PC',
        LAYOUT_MODE_SP: 'SP',
        COOKIE_LAYOUT_MODE_NEED_SYNC: 'layout_mode_need_sync',
        LAYOUT_MODE_NEED_SYNC_TRUE: 'true',
        LAYOUT_MODE_NEED_SYNC_FALSE: 'false',
        load: function() {
            return $.cookie(this.COOKIE_LAYOUT_MODE);
        },
        save: function(layoutMode) {
            $.cookie(this.COOKIE_LAYOUT_MODE, layoutMode, { path: '/' });
        },
        isNeedSync: function() {
            var value = $.cookie(this.COOKIE_LAYOUT_MODE_NEED_SYNC);
            return (value == this.LAYOUT_MODE_NEED_SYNC_TRUE);
        },
        setNeedSync: function(need) {
            var value = need ? this.LAYOUT_MODE_NEED_SYNC_TRUE : this.LAYOUT_MODE_NEED_SYNC_FALSE;
            $.cookie(this.COOKIE_LAYOUT_MODE_NEED_SYNC, value, { path: '/' });
        }
    };
    
})(com.smbc_card.layout = com.smbc_card.layout || {});
