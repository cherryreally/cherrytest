define.amd.jQuery = true;
define([
'dojo/_base/declare',
'dojo/_base/array',
'dojo/dom',
'jquery'
], function(declare, array, dom, $) {

function _initErrorStyle() {

$('td.onthe_error').each(function() {

$(this).removeClass('js_add_error_area');
});
}

function _adaptErrorStyle() {


$('td.onthe_error').each(function() {

var ua = navigator.userAgent;
var av = window.navigator.appVersion.toLowerCase();
var isErrorMessageFound = false;

$(this).find('.error_text').each(function() {

if (isErrorMessageFound) {
return;
}

if ($(this).css('display') != 'none') {
isErrorMessageFound = true;
}
if (ua.match(/msie/i) && av.indexOf("msie 8.") != -1) {
if($(this).closest("td").prev().is("th")){
$(this).closest("td").prev("th").hide();
$(this).closest("td").prev("th").show();
}
}
});

if (isErrorMessageFound) {
$(this).addClass('js_add_error_area');
$(this).find('.changePanel').show();
} else {
$(this).removeClass('js_add_error_area');
}
});
}

function _scrollToTopFailedNode(failedNodeList) {

var undefined;
var headNode;

array.forEach(failedNodeList, function(failedNode, index) {

var node = $('#' + failedNode.id);
var top = _getTopOf(node);

if (headNode === undefined || top < _getTopOf(headNode)) {
headNode = node;
}
});

if (headNode !== undefined) {
if (!_isSmartPhone()) {
headNode.focus();
}

var windowHeight = window.innerHeight ? window.innerHeight : $(window).height();
var scrollLeft = _getLeftOf(headNode);
var scrollTop = Math.max(_getTopOf(headNode) - windowHeight / 2, 0);
_scrollTo(scrollLeft, scrollTop);
}
}

function _getTopOf(node) {

var top = node.offset().top;

if (node.attr('type') == 'radio') {
top = node.parent().offset().top;
}
if (node.css('display') == 'none') {
top = node.parent().offset().top;
}

return top;
}

function _getLeftOf(node) {

var left = node.offset().left;

if (node.attr('type') == 'radio') {
left = node.parent().offset().left;
}
if (node.css('display') == 'none') {
left = node.parent().offset().left;
}

return left;
}

function _isSmartPhone() {

var ua = navigator.userAgent;
if ((ua.search(/iPhone/) != -1)
|| (ua.search(/iPad/) != -1)
|| (ua.search(/Android/) != -1)) {
return true;
}

return false;
}

function _scrollTo(left, top) {
if (_isSmartPhone()) {
window.scrollTo(left, top);
} else {
$('html, body').animate({ scrollLeft: left, scrollTop: top });
}
}

return {

init: function() {

_initErrorStyle();
},

onValidationFailed: function(failedNodeList) {

_adaptErrorStyle();
_scrollToTopFailedNode(failedNodeList);
}
};
});
