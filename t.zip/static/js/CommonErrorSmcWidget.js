define([
'dojo/_base/declare',
'dojo/text!./CommonErrorSmcWidget.html',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/_WebApiResponse',
'vp/alcor/view/ErrorMessage',
'vps/member/WebApiConst',
'vpx/view/ActionPreparatorCommonError',
'vp/alcor/control/StoreManager',
'dojo/dom-style',
'vps/member/DisableDeviceButton'
], function(declare, template, _AbstractPage, TransitionManager,
WebApiResponse, ErrorMessage, WebApiConst, ActionPreparatorCommonError, StoreManager, domStyle) {
return declare('vps.member.common.CommonErrorSmcWidget', [_AbstractPage],
 {
templateString: template,
cssClass: 'mainWidgetBase',

onStartup: function() {
if (!this.errorDetails) {
TransitionManager.transit({
webApiId: WebApiConst.COMMON_GET_ERROR_SERVICE,
doMove: false,
success: function(res) {
var webApiResponse = new WebApiResponse(res);
ErrorMessage.applyResponseErrors([undefined, webApiResponse.getErrorDetails()], false);
}
});
}
var res = StoreManager.getUserData("U337_displaynon");
if(res === 'ON') {
domStyle.set('c_C001190-toplink', 'display', 'none');
StoreManager.removeUserData("U337_displaynon");
}

this.onNode('c_C001190-toplink', 'click', function() {
TransitionManager.transit({
webApiId: WebApiConst.COMMON_GET_TOP_LINK_SERVICE
});
});
ActionPreparatorCommonError.showFixedCommonError();
}
});
});
