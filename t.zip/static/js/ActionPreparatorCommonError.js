﻿define.amd.jQuery = true;
define([
'dojo/_base/declare',
'jquery'
], function (declare, $) {

function _switchDisplay(target, show) {
if (show === true){
target.show();
} else if (show === false){
target.hide();
}
}

return {
showFixedCommonError: function(){
var target = $('.ActionFixedCommonError');
var show = !$('#vp-view-err_common').text().length;
_switchDisplay(target, show);
}
};
});

