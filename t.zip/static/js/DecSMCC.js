//console.log('start of DecSMCC.js');
//console.log("ds_tci_202212_category is " + ((typeof ds_tci_202212_category === 'undefined')?("un"):("already"))+"-defined");
ds_tci_202212_ =( function(){
////////////////////////////////////////////////////////////////////////
//this_load定義
//		+---build_options
//		|		+--OPTION組立
//		|
//		+---dec_loader
//		|		+--mba_actions
//		|
//		+---build_banner
//				+--onclick登録、バナー構築、表示
//
//taboff
//BannerClick
//		+---build_options
//		|		+--OPTION組立
//		|
//		+---MBA.init
//		+---MBA.toggle
//
//this_load()を実行する（window.addEventListener('load')の代替）
////////////////////////////////////////////////////////////////////////

var DEC_DOMAIN_NAME		= 'smcc';
var DEC_URL				= 'https://mobi.lineomni.jp';
var DEC_MOBI_LOADER		= DEC_URL + '/web/mobi-agent-client-frame-loader.min.js?domainId=' + DEC_DOMAIN_NAME +'&dec=load';
var OPTION = {};

//サンプル用各種書き換え用の変数。
var URLtype = "";

//オプション用JSON組み立てる。
function build_options(){
	
	///デバッグ用処理。URLパラメタからroomtagを設定する。
	//60：CLOVAに渡すURL、59：GID、8:問合せの区分（通称ラベル）。
	var v60 = location.href.substring(0,99); //"https://test.com/touroku";
	var v59 = _satellite.getVar("sc_eVar25");
	var v8  = "Not Specified"; //問合せ一覧の列にある。
	//search = new URLSearchParams(window.location.search);
	//if( search.has('roomTag60') ) {	v60 = search.get('roomTag60'); }
	//if( search.has('roomTag59') ) {	v59 = search.get('roomTag59'); }
	//if( search.has('location' ) ) {	v8  = search.get('location');  }
	
	URLtype  = v60;
	var GID = v59;
	if( typeof ds_tci_202212_category !== 'undefined' ){
		v8 = ds_tci_202212_category;//別スクリプトで宣言・設定されることを期待。
	}
	//★出し分け、およびGID連携用のJSONをマージする。
	OPTION = Object.assign({},{ roomTag60 : URLtype , roomTag59: GID , location: v8 }  );
	//console.log( sessionStorage.getItem("com.adobe.reactor.dataElements.sc_eVar25") );
	//console.log(OPTION);
}


function build_banner_core(DecTab, defonclick, delonclick ){

	DecTab.style.cssText = "display: block; cursor: pointer; position: fixed; z-index: 9999; visibility: visible; overflow: hidden; height: 225px; width: 65px;right: 0px; top: 181.5px;";
	def = document. createElement("img");
	def.id = "DEC_TAB_DEF";
	def.src = "https://mobi.lineomni.jp/api/globalPublicFiles/mst/smcc/DEC_TAB_DEF.png";
	def.style.cssText ="max-width: none; width: 65px; height: 225px;"
	def.onclick = defonclick;
	DecTab.appendChild(def);
	
	del = document. createElement("img");
	del.id = "DEC_TAB_DEL";
	del.src = "https://mobi.lineomni.jp/api/globalPublicFiles/mst/smcc/DEC_TAB_DEL.png";
	del.style.cssText ="width: 65px; height: 44px; left: 0px; top: 181px; position: absolute; cursor: pointer;"
	del.onclick = delonclick; 
	DecTab.appendChild(del);
}


function build_banner(){
	//////////////////////
	var exist = document.getElementById("DecTab");
	if( exist ) {	return;	}
	
	
	//バナーボタンやアクションを構築
	
	DecTab = document.createElement("div");
	DecTab.id = "DecTab";
	DecTab.style.cssText = "display: block; cursor: pointer; position: fixed; z-index: 9999; visibility: visible; overflow: hidden; height: 225px; width: 65px;right: 0px; top: 181.5px;";
	document.body.appendChild(DecTab);
	
	//console.log("banner build type: " + typeof ds_tci_202212_build_banner_core );
	if( typeof ds_tci_202212_build_banner_core === 'function' ){
		ds_tci_202212_build_banner_core(DecTab,BannerClick,taboff );
	}else{
		build_banner_core(DecTab,BannerClick,taboff);
	}
}

//一時的define書き替え（保全）監視を解除するためのフラグ
let DEC_SUPPORT_DOJO_TIMER2 = false;//MBAのJSの処理完了フラグ。1番はいろいろあって欠番。
let DEC_SUPPORT_DOJO_timeval;
let DEC_SUPPORT_DOJO_count = 0;//処理時間見積ためのカウンタ（インターバル間隔で算出）

//フラグをwatchdog監視する。
function watchdogloader(){
	DEC_SUPPORT_DOJO_count++;
	if( DEC_SUPPORT_DOJO_TIMER2 == true ){
		clearInterval(DEC_SUPPORT_DOJO_timeval);
		//console.log("all of JSs loaded " + DEC_SUPPORT_DOJO_count +" times" );
		window.define= window._define;
		window._define= undefined;
	}
	//console.log("waiting " + DEC_SUPPORT_DOJO_TIMER2);
}

function this_load(){
	//本JSの2重処理防止
	var exist = document.getElementById("DEC_SUPPORT_ORIGIN");
	if( exist ) {	
		//console.log("find DEC_SUPPORT_ORIGIN");
		return;	
	}else{
		//console.log("DEC_SUPPORT_ORIGIN will be added.");
		var origin = document.createElement("div");
		origin.id = "DEC_SUPPORT_ORIGIN";
		document.body.appendChild(origin);
	}
	
	//loadロード時に、設置ページを判別し、出し分け用のJSONを構築する。
	//build_options();
	//console.log("build OPTION done" );
	//////////////////////
	//MBAの準備。
	//このローダの延長でinitしても良いが、roomtag反映タイミングをチャット開始ギリギリ（バナークリック）まで待ちたいので
	//ここでは、initしない。
	dec_loader(0);
	//console.log("dec_loader done." );
	//バナー構築。
	build_banner();
	
}

function sendWelcome(){
	MobiAgentClient.sendGuestHiddenMessage(URLtype);
	//console.log("sendWelcome");
}
//SDKが扱うチャットウィンド用イベントのアクションを構築する。
function mba_actions(){
	MobiAgentClient.on('roomReady', function (data) {
		//console.log("mba roomReady");
	});
	MobiAgentClient.on('operatorTimeout', function (data) {
		//console.log("mba operatorTimeout");
	});
	MobiAgentClient.on('operatorReady', function () {
		//console.log("mba operatorReady");
		DecLocationCheck.operatorReady();
	});
	//startは、init開始直後（callbackよりも先）に実行される。
	MobiAgentClient.on('start', function (data) {
		//console.log("mba start");
		hiddenFrame();
	});
	//sdkReadyは、init後にerrorが無い場合に、実行される。
	MobiAgentClient.on('sdkReady', function (data) {
		//console.log("mba sdkready " + URLtype );
		DecLocationCheck.sdkReady();
		//隠し文字を送る。Clovaの応答を誘導するため。
		//__startの応答が発生するときに、隠しメッセが無視される場合があるので意図的に送信を遅延させる。
		//100msecでは不十分だった。
		setTimeout(sendWelcome,500);
		
		//チャットウィンドウを開く。
		MobiAgentClient.toggle(true);
	});
	//エラーイベントは、営業日時外・対応上限超過・対応停止等の理由がある状態でinitした時に発生する。
	MobiAgentClient.on('error', (data) => {
		//console.log("mba error");
		//console.log(data);
		//チャットウィンドウはヘッダ部分のみ表示される。チャットウィンドウを開くためには、toggleを呼ぶ。
		//MobiAgentClient.toggle(true);
		DecTmpInfo.hideUserInfoForm();
		//DecTmpInfo.deleteInputData();//消去しない方針に決定。
	});
	//チャットウィンドウを最小化後に復帰した場合に実行される。
	MobiAgentClient.on('openFrame', function() {
		//console.log("openFrame");
		hiddenBanner();
		visibleFrame();
		//console.log("openFrame end");
	});
	//チャットウィンドウを最小化した場合に実行される。
	MobiAgentClient.on('closeFrame', function() {
		//console.log("closeFrame");
		visibleBanner();
		hiddenFrame();
		//console.log("closeFrame end");
	});
	//ルーム終了した場合に実行される。
	MobiAgentClient.on('roomClosed', function() {
		//console.log("roomClosed");
		DecLocationCheck.roomClosed();
		DecTmpInfo.hideUserInfoForm();
		DecTmpInfo.deleteInputData();//ルーム終了時に消去する。
	});
	//Xボタンでチャットウィンドウが消失したタイミングで実行される。
	MobiAgentClient.on('closeChatView', function() {
		//console.log("closeChatView");
		//closeChatViewイベント発生時はチャットウィンドウは消失し、ページリロードしないと復活しない。
		//が、dec_loaderを呼んでSDKを除去・再ロードすることで、チャットウィンドウを再度表示させる。
		//Loadイベント発生ではないので、windowなどの初期化は実行されない。
		//引数はただのデバッグ調査用、動作に影響しない。
		dec_loader(1);
		//console.log("closeChatView end");
		//おそらくここでも情報フォームの非表示クリア処理が必要と思われる。
	});
	//「再読み込みを行う」をクリックした場合に実行される。
	MobiAgentClient.on('reload', function(){
		//console.log("reload");
		DecTmpInfo.hideUserInfoForm();
		DecTmpInfo.deleteInputData();//ルーム終了時に消去する。
	});
	MobiAgentClient.on('messageReceived', function(data) {
		// オペレータからトリガー文言が送信された場合
		if(data.sender === 'operator' && data.text.replace(/\r?\n/g,"") === DecTmpInfo.getTriggerMsg()) {
			DecTmpInfo.showUserInfoForm();
		}
	});
	MobiAgentClient.on('sdkSocketClosed', function() {
		//console.log("sdkSocketClosed");
	});
	MobiAgentClient.on('sdkSocketReconnected', function() {
		//console.log("sdkSocketReconnected");
	});
	
	//console.log("mba_loader end. MBA SDK available. ");
	
	//checkDomainStatusWithGroupは将来を見越した記述。
	MobiAgentClient.checkDomainStatusWithGroup(DEC_URL, DEC_DOMAIN_NAME, "Not Specified", function(err, result){
		//console.log(err);
		//console.log(result);
	});	
	//MBA用JSの処理が完了したので停止フラグ２を立てる。
	//タイミングはここの位置では無く、本関数の頭あるいは、もっと適切な場所があるかもしれない。
	DEC_SUPPORT_DOJO_TIMER2 = true;
}

//チャットウィンドウ用SDKをロードする
//ロード時のコンテキストは、本サンプルでは下記のとおり。
//1:Xボタンでチャットウィンドウが消失したタイミング。
//0:ページをロードしたタイミング。
//コンテキストはログ表示にのみ使用。
function dec_loader(context){
	
	////AMDのdefine干渉（Dojo）対策
	//ここから、DEC_MOBI_LOADERのロードが完了するまでは、defineをラップして、引数1つ（MBAが使用）の時はスルーする。
	//tiveInterval(100ms)でフラグ（MBAのJS処理完了）を監視する。
	//開始位置はここではなく、appendChild直前でもよいかもしれない。
	window._define = window.define;
	//console.log(window._define);
	window.define = ((define) => (...args) => {
		if( args.length !== 1 ){
			//console.log("the case of Dojo usage found.");
			define(...args);
		}else{
			//do nothing 
			//console.log("the case of MBA usage found.");
		}
	})( window.define );
	//console.log("window.define modifyed.");
	DEC_SUPPORT_DOJO_TIMER2  = false;
	DEC_SUPPORT_DOJO_count   = 0;
	DEC_SUPPORT_DOJO_timeval = setInterval(watchdogloader,100);
	////AMDのdefine干渉（Dojo）対策　ここまで

	var kc = document.getElementById('konnect-container');
	if(!kc){
		//console.log("not found kc context:"+ context);
	}else {
		//console.log("kc deleted ");
		kc.remove();
		delete window.MobiAgentClient;
	}
	
	var mobi = document.getElementById('mba_loader');
	if(!mobi){
		//console.log("not found mobi loader  context:"+ context);
	}else {
		//console.log("mobi loader  deleted ");
		mobi.remove();
	}
	var sc = document.createElement('script'); 
	sc.onload  = mba_actions;
	sc.id = 'mba_loader';
	sc.src =DEC_MOBI_LOADER;
	document.body.appendChild(sc);
	//console.log("reloaded context:"+context);
}

//バナーボタン表示・非表示、チャットウインドウ表示・非表示切替サブルーチン
function visibleBanner(){
	//console.log('visibleBanner');
	var imgBanner = document.getElementById("DecTab");
	imgBanner.style.display = "block";
	imgBanner.style.zIndex = '99999';
	//console.log('visibleBanner end');
}
function hiddenBanner(){
	//console.log('hiddenBanner');
	var imgBanner = document.getElementById("DecTab");
	imgBanner.style.display = "none";
	imgBanner.style.zIndex = '-1';
	//console.log('hiddenBanner end');
}
function visibleFrame(){
	//console.log('visibleFrame');
	var frame = document.getElementById("konnect-container");
	frame.style.display = "block";
	frame.style.zIndex = '99998';
	//console.log('visibleFrame end');
}
function hiddenFrame(){
	//console.log('hiddenFrame');
	var frame = document.getElementById("konnect-container");
	frame.style.display = "none";
	frame.style.zIndex = '-1';
	//console.log('hiddenFrame end');
}

//★タブを非表示にする。復活させるにはリロードする。
function taboff(){
	tab = document.getElementById("DecTab");
	tab.style.display = "none";
}

//★バナークリック時のアクション
function BannerClick(){
//バナークリックのタイミングでGIDを設定する。
	build_options();
	//init初期化。
	MobiAgentClient.init(
		DEC_URL, DEC_DOMAIN_NAME, OPTION, function(){ //console.log("cb");//console.log(OPTION); 
		DecTmpInfo.UserInfoFormInit(); } // callback
	);
	MobiAgentClient.toggle(true);
}

DecTmpInfo = (function () {
	var _konnectContainer = null; // web小窓ラッパー要素
	var _createdElement = {};
	var _customerData = {
		dsUserInfoNameKanji: '',
		dsUserInfoNameKana: '',
		dsUserInfoBirthDay: '',
		dsUserInfoPhoneNum: '',
		dsUserInfoCardName: ''
	};  // 一時情報入力データ格納	
	var _tmpInfoDisplayTriggerMsg = 'お客さまの情報をお調べしたうえでご案内いたします。画面上部の「お客さま情報入力」にご入力後、「入力完了」ボタンを押下してください。なお、お客様情報を特定後、追加のご本人様確認としてお客様の情報を何点かお伺いいたします。あらかじめご了承ください。';
	var _inputCmpMsg = '入力完了'; // 入力完了メッセージ

	var UserInfoFormInit = function(){
		_setWebChatContainer();
		if(!_konnectContainer) {
			//console.log("Not yet konnect-container exist.");
			return;
		}
		_addCss(); // お客様情報入力画面用css追加
		_createHtmlUserInfoForm(); // お客様情報入力フォーム生成
		var _createdElementList = ['dsUserInfoForm'];
		for (var i = 0; i < _createdElementList.length; i++) {
			_setCreatedElement(_createdElementList[i]); // アクションに使用する要素を格納
		}
		_closeUserInfoForm(); // お客様情報入力フォーム 閉じるボタン押下時のアクション定義
	}

	/**
	* _setWebChatContainer
	*
	* Web小窓のラッパー要素を格納する
	*
	*/
	var _setWebChatContainer = function () {
		_konnectContainer = document.getElementById('konnect-container');
	}

	/**
	* _createElement
	*
	* DOMを生成し、属性を設定して返却する
	*
	* @param elem {String} 生成する要素
	* @param　attrObj　{obj} 生成する要素の属性
	*
	* @return　element　{obj} 生成した要素
	*
	*/
	var _createElement = function (elem, attrObj) {
		var element = document.createElement(elem);
		if (!elem) {
			return;
		}
		if (attrObj) {
			for (var attr in attrObj) {
				element[attr] = attrObj[attr];
			}
		}
		return element;
	}

	/**
	* _addCss
	*
	* お客様情報入力用のcssをheadに追加する
	*
	*/
	var _addCss = function () {
		var css = document.createElement('style');
		css.innerText = '.ds-user-info-form {font-family: Meiryo, メイリオ, Hiragino Kaku Gothic Pro, ヒラギノ角ゴ Pro W3, Osaka, MS PGothic, arial, helvetica, sans-serif; display: none; border: 1px solid rgb(224, 224, 224); position: absolute; z-index: 99999; right: 0; top: 0; left: 0; overflow-y: auto; max-height: 45%; border-radius: 5px 5px 0 0; background: rgb(235, 235, 235); -webkit-overflow-scrolling: touch;}' +
																																																																																										/*フォーム背景色元の色rgb(204, 204, 204)*/
		'.ds-user-info-form.open {display: block;}' +
		'.ds-user-info-form.is-android.hide-temp {display: none;}' +
		'.ds-user-info-form .ds-head{margin: 0.5em 0; border-bottom: 2px solid rgb(242, 242, 242);}' + /*　ヘッダの下側ボーダーラインの色　*/
		'.ds-user-info-form .ds-title-left {padding-left: 10px; margin: 0.5em 0.5em 5px;}' +
		'.ds-user-info-form .ds-scroll-content {overflow-x: auto; padding: 0 1em; -webkit-overflow-scrolling: touch;}' + 
		'.ds-user-info-form .ds-field-wrap {font-size: 13px; line-height: 1.5; margin-top: 0em; color: #575757;}' + /*　エラーメッセの色　*/
		'.ds-user-info-form .ds-field-label {font-weight: 700; color: #555}' + /*　フォームラベルの色　*/
		'.ds-user-info-form .ds-field-label > span {color: rgb(255, 0, 0);}' + /*　フォーム必須ラベルの色　*/
		'.ds-user-info-form .ds-field-ctrl {width: calc(100% - 20px); min-height: 25px; padding: 5px 10px; border: 1px solid #707070; box-sizing: content-box !important;}' + /*　テキストボックスの枠の緑色　*/
																															/*テキストボックスの枠の緑色、元の色#4cabb6　*/
		'.ds-user-info-form .ds-field-ctrl input {font-size: 16px; width: 100%; min-height: 25px; margin: -5px -10px; padding: 5px 9px; border: 1px solid transparent; box-sizing: content-box !important;}' +
		'.ds-user-info-form .ds-footer {font-size: 14px; margin: 10px 0;}' +
		'.ds-user-info-form .ds-footer.is-android {margin-bottom: 60%;}' +
		'.ds-user-info-form .ds-footer .ds-close-btn {font-size: 14px; cursor: pointer; border: none; background: rgb(246,130,19); color: rgb(255, 255, 255); border-style: none; border-radius: 5px; font-family: Roboto, メイリオ, Meiryo, sans-serif !important;}' + /*入力完了ボタン*/
																													/*元のボタン背景色rgb(53, 49, 143)*/
		'.ds-user-info-form .ds-footer .ds-close-btn.is-ie {padding : 4px 3px}';
		document.head.appendChild(css);
	}

	/**
	* _setCreatedElement
	*
	* 生成した要素を格納する
	* 
	* @param　elementsId　{String} 作成した要素のID
	*
	*/
	var _setCreatedElement = function(elementId) {
		_createdElement[elementId] = document.getElementById(elementId);
	}

	/**
	* getCreatedElement
	*
	* 格納した要素を返却する
	* 
	* @param　elements　{String} 生成した要素
	*
	*/
	var getCreatedElement = function(elementId) { 
		return _createdElement[elementId];
	}

	/**
	* _createHtmlUserInfoForm
	*
	* お客様情報入力フォームを生成する
	*
	*/
	var _createHtmlUserInfoForm = function () {
		var formContainer = _createElement('div', {
			'id': 'dsUserInfoForm',
			'className': 'ds-user-info-form'
		});
		_konnectContainer.appendChild(formContainer);
		var userInfoForm = "  <div class='ds-content'>";
		userInfoForm += "    <div class='ds-head'>";
		userInfoForm += "      <h4 class='ds-title-left'>";
		userInfoForm += "        <b>お客さま情報入力</b>";
		userInfoForm += "      </h4>";
		userInfoForm += "    </div>";
		userInfoForm += "";
		userInfoForm += "    <div class='ds-scroll-content'";
		userInfoForm += "      <form>";
		userInfoForm += "      <div class='ds-body'>";
		userInfoForm += "";
		userInfoForm += "          <!-- Customer name -->";
		userInfoForm += "          <div class='ds-field-wrap'>";
		userInfoForm += "            <label class='ds-field-label' for='dsUserInfoNameKanji'>【氏名（漢字）】<span>※必須</span></label>";
		userInfoForm += "            <div class='ds-field-ctrl'>";
		userInfoForm += "              <input id='dsUserInfoNameKanji' name='ds_user_info[dsUserInfoNameKanji]' onblur='DecTmpInfo.sendUserInfo(this)' type='text'>";
		userInfoForm += "              <p style='margin:10px 0px 2px 0px; font-size:13px; display:none; '>氏名を漢字で入力してください</p>";
		userInfoForm += "            </div>";
		userInfoForm += "          </div>";
		userInfoForm += "";
		userInfoForm += "          <!-- userId -->";
		userInfoForm += "          <div class='ds-field-wrap'>";
		userInfoForm += "            <label class='ds-field-label' for='dsUserInfoNameKana'>【氏名（カナ）】<span>※必須</span></label>";
		userInfoForm += "            <div class='ds-field-ctrl'>";
		userInfoForm += "              <input id='dsUserInfoNameKana' name='ds_user_info[dsUserInfoNameKana]' onblur='DecTmpInfo.sendUserInfo(this)' type='text'>";
		userInfoForm += "              <p style='margin:10px 0px 2px 0px; font-size:13px; display:none; '>氏名をカナで入力してください</p>";
		userInfoForm += "            </div>";
		userInfoForm += "          </div>";
		userInfoForm += "";
		userInfoForm += "          <!-- Customer phoneNumber -->";
		userInfoForm += "          <div class='ds-field-wrap'>";
		userInfoForm += "            <label class='ds-field-label' for='dsUserInfoBirthDay'>【生年月日】<span>※必須</span>（例：1990年1月2日）</label>";
		userInfoForm += "            <div class='ds-field-ctrl'>";
		userInfoForm += "              <input id='dsUserInfoBirthDay' name='ds_user_info[dsUserInfoBirthDay]' onblur='DecTmpInfo.sendUserInfo(this)' type='text'>";
		userInfoForm += "              <p style='margin:10px 0px 2px 0px; font-size:13px; display:none; '>生年月日を入力してください</p>";
		userInfoForm += "            </div>";
		userInfoForm += "          </div>";
		userInfoForm += "";
		userInfoForm += "          <!-- Customer phoneNumber -->";
		userInfoForm += "          <div class='ds-field-wrap'>";
		userInfoForm += "            <label class='ds-field-label' for='dsUserInfoPhoneNum'>【登録電話番号】<span>※必須</span>（例：08012345678）</label>";
		userInfoForm += "            <div class='ds-field-ctrl'>";
		userInfoForm += "              <input id='dsUserInfoPhoneNum' name='ds_user_info[dsUserInfoPhoneNum]' onblur='DecTmpInfo.sendUserInfo(this)' maxlength='11' type='text'>";
		userInfoForm += "              <p id='dsUserInfoExtra1_err1' style='margin:10px 0px 2px 0px; font-size:13px; display:none; '>電話番号を半角数字で入力してください</p>";
		userInfoForm += "              <p id='dsUserInfoExtra1_err2' style='margin:10px 0px 2px 0px; font-size:13px; display:none; '>数字のみで入力してください</p>";
		userInfoForm += "              <p id='dsUserInfoExtra1_err3' style='margin:10px 0px 2px 0px; font-size:13px; display:none; '>桁数が不足しています</p>";
		userInfoForm += "              <p id='dsUserInfoExtra1_err4' style='margin:10px 0px 2px 0px; font-size:13px; display:none; '>桁数をご確認ください</p>";
		userInfoForm += "            </div>";
		userInfoForm += "          </div>";
		userInfoForm += "";
		userInfoForm += "          <!-- Customer phoneNumber -->";
		userInfoForm += "          <div class='ds-field-wrap'>";
		userInfoForm += "            <label class='ds-field-label' for='dsUserInfoCardName'>【お調べするカードの名称】</label>";
		userInfoForm += "            <div class='ds-field-ctrl'>";
		userInfoForm += "              <input id='dsUserInfoCardName' name='ds_user_info[dsUserInfoCardName]' onblur='DecTmpInfo.sendUserInfo(this)' type='text'>";
		userInfoForm += "              <p style='margin:10px 0px 2px 0px; font-size:13px; display:none; '></p>";
		userInfoForm += "            </div>";
		userInfoForm += "          </div>";
		userInfoForm += "";
	// androidだとキーボードと「入力完了」ボタンが被る場合があるため、被らないように余白を追加
	//if (DecSupport.GuestUserPlatform.isAndroid()) {
	//  userInfoForm += "<div class='ds-footer is-android'>";
	//} else {
		userInfoForm += "<div class='ds-footer'>";
    //}
		userInfoForm += "        <div style='padding-left: 5px; text-align: center; '>";
	//if (DecSupport.GuestUserPlatform.isIe()) {
	//  userInfoForm += "          <button id='dsCloseBtn' type='submit' class='ds-close-btn is-ie'>入力完了</button>";
	//} else {
		userInfoForm += "          <button id='dsCloseBtn' type='submit' class='ds-close-btn' style='cursor: pointer;'>入力完了</button>";
	//}
		userInfoForm += "        </div>";
		userInfoForm += "";
		userInfoForm += "      </div> <!-- ./ footer -->";
		userInfoForm += "      </form>";
		userInfoForm += "    </div> <!-- ./ scroll-content -->";
		userInfoForm += "  </div> <!-- ./ content -->";
		userInfoForm += "</div> <!-- ./ userInfoForm -->";
		formContainer.innerHTML = userInfoForm;
	}

	/*
	* _closeUserInfoForm
	*
	* お客様情報入力フォーム 閉じるボタン押下時に入力フォームを非表示にする
	*
	*/
	var _closeUserInfoForm = function() {
		document.getElementById('dsCloseBtn').onclick = function(event) {
			event.preventDefault();
			
			//バリデーションエラーのまま送信ボタン押下時なにもしない。
			//完全未入力のまま送信ボタン押下時でも何もしない
			var input_item = null;
			
			//違反を1つでも見つけたらすぐリタンする。全部検査したら複数同時違反処理が必要になてしまう。
			//その箇所にフォーカスする。都度バリデーション状態にするため。
			if( verifycheck( input_item = document.getElementById('dsUserInfoNameKanji')) ){	input_item.focus();	return;	}
			if( verifycheck( input_item = document.getElementById('dsUserInfoNameKana' )) ){	input_item.focus();	return;	}
			if( verifycheck( input_item = document.getElementById('dsUserInfoBirthDay' )) ){	input_item.focus();	return;	}
			if( verifycheck( input_item = document.getElementById('dsUserInfoPhoneNum' )) ){	input_item.focus();	return;	}
			
			
			hideUserInfoForm();
			//deleteInputData();//消去しない方針に決定。
			MobiAgentClient.sendMessage(_inputCmpMsg);
		}
	}

	/*
	* showUserInfoForm
	*
	* お客様情報入力フォームを表示する
	*
	*/
	var showUserInfoForm = function () {
		var target = document.getElementsByClassName('ds-user-info-form')[0];
		if (target) {
			target.classList.add('open');
		}
	}

	/*
	* hideUserInfoForm
	*
	* お客様情報入力フォームを非表示にする
	*
	*/
	var hideUserInfoForm = function() {
		var target = document.getElementsByClassName('ds-user-info-form')[0];
		if(target) {
			target.classList.remove('open');
		}
	}

	/**
	* sendUserInfo
	*
	* DEC Supportに一時情報を送信sendUserInfoする
	* 
	* @param　customerInfo　{obj} フォーカスアウトした要素
	*
	*　入力完了押下時、全チェックのため戻り値を設置する。
	*　false:チェック成功　更新したかどうかは返さない。
	*　true:チェック失敗
	*/
	function sendUserInfo(customerInfo) {
		
		///バリデーション
		if( verifycheck(customerInfo) ){
			return true;
		}
		
		if(!isUpdated(customerInfo)) {
			return false;
		}
		
		_customerData[customerInfo.id] = customerInfo.value;
		var formData = '';
		formData += '####################\n';
		formData += '氏名漢字 : ' + _customerData['dsUserInfoNameKanji'] + '\n';
		formData += '氏名カナ : ' + _customerData['dsUserInfoNameKana'] + '\n';
		formData += '生年月日 : ' + _customerData['dsUserInfoBirthDay'] + '\n';
		formData += '電話番号 : ' + _customerData['dsUserInfoPhoneNum'] + '\n';
		formData += 'カード名称 : ' + _customerData['dsUserInfoCardName'];
		formData += '\n';
		formData += '####################\n';
		MobiAgentClient.setTempField(formData); // お客様情報入力送信
		//下記通知は使わない。
		var updatestr = "";
		switch(customerInfo.id){
		case 'dsUserInfoNameKanji': updatestr="名前漢字"; break;
		case 'dsUserInfoNameKana':  updatestr="名前カナ"; break;
		case 'dsUserInfoBirthDay':  updatestr="生年月日"; break;
		case 'dsUserInfoPhoneNum':  updatestr="電話番号"; break;
		case 'dsUserInfoCardName':  updatestr="カード名称"; break;
		}
		//MobiAgentClient.sendGuestHiddenMessage(updatestr+ ': お客様情報が入力されました！'); // 隠しメッセージ送信
		return false;
	}

	/**
	* isUpdated
	*
	* お客さま情報入力フォーム バリデーションチェックを行う
	*
	* 対象フォームに値が更新されている場合、trueを返す
	* 対象フォームに値が更新されていない場合、falseを返す
	*
	* @param　customerInfo　{obj} 入力フォーム要素
	* @return　true|false {Boolean}
	*
	*/

	function isUpdated(customerInfo) {
		if(_customerData[customerInfo.id] !==  customerInfo.value) {
			return true;
		}
		return false;
	}

	/**
	* deleteInputData
	*
	* お客さま情報入力フォーム 入力値を削除する
	*
	*/

	function deleteInputData() {
		document.getElementById('dsUserInfoNameKanji').value = '';           // 氏名
		document.getElementById('dsUserInfoNameKana').value = '';                 // ユーザID
		document.getElementById('dsUserInfoBirthDay').value = '';    // 電話番号
		document.getElementById('dsUserInfoPhoneNum').value = '';    // 追加項目1
		document.getElementById('dsUserInfoCardName').value = '';    // 追加項目2
		
		
		_customerData['dsUserInfoNameKanji'] = '';
		_customerData['dsUserInfoNameKana'] = '';
		_customerData['dsUserInfoBirthDay'] = '';
		_customerData['dsUserInfoPhoneNum'] = '';
		_customerData['dsUserInfoCardName'] = '';
 	}
	/**
	* getTriggerMsg
	*
	* お客様情報入力画面を表示するトリガーメッセージを返却する
	* 
	* @return　_tmpInfoDisplayTriggerMsg　{String} トリガーメッセージ
	*
	*/
	var getTriggerMsg = function() { 
		return _tmpInfoDisplayTriggerMsg;
	}
	
	
	/**********************************/
	var verifyed = false;
	
	//引数：input要素。戻り値：true:バリデーション違反。falseバリデーション整合。
	var verifycheck = function(customerInfo){
		var ret=false;
		
		switch(customerInfo.id){
		case 'dsUserInfoNameKanji': 
		case 'dsUserInfoNameKana':
		case 'dsUserInfoBirthDay': 
			if( !BlankCheck(customerInfo.value) ) {
				customerInfo.style.cssText = "";
				customerInfo.nextSibling.nextSibling.style.display = "none";
				ret = false;
			}else{
				customerInfo.focus();
				customerInfo.style.cssText = "background-color: pink;  border-color: red; border-width :3px; ";
				customerInfo.nextSibling.nextSibling.style.display = "block";
				ret = true;
			}
			break;
			/*
		case 'dsUserInfoBirthDay': 
			var checkresult = YYYYMMDDCheck(customerInfo.value);
			if(  checkresult == 0 ){
				customerInfo.style.cssText = "";
				customerInfo.nextSibling.nextSibling.style.display = "none";
				ret = false;
			}else{
				customerInfo.focus();
				customerInfo.style.cssText = "background-color: pink;  border-color: red; border-width :3px; ";
				customerInfo.nextSibling.nextSibling.style.display = "block";
				ret = true;
			}
			break;
			*/
		case 'dsUserInfoPhoneNum':  
			var checkresult = TelCheck(customerInfo.value); 
			var errid = '';
			var errelm;
			errelm = document.getElementById("dsUserInfoExtra1_err1");	errelm.style.display = "none";
			errelm = document.getElementById("dsUserInfoExtra1_err2");	errelm.style.display = "none";
			errelm = document.getElementById("dsUserInfoExtra1_err3");	errelm.style.display = "none";
			errelm = document.getElementById("dsUserInfoExtra1_err4");	errelm.style.display = "none";
			//console.log(checkresult);
			if( checkresult == 0 ){
				customerInfo.style.cssText = "";
				ret = false;
				break;
			}else if( checkresult == 200 ){
				errid= 'dsUserInfoExtra1_err1'; 
			}else if( checkresult == 1 ){	
				errid= 'dsUserInfoExtra1_err2'; 
			}else if( checkresult == 2 ){	
				errid= 'dsUserInfoExtra1_err3'; 
			}else if( checkresult == 3 ){	
				errid= 'dsUserInfoExtra1_err4'; 
			}
			errelm = document.getElementById(errid);
			errelm.style.display = "block";
			customerInfo.focus();
			customerInfo.style.cssText = "background-color: pink;  border-color: red; border-width :3px; ";
			ret = true;
			break;
		case 'dsUserInfoCardName': 
			ret = false; break;
		}
		
		return ret;
	}
	
	
	/**
	空白除去。空白の定義は諸説ある。
	**/
	function DeleteBlank(val){
		val = val.replaceAll(/\r\n|\r|\n|\t| |　|\s+/g, '');
		val = val.replaceAll(String.fromCharCode(160),'');
		return val;
	}
	/**
	未入力チェック
	true:空白である。
	false:空白でない。
	**/
	function BlankCheck(val){
		var tmp = DeleteBlank(val);
		if( tmp.length == 0 ){
			return true;
		}else{
			return false;
		}
	}
	/**
	数字チェック
	true:数字のみ
	false:数字以外になにか混入。
	**/
	function NumCheck(val){
		var tmp =  DeleteBlank(val);
		for( i=0;i<10;i++){	tmp = tmp.replaceAll(i,'');	}
		if( tmp.length != 0 ){	return false;	}
		return true;
	}
	/**
	電話番号チェック
	0:10桁か11桁の数字である
	1:半角数字以外混入
	2:桁不足（10未満）
	3:桁過剰（12以上）
	200:未入力不正。
	**/
	function TelCheck(val){
		if(BlankCheck(val)){ 	return 200;	}
		var tmp =  DeleteBlank(val);
		if( !NumCheck(tmp) ){	return 1;	}
		if( tmp.length < 10 ){	return 2;	}
		if( tmp.length > 11 ){	return 3;	}
		return 0;
	}
	/**
	結局この西暦年月日チェックは未使用となった。単に未入力チェックのみになった。
	西暦年月日チェック
	使用インタフェース、replaceAll、fromCharCode、RegExp、match、indexOf、new Date、substr
	年月日の漢字はそれぞれ唯一のはず。旧字体等はサポート外。
	0:OK
	1:年月日過不足不正
	2:年月日順序不正
	3:過剰データ混入
	4:過剰データ混入
	10:年の数値以外混入不正
	11:年の桁数不正
	20:月の数値以外混入不正
	30:日の数値以外混入不正
	100:日付不成立
	200:未入力不正。
	**/
	function YYYYMMDDCheck(val){
		if(BlankCheck(val)){return 200;}
		var str =  DeleteBlank(val);
		var KY='年';
		var KM='月';
		var KD='日';
		var DELIMIT='-';
		
		var county = ( str.match( new RegExp( KY, "g" ) ) || [] ).length ;
		var countm = ( str.match( new RegExp( KM, "g" ) ) || [] ).length ;
		var countd = ( str.match( new RegExp( KD, "g" ) ) || [] ).length ;
		if( 1 != county*countm*countd ){	return 1;}
		
		if( str.indexOf(KY) < str.indexOf(KM) && str.indexOf(KM) < str.indexOf(KD) ){	}else{return 2;}
		
		str = str.replaceAll(KY,DELIMIT);
		str = str.replaceAll(KM,DELIMIT);
		str = str.replaceAll(KD,DELIMIT);
		var array_str = str.split(DELIMIT);
		//console.log(array_str);
		if( array_str.length != 4 ){	return 3; }
		if( array_str[3].length != 0 ){	return 4; }
		
		var tmpyy = array_str[0];
		if( !NumCheck(tmpyy) ){			return 10; }
		if( array_str[0].length != 4 ){ return 11; }
		tmpyy = array_str[0];
		
		var tmpmm = array_str[1];
		if( !NumCheck(tmpmm) ){			return 20; }
		tmpmm = '0'+array_str[1];
		tmpmm = tmpmm.substr(-2,2);
		
		var tmpdd = array_str[2];
		if( !NumCheck(tmpdd) ){			return 30; }
		tmpdd = '0'+array_str[2];
		tmpdd = tmpdd.substr(-2,2);
		
		var date= new Date(tmpyy,tmpmm-1,tmpdd);
		var checkyear  = date.getFullYear();
		var chedkmonth = '0'+ (date.getMonth()+1) ;
		chedkmonth = chedkmonth.substr(-2,2);
		var chedkdate  = '0'+ date.getDate();
		chedkdate = chedkdate.substr(-2,2);
		var ddcheck = checkyear+''+chedkmonth+''+chedkdate;
		var ddtmp	= tmpyy+''+tmpmm+''+ tmpdd;
		if( ddcheck != ddtmp ){			return 100; }
		
		return 0;
	}
	
	/**********************************/
	
	// public
	return {
		UserInfoFormInit: UserInfoFormInit,
		deleteInputData: deleteInputData,
		getCreatedElement: getCreatedElement,
		hideUserInfoForm: hideUserInfoForm,
		showUserInfoForm: showUserInfoForm,
		sendUserInfo: sendUserInfo,
		getTriggerMsg: getTriggerMsg
	};
}());


DecLocationCheck = (function () {
	//タイマIDは負にならない前提。
	var timer_watch_textarea = -1;
	
	//監視間隔はとりあえず500。200ぐらいでも十分処理できるはず。
	var interval_msec=10;
	
	//無効化切替・プレスホルダ・キャレット操作用要素取得用ID
	//隠ぺい目的の送信ボタン取得用ID
	var target_id = 'mbaGuestFrame_content_input_wrapper_textarea_textarea';
	var target_button_class= 'mbaGuestFrame_content_input_wrapper_textarea_sendButton';
	
	var db =["none",
	//
	//[^\t//START_OF_URLPATH$]が連続する行が要素を列挙開始の目印。
	//
	//START_OF_URLPATH
	//START_OF_URLPATH
'/api/globalPublicFiles/mst/smccdemo01/DecSMCC070599.html',
'/api/globalPublicFiles/mst/smccdemo01/DecSMCC09045999.html',
'/api/globalPublicFiles/mst/smccdemo01/DecSMCC0904003.html',
'/api/globalPublicFiles/mst/smccdemo01/DecSMCC0904004.html',
'/request',
'/l/998521/2022-11-10/2gv6',
'/l/998521/2022-11-29/36pl',
'/l/998521/2023-01-20/5nbc',
'/l/998521/2022-12-26/4qvh',
'/l/998521/2023-01-29/67b8',
'/l/998521/2023-01-29/67bg',
'/l/998521/2023-02-06/6vrn',
'/memx/corporate/login/index.html',
'/memx/corporate/top/index.html',
'/hojin/admin/index.jsp',
'/hojin/admin_business/index.jsp',
'/s/login',
'/s/',
'/s/ExamineRequestInput',
'/s/ExamineRequestInputB',
'/s/ReceptionExamination',
'/s/ReceptionExaminationB',
'/s/ReceptionJoinRequest',
'/s/ReceptionDocuments',
'/s/ReceptionDocumentsB',
'/s/ReceptionJoinCompleted',
'/s/ReceptionJoinCompletedB',
'/s/ReceptionInput',
'/s/ReceptionInputB',
'/s/Inquiry',
'/s/ExamineRequestCheck',
'/s/ExamineRequestCheckB',
'/s/ReceptionCheck',
'/s/ReceptionCheckB',
'/IdRequestIntro/IdRequest',
'/IdRequestIntro',
'/hojin/inquiry/chat/corporate.jsp',
'/hojin/inquiry/chat/business.jsp',

'/kamei/start/top.jsp',
'/kamei/start/support.jsp',
'/kamei/index.jsp',
'/merchantx/top/index.html',
'/kamei/inquiry/index.jsp',
'/kamei/list',
'/kamei/uriage/meisai/index.jsp',
'/kamei/netservice/update.jsp',
'/kamei/netservice/omatome.jsp',
'/merchantx/furikomi/index.html',
		
	//END_OF_URLPATH
	//END_OF_URLPATH
	//
	//
	"endofarray"];
	
	//これらフラグは名前空間外に公開する。DecLocationCheckで修飾する。
	var flg_operatorReady = false;
	var flg_companyPage = false;
	
	var watchdog_textarea = function(){
		//console.log("watchdog_textarea");
		
		//要素が無いのは、バナー状態・歯車メニュ表示中でテキストエリアが無い状態。
		var kf  = document.getElementById('konnect-frame');
		if( !kf ){return; }
		var ta  = kf.contentWindow.document.getElementById(target_id);
		if( !ta ){return; }
		var tb = kf.contentWindow.document.getElementsByClassName(target_button_class);
		if( !tb ){	return; }
		if( tb.length != 1 ){ return;	}
		
		//console.log("DecLocationCheck watchdog_textarea ");
		//console.log( DecLocationCheck.flg_companyPage == true   && DecLocationCheck.flg_operatorReady == false  );
		//console.log( "flg_companyPage:"   + DecLocationCheck.flg_companyPage   +  "      flg_operatorReady:" + DecLocationCheck.flg_operatorReady );
		
		if( DecLocationCheck.flg_companyPage == true   && DecLocationCheck.flg_operatorReady == false ){
			ta.disabled = true;
			ta.placeholder  = "";
			ta.classList.add("input_bgcolor");
			ta.classList.add("input_textcolor");
			ta.classList.add("input_caretcolor");
			//tb[0].classList.add("send_buttoncolor");
			tb[0].style.display ="none";
		}else{
			ta.disabled = false;
			ta.placeholder  = "短い文章でご質問をどうぞ";
			ta.classList.remove("input_bgcolor");
			ta.classList.remove("input_textcolor");
			ta.classList.remove("input_caretcolor");
			//tb[0].classList.remove("send_buttoncolor");
			tb[0].style.display ="inline-block";
		}
		
	}
	
	var sdkReady = function () {
		//console.log("DecLocationCheck sdkready start");
		//sdkreadyでは、設置場所の判定、監視スレッド起動のみを行う（他の処理はさせない）。
		
		//URLパスの判定処理は、sdkredy時に1回のみ実施。
		//URLページ移動（新規GET）すれば移動先でsdkready実行・再判定されるので1度の判定で十分。
		DecLocationCheck.flg_operatorReady = false;
		
		//DecLocationCheck.flg_companyPage =  db.includes(document.location.href);
		var document_location_pathname = document.location.pathname;
		//JS互換性のためforEach使用。pathnameはローカル変数に写す。
		//dbに100文字（パス名）ｘ1000行（設置場所）あっても10msec以内で判定する想定。
		db.forEach(function(elem) {
			if(   document_location_pathname  === elem ){
				DecLocationCheck.flg_companyPage = true ;
			}
		});
		
		//console.log("DecLocationCheck sdkReady flg_companyPage "+ DecLocationCheck.flg_companyPage);
		//万が一タイマが動いていたら停止する（sdkreadyが2度も呼ばれることはないはず）
		if( timer_watch_textarea != -1 ){
			//console.log("sdkReady timer clear"+timer_watch_textarea);
			clearInterval(timer_watch_textarea);
		}
		//URLパス判定後にスレッド生成。
		timer_watch_textarea = setInterval(watchdog_textarea,interval_msec);
		//console.log("DecLocationCheck sdkReady "+timer_watch_textarea);
	}
	
	//イベント処理はフラグ操作のみに限定。フラグに基づいた処理は監視スレッド側にさせる。
	var operatorReady = function(){
		DecLocationCheck.flg_operatorReady = true;
		console.log("DecLocationCheck operatorReady :"+ DecLocationCheck.flg_operatorReady);
	}
	var roomClosed = function(){
		DecLocationCheck.flg_operatorReady = false;
		//console.log("DecLocationCheck roomClosed : "+ DecLocationCheck.flg_operatorReady);
	}
	return {
		//2つのフラグを公開する。
		flg_operatorReady:flg_operatorReady,
		flg_companyPage:flg_companyPage,
		roomClosed:roomClosed,
		operatorReady:operatorReady,
		sdkReady: sdkReady
	};
}());


//window.addEventListener('load')の代替）。
//本JSは基本は、動的なロードを想定しておらず、
//HTMLへのハードコーディングされる（window.addEventListener('load')が実行される）こと期待する。
//が、タグマネージャ等で動的に本JSをロードする場合を保証するため、初期処理を呼ぶ。
return {
	this_load:this_load
	};
}());
ds_tci_202212_.this_load();
//console.log('end of DecSMCC.js');
