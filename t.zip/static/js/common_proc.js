/**
 * main script
 * 共通スクリプト/モジュール実行定義等
 *
 * @modified    :    2013.12.25
 * @created        :    2013.11.01
 */
var ua = com.smbc_card.util.UserAgent;
var useragent = {};
useragent.name = window.navigator.userAgent.toLowerCase();
useragent.ver = window.navigator.appVersion.toLowerCase();

useragent.browser = (function(){
    if (useragent.name.indexOf('edge') !== -1) return 'edge';   // Edge
    else if (useragent.name.indexOf("iemobile") !== -1)      return 'iemobile'; // ieMobile
    else if (useragent.name.indexOf('android') !== -1) return 'android';    //android
    else if (useragent.name.indexOf("msie") !== -1 && useragent.name.indexOf('opera') === -1 || useragent.name.indexOf('trident/7') !== -1) return 'ie';    //ie
    else if (useragent.name.indexOf('chrome')  !== -1 && useragent.name.indexOf('edge') === -1)   return 'chrome';  // chrome
    else if (useragent.name.indexOf('safari')  !== -1 && useragent.name.indexOf('chrome') === -1 && useragent.name.indexOf('iphone') == -1) return 'macsafari'; // macsafari
    else if (useragent.name.indexOf('safari')  !== -1 && useragent.name.indexOf('chrome') === -1 && useragent.name.indexOf('iphone') !== -1) return 'iossafari';    // iossafari
    else if (useragent.name.indexOf('opera')   !== -1) return 'opera';                  // Opera
    else if (useragent.name.indexOf('firefox') !== -1) return 'firefox';                // FIrefox
    else return 'unknown_browser';
})();

useragent.version = (function(){
    if (useragent.name.indexOf('trident/7') !== -1) return 11;  // ie11
    else if (useragent.name.indexOf("msie") !== -1 && useragent.name.indexOf('opera') === -1){  //ieバージョン取得
        if      (useragent.ver.indexOf("msie 6.")  !== -1) return 6;    // ie6
        else if (useragent.ver.indexOf("msie 7.")  !== -1) return 7;    // ie7
        else if (useragent.ver.indexOf("msie 8.")  !== -1) return 8;    // ie8
        else if (useragent.ver.indexOf("msie 9.")  !== -1) return 9;    // ie9
        else if (useragent.ver.indexOf("msie 10.") !== -1) return 10;   // ie10
    }
    else if (useragent.name.indexOf('safari')  !== -1 && useragent.name.indexOf('chrome') === -1){ //safariバージョン取得
        var safariversion = useragent.name.match(/version\/([\d]+)/);
        if (safariversion) return safariversion[1]* 1;
        else return 100;
    }
    else if (useragent.name.indexOf('android') !== -1){ //androidバージョン取得
        var androidversion = parseFloat(useragent.name.slice(useragent.name.indexOf("android")+8));
        return androidversion;
    }
    else return 100;
})();

//暗号レベルアップ対応
$.ajax({
    type: "GET",
    url: "/static/responsive/data/security_attention.xml",
    dataType: "xml",
    timeout: 5000,
    error: function() { //xml読み込み失敗時
    },
    success: function(xml) {    //xml読み込み成功時
        $(xml).find("browser").each(function() {
            var name = $(this).find("name").text(); //ブラウザの名称を取得
            var version = $(this).find("version").text() * 1;   //バージョンを取得
            var message = $(this).find("message").text();   //メッセージを取得（ブラウザごとに定義する場合に使用）
            var common_message = $(xml).find("common").text();  //共通メッセージを取得
            var addHTML = '';
            if (name.match(useragent.browser) && useragent.version <= version) {    //xml内に記載されたバージョン数以下のみ実行
                addHTML += '<div class="security_attention forPcBlock"><p>';
                if (!message) {
                    addHTML += common_message;
                } else addHTML += message;
                addHTML += '</p></div>';
                if (useragent.browser.match(/iossafari|android/)) { //sp用のHTMLを挿入
                    $('div#header').append(addHTML);
                    addHTML = '<div class="security_attention forSpBlock"><p>';
                    if (!message) {
                        addHTML += common_message;
                    } else addHTML += message;
                    addHTML += '</p></div>';
                    $('div#contWrap').prepend(addHTML);
                } else $('div#header').append(addHTML); //pc用のHTMLを挿入

                $('div.security_attention').css({
                    'margin-bottom': '0px',
                    'clear': 'both',
                    'font-size': '14px',
                    'padding-top': '10px'
                });

                $('div.security_attention p').css({
                    'padding-bottom': '10px',
                    'padding-left': '10px',
                    'padding-right': '10px',
                    'color': '#d40c0c',
                    'padding-top': '10px',
                    'background': '#fcfcdd',
                    'border': '1px solid #EBEBA9'
                });
                $('div.security_attention a').css({
                    'color': '#0c1e89'
                });
                $('div.security_attention a:link').css({
                    'color': '#0c1e89'
                });
                $('div.security_attention a:visited').css({
                    'color': '#551a8b'
                });
                $('div.security_attention a:hover').css({
                    'color': '#0c1e89'
                });
                $('div.security_attention a:active').css({
                    'color': '#551a8b'
                });
            } else return 0;
        });
    }
});

var app = window.navigator.appVersion.toLowerCase();
var isLteIE8 = (app.indexOf("msie 6.") != -1 || app.indexOf("msie 7.") != -1 || app.indexOf("msie 8.") != -1);
var isLteIE9 = (app.indexOf("msie 9.") != -1);
var isLteIE10 = (app.indexOf("msie 10.") != -1);
// var etype = 'ontouchstart' in window ? 0 : 1,
var etype = ua.name.indexOf("window") != -1 ? 1 : 0;
//var etype = 1;
ev = {
    start: ['touchstart', 'click']
}

var popUpFunc;

var IE7 = navigator.appVersion.indexOf("MSIE 7.") !== -1;

// IE console.log 対策
var alertFallback = true;
if (typeof console === "undefined" || typeof console.log === "undefined") {
    console = {};
    if (alertFallback) {
        console.log = function(msg) {
            //alert(msg);
        };
    } else {
        console.log = function() {};
    }
}

/**
 * アコーディオン
 */

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////querty_1 start///////////////////////////////
// アンカーリンク併用時の高さ合わせ用
$(window).on('load', function () {
    let headerHeight = $('#header').outerHeight();
    let rehash = location.hash;
    if (rehash) {
        $('html,body').stop().scrollTop(0);
        setTimeout(function () {
            var position = $(rehash).offset().top - headerHeight;
            $('html,body').animate({
                scrollTop: position
            }, 'slow');
        }, 100);
    }
});
(function($) {
    var pluginName = "accordion";
    $.fn[pluginName] = function(options) {

        return this.each(function() {
            // init
            var _elem = this;
            var $elem = $(_elem);

            var beforeTxt = $('.acdiBtn', _elem).text();
            var afterTxt = function() {
                switch (beforeTxt) {
                    case '詳しい検索':
                        return '閉じる';
                    case '表示する':
                        return '閉じる';
                }
            }

            //PCボタンなし・SPボタンあり(open)用
            function accordionH2Open() {
                var w = window.innerWidth;
                var x = 640;
                if (w > x) {
                    $('h2.acdiHeadL').find("span").removeClass('off');
                    $('h2.acdiHeadL').find("span").addClass('on');
                    $('h2.acdiHeadL').next('.acdiBody').css("display", "none");
                }
            }

            function accordionH3Open() {
                var w = window.innerWidth;
                var x = 640;
                if (w > x) {
                    $('H3.acdiHead').find("span").removeClass('off');
                    $('H3.acdiHead').find("span").addClass('on');
                    $('H3.acdiHead').next('.acdiBody').css("display", "none");
                }
            }

            function accordionCardPointH3Open() {
                var w = window.innerWidth;
                var x = 640;
                if (w > x) {
                    $('.cardPointWarp H3.acdiHead').find("span").removeClass('off');
                    $('.cardPointWarp H3.acdiHead').find("span").addClass('on');
                    $('.cardPointWarp H3.acdiHead').next('.acdiBody').css("display", "none");
                }
            }

            function accordionH2Close() {
                var w = window.innerWidth;
                var x = 640;
                if (w < x) {
                    $('h2.acdiHeadL').find("span").removeClass('off');
                    $('h2.acdiHeadL').find("span").addClass('on');
                    $('h2.acdiHeadL').next('.acdiBody').css("display", "none");
                }
            }

            function accordionH3Close() {
                var w = window.innerWidth;
                var x = 640;
                if (w < x) {
                    $('H3.acdiHead').find("span").removeClass('off');
                    $('H3.acdiHead').find("span").addClass('on');
                    $('H3.acdiHead').next('.acdiBody').css("display", "none");
                }
            }

            function accordionCardPointH3Close() {
                var w = window.innerWidth;
                var x = 640;
                if (w < x) {
                    $('.cardPointWarp H3.acdiHead').find("span").removeClass('off');
                    $('.cardPointWarp H3.acdiHead').find("span").addClass('on');
                    $('.cardPointWarp H3.acdiHead').next('.acdiBody').css("display", "none");
                }
            }

            $(window).load(function() {
                accordionH2Open();
                accordionCardPointH3Open();
                accordionH2Close();
                accordionCardPointH3Close();
                accordionH3Open();
                accordionH3Close();
            });
            if (ua.isiOS) {
                $(window).on("orientationchange", function() {
                    accordionH2Open();
                    accordionH2Close();
                    accordionCardPointH3Open();
                    accordionCardPointH3Close();
                    accordionH3Open();
                    accordionH3Close();
                });
            } else {
                $(window).resize(function() {
                    //ie8 resize event なし
                    if(!isLteIE8){

                        if (window.innerWidth > 640) {
                            accordionH2Close();
                            accordionCardPointH3Open();
                            accordionH3Close();
                        }

                    }
                });
            }

            function accordionDivOpen() {
                var w = window.innerWidth;
                var x = 640;
                if (w > x) {
                    $('.acdiCaution .acdiHead').find("span").removeClass('off');
                    $('.acdiCaution .acdiHead').find("span").addClass('on');
                    $('.acdiCaution .acdiBody').css("display", "block");

                    $('.acdiCautionType02 .acdiHead').find("span").removeClass('off');
                    $('.acdiCautionType02 .acdiHead').find("span").addClass('on');
                    $('.acdiCautionType02 .acdiBody').css("display", "block");

                    $('.relevantPageWrapArea .acdiHead').find("span").removeClass('off');
                    $('.relevantPageWrapArea .acdiHead').find("span").addClass('on');
                    $('.relevantPageWrapArea .acdiBody').css("display", "block");

                    $('.acdiImportant .acdiHead').find("span").removeClass('off');
                    $('.acdiImportant .acdiHead').find("span").addClass('on');
                    $('.acdiImportant .acdiBody').css("display", "block");

                    $('.cardFeature').parent().find("span").removeClass('off');
                    $('.cardFeature').parent().find("span").addClass('on');
                    $('.cardFeature').parent().next('.acdiBody').css("display", "block");

                    $('.hanyouAcdiType01 .acdiHead').find("span").removeClass('off');
                    $('.hanyouAcdiType01 .acdiHead').find("span").addClass('on');
                    $('.hanyouAcdiType01 .acdiBody').css("display", "block");

                    $('.hanyouAcdiType02 .acdiHead').find("span").removeClass('off');
                    $('.hanyouAcdiType02 .acdiHead').find("span").addClass('on');
                    $('.hanyouAcdiType02 .acdiBody').css("display", "block");
                }
            }

            function accordionDivClose() {
                var w = window.innerWidth;
                var x = 640;
                if (w < x) {
                    $('.acdiCaution .acdiHead').find("span").removeClass('on');
                    $('.acdiCaution .acdiHead').find("span").addClass('off');
                    $('.acdiCaution .acdiBody').css("display", "block");

                    $('.acdiCautionType02 .acdiHead').find("span").removeClass('on');
                    $('.acdiCautionType02 .acdiHead').find("span").addClass('off');
                    $('.acdiCautionType02 .acdiBody').css("display", "block");

                    $('.relevantPageWrapArea .acdiHead').find("span").removeClass('on');
                    $('.relevantPageWrapArea .acdiHead').find("span").addClass('off');
                    $('.relevantPageWrapArea .acdiBody').css("display", "block");

                    $('.acdiImportant .acdiHead').find("span").removeClass('off');
                    $('.acdiImportant .acdiHead').find("span").addClass('on');
                    if (isLteIE8) {
                        $('.acdiImportant .acdiBody').css("display", "block");
                    } else {
                        $('.acdiImportant .acdiBody').css("display", "none");
                    }


                    $('.cardFeature').parent().find("span").removeClass('off');
                    $('.cardFeature').parent().find("span").addClass('on');
                    $('.cardFeature').parent().next('.acdiBody').css("display", "none");

                    $('.hanyouAcdiType01 .acdiHead').find("span").removeClass('off');
                    $('.hanyouAcdiType01 .acdiHead').find("span").addClass('on');
                    $('.hanyouAcdiType01 .acdiBody').css("display", "none");

                    $('.hanyouAcdiType02 .acdiHead').find("span").removeClass('off');
                    $('.hanyouAcdiType02 .acdiHead').find("span").addClass('on');
                    if (isLteIE8) {
                        $('.hanyouAcdiType02 .acdiBody').css("display", "block");
                    } else {
                        $('.hanyouAcdiType02 .acdiBody').css("display", "none");
                    }
                }
            }

            var accordionDivFlag;
            $(window).load(function() {
                accordionDivOpen();
                accordionDivClose();
                accordionDivFlag = true;
            });
            if (ua.isiOS) {
                $(window).on("orientationchange", function() {
                    accordionDivOpen();
                    accordionDivClose();
                });
                $(".acdiBtn").click(function() {
                    accordionDivFlag = false;
                });

            } else {
                $(window).resize(function() {
                  //ie8 resize event なし
                    if(!isLteIE8){

                        if (window.innerWidth > 640) {
                            accordionDivOpen();
                            accordionDivFlag = true;
                        }
                        if (accordionDivFlag == true) {
                            accordionDivClose();
                        }

                    }
                });
                $(".acdiBtn").click(function() {
                    accordionDivFlag = false;
                });
            }

            var proc = function(_target, _e) {
                $(_target).toggleClass('active');
                switch (true) {
                    case $elem.next('.acdiBody')[0] !== undefined:
                        $elem.next('.acdiBody').stop().slideToggle();
                        break;
                    case $elem.prev('.acdiBody')[0] !== undefined:
                        $elem.prev('.acdiBody').stop().slideToggle();
                        break;
                    case $elem.next().find('.acdiBody')[0] !== undefined:
                        $elem.next().find('.acdiBody').stop().slideToggle();
                        break;
                    case $elem.prev().find('.acdiBody')[0] !== undefined:
                        $elem.prev().find('.acdiBody').stop().slideToggle();
                        break;
                    case $elem.parent().next().find('.acdiBody')[0] !== undefined:
                        $elem.parent().next().find('.acdiBody').stop().slideToggle();
                        break;
                    case $elem.parent().prev().find('.acdiBody')[0] !== undefined:
                        $elem.parent().prev().find('.acdiBody').stop().slideToggle();
                        break;
                }
                if ($(_target).hasClass('active')) {
                    $('.acdiBtn', _elem).text(afterTxt);
                } else {
                    $('.acdiBtn', _elem).text(beforeTxt);
                }
            }

            $elem.on('click', function(_e) {
                var $this = $('.acdiBtn', this);

                if ($this.hasClass("on")) {
                    $this.removeClass("on");
                    $this.addClass("off");
                } else if ($this.hasClass("off")) {
                    $this.removeClass("off");
                    $this.addClass("on");
                }

                if (device.tablet()) {
                    $this.css('opacity', 1);
                }
                proc($this, _e);
            });

        });

    };
})(jQuery);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////querty_1 end///////////////////////////////

$('h3.acdiHead').accordion(); /* acdiHeadはh3に限定 */
$('.acdiHeadL').accordion();

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////querty_2 start///////////////////////////////
$(function($) {
    if ($('.scrollWrapArea')[0]) {
        // スクロール
        $('.scrollWrapArea').jScrollPane({
            showArrows: true,
            arrowButtonSpeed: 200
        });
        $('.scrollWrapArea').height(207) // 高さ調整（over ride）
        $(window).on('resize', function() {
          //ie8 resize event なし
            if(!isLteIE8){

                $('.scrollWrapArea').height(180);
                $('.scrollWrapArea').jScrollPane({
                    showArrows: true,
                    arrowButtonSpeed: 200
                });
                $('.scrollWrapArea').height(207) // 高さ調整（over ride）

            }
        });
    }

// タブ
    $(".tabBody").hide();

    $(".tabHead").each(function(e) {
        var int = 0;
        int += e;
        var tabHead = $(".tabHead");
        var thisHead = $(this);

        // localhost 取得
        var url   = location.href;
        var param  = url.split("?");
        var params;
        var getTab = "default";
        if (param.length > 1) {
            params = param[1].split("actTab=");
            if (params.length > 1) {
                getTab = params[1].match(/^..tab/);
            }
        }

        thisHead.closest(".tabAreaWrap").children(".tabBody").eq(0).css({
            "display": "block",
            "clear": "both"
        });

        if (thisHead.hasClass("vertical")) {
            //立て並び
            if (thisHead.hasClass("static")) {
                thisHead.find("ul li a").each(function() {
                    var this_a = $(this);
                    this_a.css("height", "100%");
                });
                if (window.innerWidth > 640) {
                    var tabPadding = "16px 15px";
                } else {
                    var tabPadding = "12px 10px";
                }
                if (isLteIE8 || isLteIE9) {
                    thisHead.find("ul li a").css({
                        "display": "block",
                        "padding": tabPadding,
                        "position": "relative"
                    });
                } else {
                    thisHead.find("ul li a").css({
                        "padding": tabPadding,
                        "position": "relative",
                        "box-sizing": "border-box"
                    });
                }
                thisHead.find("ul li").not(".act").css("padding", "0px");

                $(window).on("resize", function() {
                  //ie8 resize event なし
                    if(!isLteIE8){

                        thisHead.find("ul li a").each(function() {
                            var this_a = $(this);
                            setTimeout(function() {

                            }, 0);
                        });

                    }
                });
            } else {
                //url取得後の処理
                thisHead.find("li").removeClass("act");
                thisHead.closest(".tabAreaWrap").children(".tabBody").hide();
                if (getTab == "02tab" && thisHead.find("li").length >= 2) {
                    $(thisHead.find("li")).eq(1).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(1).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else if (getTab == "03tab" && thisHead.find("li").length >= 3) {
                    $(thisHead.find("li")).eq(2).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(2).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else if (getTab == "04tab" && thisHead.find("li").length >= 4) {
                    $(thisHead.find("li")).eq(3).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(3).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else if (getTab == "05tab" && thisHead.find("li").length >= 5) {
                    $(thisHead.find("li")).eq(4).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(4).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else {
                    $(thisHead.find("li")).eq(0).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(0).css({
                        "display": "block",
                        "clear": "both"
                    });
                }
            }

            thisHead.find("ul li").on("click", function() {
                var thisBody = $(this).closest(".tabAreaWrap").children(".tabBody");
                var thisLi = $(this).closest("ul").children("li");
                var num = thisLi.index(this);
                if (!thisHead.hasClass("static")) {
                    thisBody.hide();
                    thisBody.eq(num).css({
                        "display": "block",
                        "clear": "both"
                    });
                    thisLi.removeClass('act');
                    $(this).addClass('act');
                }
            });

            // ie8・ie9のタブの幅設設定
            if (isLteIE8 || isLteIE9) {
                var list_size = thisHead.find("ul li").size();
                var list_pc_block = thisHead.find("ul li.forPcBlock").size();
                var get_list_width = (100 - ((list_size - list_pc_block) - 1)) / (list_size -
                    list_pc_block);
                var win_w = window.innerWidth;

                if (thisHead.hasClass("static")) {
                    var tab_h = parseInt(thisHead.find("ul li").css("height").replace("px",'')-26);

                }

                //会員TOP用
                if ( thisHead.attr("id") == "tabType02" ) {
                    get_list_width = (100 - ((list_size - list_pc_block) + 5)) / (list_size - list_pc_block);
                    console.log(get_list_width)
                }

                if (win_w < 640 && isLteIE9) {
                    thisHead.find("ul li").css("width", "100%");
                } else {
                    thisHead.find("ul li").css("width", get_list_width + "%");
                }

                $(window).on("resize", function() {
                  //ie8 resize event なし
                    if(!isLteIE8){

                        win_w = window.innerWidth;
                        if (win_w < 640 && isLteIE9) {
                            thisHead.find("ul li").css("width", "100%");
                        } else {
                            thisHead.find("ul li").css("width", get_list_width + "%");
                        }

                    } else {
                        if (thisHead.hasClass("static")) {
                            var tab_w = parseInt(thisHead.find("ul li").css("width").replace("px",'')-20);
                            thisHead.find("ul li a").css("width", tab_w);
                        }
                    }
                });

            }
        } else {
            //横並び
            if (thisHead.hasClass("static")) {
                thisHead.find("ul li a").each(function() {
                    var this_a = $(this);
                    this_a.css("height", "100%");
                });
                if (window.innerWidth > 640) {
                    var tabPadding = "16px 15px";
                } else {
                    var tabPadding = "12px 10px";
                }
                if (isLteIE8 || isLteIE9) {
                    thisHead.find("ul li a").css({
                        "display": "block",
                        "padding": tabPadding,
                        "position": "relative"
                    });
                } else {
                    thisHead.find("ul li a").css({
                        "padding": tabPadding,
                        "position": "relative",
                        "box-sizing": "border-box"
                    });
                }
                thisHead.find("ul li").not(".act").css("padding", "0px");
            } else {
                //url取得後の処理
                thisHead.find("li").removeClass("act");
                thisHead.closest(".tabAreaWrap").children(".tabBody").hide();
                if (getTab == "02tab" && thisHead.find("li").length >= 2) {
                    $(thisHead.find("li")).eq(1).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(1).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else if (getTab == "03tab" && thisHead.find("li").length >= 3) {
                    $(thisHead.find("li")).eq(2).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(2).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else if (getTab == "04tab" && thisHead.find("li").length >= 4) {
                    $(thisHead.find("li")).eq(3).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(3).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else if (getTab == "05tab" && thisHead.find("li").length >= 5) {
                    $(thisHead.find("li")).eq(4).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(4).css({
                        "display": "block",
                        "clear": "both"
                    });
                } else {
                    $(thisHead.find("li")).eq(0).addClass("act");
                    thisHead.closest(".tabAreaWrap").children(".tabBody").eq(0).css({
                        "display": "block",
                        "clear": "both"
                    });
                }
            }

            thisHead.find("ul li").on("click", function() {
                var thisBody = $(this).closest(".tabAreaWrap").children(".tabBody");
                var thisLi = $(this).closest("ul").children("li");
                var num = thisLi.index(this);
                if (!thisHead.hasClass("static")) {
                    thisBody.hide();
                    thisBody.eq(num).css({
                        "display": "block",
                        "clear": "both"
                    });
                    thisLi.removeClass('act');
                    $(this).addClass('act');
                }
            });
            // ie8・ie9のタブの幅設設定
            if (isLteIE8 || isLteIE9) {
                var win_w = window.innerWidth;
                var list_size = thisHead.find("ul li").size();
                var list_pc_block = thisHead.find("ul li.forPcBlock").size();
                var get_list_width = (100 - ((list_size - list_pc_block) - 1)) / (list_size -
                    list_pc_block);

                if ( thisHead.attr("id") == "tabType02" ) {
                    // 処理なし
                } else {
                    thisHead.find("ul li").css("width", get_list_width + "%");
                }

                if (thisHead.hasClass("static")) {
                    var tab_h = parseInt(thisHead.find("ul li").css("height").replace("px",'')-14);
                    thisHead.find("ul li a").css("height", tab_h);
                    if (win_w < 640) {
                        thisHead.find("ul li a").each(function() {
                            var this_a = $(this);
                            var a_height = parseInt(this_a.closest("li").css("height").replace("px",'')) + 14;

                        });
                    }
                    $(window).on("resize", function() {
                      //ie8 resize event なし
                        if(!isLteIE8){
                            win_w = window.innerWidth;
                            if (isLteIE9) {
                                thisHead.find("ul li").css("height", "auto");
                                thisHead.find("ul li a").css("height", "auto");
                                var tab_h = parseInt(thisHead.find("ul li").css("height").replace("px",'')-14);
                                thisHead.find("ul li a").css("height", tab_h);
                                if (win_w < 640) {
                                    thisHead.find("ul li a").each(function() {
                                        var this_a = $(this);
                                        var a_height = parseInt(this_a.closest("li").css("height").replace("px",'')) + 14;

                                    });
                                }
                            }
                        }
                    });
                };
            }
        }
    });

    //Tab Control
    //    $(".tabControl").on("click", function() {
    //        var this_control = $(this);
    //        var get_target_id = this_control.attr("href");
    //
    //        $(get_target_id).click();
    //    });



    if (isLteIE8) {
        $('.checkArea label.target').each(function() {
            var $input = $(this).prev(),
                $self = $(this);
            if ($input.is(":checked")) {
                $input.attr('checked', 'checked');
                $self.css('background-image', 'url(/common/img/icon_check_01_on.png)');
            }
        });
        // ラジオボタン、チェックボックス
        $('.checkArea label.target').on('click', function() {
            var $input = $(this).prev(),
                $self = $(this);
            if ($input.is(":checked")) {
                $input.removeAttr('checked');
                $self.css('background-image', 'url(/common/img/icon_check_01.png)');
            } else {
                $input.attr('checked', 'checked');
                $self.css('background-image', 'url(/common/img/icon_check_01_on.png)');
            }
        });

        $('.radioArea label.target').each(function() {
            var $input = $(this).prev(),
                $self = $(this);
            if ($input.is(":checked")) {
                $input.attr('checked', 'checked');
                $self.css('background-image', 'url(/common/img/icon_radio_01_on.png)');
            }
        });
        $('.radioArea label.target').on('click', function() {
            var $input = $(this).prev(),
                $self = $(this);

            $('.radioArea input').removeAttr('checked');
            $('.radioArea label.target').css('background-image', 'url(/common/img/icon_radio_01.png)');

            if ($input.is(":checked")) {
                $self.css('background-image', 'url(/common/img/icon_radio_01.png)');
            } else {
                $input.attr('checked', 'checked');
                $self.css('background-image', 'url(/common/img/icon_radio_01_on.png)');
            }
        });
    }

    /* グローバルメニュー、検索窓 */
    // グローバルメニューのカレント判定
    var breadcrumbText02 = ($('.breadcrumbArea a').length > 1) ? $('.breadcrumbArea a:nth-child(2)').text() : $('.breadcrumbArea strong').text(); //会員・加盟店用

    $('.megaMenu_item > .megaMenu_itemTitle > a').each(function(index, item) {
            var naviText = $(this).text();
            if (breadcrumbText02 == naviText) {
                $(item).closest('.megaMenu_item').addClass('megaMenu_item-active');
            }
    });


    // ツールチップ
    var agent = navigator.userAgent;
    if (etype === 1 || agent.search(/Window/) != -1 || !(device.mobile() || device.tablet())) {
        $('.toolTip').addClass('f-pc'); // ツールチップはPCのみ
    }

    // カルーセル
    if ($(".carouselWrapArea").size() > 0) {
        $(window).load(function() {
            imageSliderAction();
        });
        imageSliderAction();
        $(window).on("resize", function() {
          //ie8 resize event なし
            if(!isLteIE8){

                //ie8はresize event なし
                if(!isLteIE8){
                    imageSliderAction();
                }

            }
        });
        $(".tabHead ul li").on("click", function() {
            imageSliderAction();
        });
    }

    function imageSliderAction() {
        var win_w = window.innerWidth;

        $(".carouselWrapArea").each(function(e) {
            var this_area = $(this);
            var this_carousel = this_area.find(".carouselArea");
            var this_coll = this_carousel.attr("id") != undefined ? this_carousel.attr("id") : "default";
            var set_slide_class = "slide" + e;
            var set_navi_num = "navi" + e;
            var img_height = this_area.find("img").height();
            var img_height_area = this_area.find("img").height();
            var img_width = this_area.find("img").width();
            var set_coll;

            this_carousel.addClass(set_slide_class);
            this_area.find(".naviWrap").addClass(set_navi_num);

            if (this_coll != "default") {
                this_coll = this_coll.replace("coll", "") * 1;
            } else {
                this_coll = 1;
            }

            if ( this_area.find("ul li").find("a").size() > 0 ) {
                img_height += 30;
            }

            if (win_w > 640) {
                $("." + set_slide_class + " ul").carouFredSel({
                    width: "100%", //表示する幅
                    height: img_height, //表示する高さ
                    circular: true,
                    infinite: false,
                    auto: false,
                    items: this_coll,
                    direction: "left",
                    align: "center",
                    prev: '.naviWrap.' + set_navi_num + ' .btnPrev',
                    next: '.naviWrap.' + set_navi_num + ' .btnNext',
                    scroll: {
                        items: this_coll,
                        duration: 1000,
                        pauseOnHover: true
                    },
                    wipe: {
                        onTouch: true,
                        onMouse: true
                    }
                });
            } else {
                set_coll = Math.floor((this_area.width() - 62) / (img_width + 20));
                if (this_coll > set_coll) {
                    this_coll = set_coll;
                }
                $("." + set_slide_class + " ul").carouFredSel({
                    width: "105.5%", //表示する幅
                    height: img_height, //表示する高さ
                    circular: true,
                    infinite: false,
                    auto: false,
                    items: this_coll,
                    direction: "left",
                    align: "center",
                    prev: '.naviWrap.' + set_navi_num + ' .btnPrev',
                    next: '.naviWrap.' + set_navi_num + ' .btnNext',
                    scroll: {
                        items: this_coll,
                        duration: 1000,
                        pauseOnHover: true
                    },
                    wipe: {
                        onTouch: true,
                        onMouse: true
                    }
                });
            }

            //会員TOP用条件文
            if ( this_area.is(".ktopCarousel") ) {
                this_area.find(".naviWrap span").css("cssText", "height:55px; top:"+(img_height_area-13)/2+"px;");
                    setTimeout(function(){
                        win_w = window.innerWidth;
                        if (win_w < 640) {
                            set_coll = Math.floor((this_area.width() - 62) / (img_width + 20));
                            if (this_coll > set_coll) {
                                this_coll = set_coll;
                            }
                            if (set_coll <= 1) {
                                $("." + set_slide_class + " ul").css("left", ((this_area.width()-img_width)/set_coll)/2 + "px");
                            } else {
                                $("." + set_slide_class + " ul").css("left", (this_area.width() - (img_width*set_coll) - (20*(set_coll-1)))/set_coll + "px");
                            }
                        }
                    }, 100);
            } else {
                this_area.find(".naviWrap span").height(img_height + 40 + "px");
            }

            this_area.height(img_height + 40 + "px");
        });
    }



    // モーダルウィンドウ
    var mt;
    var MDCenter = function(t) {
        var cssSET = IE7 ? function() {
            return {
                top: $(window).scrollTop() + (($(window).height() - t.height()) / 2),
                left: ($(window).width() - t.width()) / 2
            }
        } : function() {
            return {
                top: $(window).scrollTop() + (($(window).height() - t.height()) / 2)
            }
        }
        return cssSET();
    }
    var MDFilter = function() {
        $('.jsEvModalFilter').show().height($(document).height())
    }
    var MDCheck = function() {
            return $('.modalCont').not(':hidden')[0]
        }
        //    $('.jsEvModal').on(ev.start[etype], function(p) {
    $('.jsEvModal').on(ev.start[1], function(p) {
        MDFilter();
        var mNum = $(this).data('modalNum');
        mt = $('.modalCont[data-modal-num=' + mNum + ']');
        mt.css(MDCenter(mt))
        mt.show();
        return false;
    });


    //    $('.jsEvModalClose,.jsEvModalFilter').on(ev.start[etype], function(p) {
    $('.jsEvModalClose,.jsEvModalFilter').on(ev.start[1], function(p) {
        $('.jsEvModalFilter').hide();
        mt.hide();
        return false;
    })
    $(window).on('resize', function() {
      //ie8 resize event なし
        if(!isLteIE8){

            if (!MDCheck() || mt === undefined) return;
            mt.css(MDCenter(mt))

        }
    })
    $(window).setBreakpoints({
        distinct: true,
        breakpoints: [1, 640]
    });
    // if(isLteIE8){
    $('img').each(function() {
        try {
            if ($(this).attr('src').indexOf('.png') != -1) {
                $(this).css('filter', 'progid:DXImageTransform.Microsoft.AlphaImageLoader(src="' + $(this).attr('src') + '", sizingMethod="scale");');
            }
        } catch(e) {

        }
    });

    (function() {
        /**
         *
         * 右エリア座標固定(.js-fixSide = 固定する要素 / .js-baseH = Y座標の基準となる要素)
         *
         */
        var fixedCheck = function() {
            // SPモードの場合はマージンを削除して終わり
            var mode = (typeof $.cookie("layout_mode") === "undefined") ? "SP" : $.cookie("layout_mode");
            if (mode === "SP") {
                $(".js-fixSide").css({
                    "width": "100%",
                    "margin-top": 0
                });
            }
            var marginBtm = 20;
            var scrollTop = $(window).scrollTop();
            var scrollEnd = $(window).scrollTop() + $(window).height() - marginBtm;
            var contStart = $(".js-baseH").offset().top - marginBtm;
            var contEnd = contStart + $(".js-baseH").height();
            var fixMargin = $(".js-fixSide").css("margin-top").split("px")[0];
            var fixedEnd = scrollTop + $(".js-fixSide").height();
            if (ua.isiOS) contEnd = contEnd - 230; // FIXME :
            // iOSが座標関連で正確な値を取れないため、調整
            if (scrollTop <= contStart) {
                // Y座標成り行き
                if ($(".js-fixSide").hasClass("js-fixed")) $(".js-fixSide").toggleClass("js-fixed");
                $(".js-fixSide").css({
                    "width": "100%",
                    "margin-top": 0
                });
            } else if ((scrollTop > contStart) && (fixedEnd < contEnd)) {
                // Y座標上固定（Fix）
                if (!$(".js-fixSide").hasClass("js-fixed")) $(".js-fixSide").toggleClass("js-fixed");
                $(".js-fixSide").css({
                    "width": $(".js-fixSide").parent().width() + "px",
                    "margin-top": 0
                });
            } else {
                // Y座標下固定（margin）
                if ($(".js-fixSide").hasClass("js-fixed")) $(".js-fixSide").toggleClass("js-fixed");
                if (!$("body").hasClass("sp-layout")) {
                    $(".js-fixSide").css({
                        "width": "100%",
                        "margin-top": $(".js-baseH").height() - $(".js-fixSide").height() - marginBtm + "px"
                    });
                }
            }
        }
        if (($(".js-fixSide").length === 1) && ($(".js-baseH").length === 1)
            /*
             * &&
             * (!ua.isTablet)
             */
        ) {
            // $(window).on("load scroll resize", fixedCheck);
        }
    })();

    (function() {
        // アコーディオン（スマートフォンのみ）
        var flag = false;
        var initAccordion = function() {
            flag = true;
            // 入れ子のアコーディオンを開く（カード一覧のみ？）
            var acdBtn = $(".spAcdBody").find('.acdiBtn');
            acdBtn.each(function() {
                if (!$(this).hasClass("active")) $(this).trigger('click');
            });
            $(".spAcdBody").hide();
            $(".spAcdCap").click(function(event) {
                if (flag) {
                    var btn = $(this).find(".btnType02");
                    btn.toggleClass('on');
                    btn.toggleClass('off');
                    $(this).parent().find(".spAcdBody").slideToggle("slow");
                    return false;
                }
            });
        }
        var clearAccordion = function() {
            flag = false;
            $(".spAcdCap").unbind();
            $(".spAcdBody").show();
        }
        var resizeCheck = function() {
            if ($(".spAcdBtn").css("display") === "none") { // 切り替えボタンの表示/非表示で判定
                // PC向け
                if (flag) clearAccordion();
            } else {
                // SP向け
                if (!flag) initAccordion();
            }
        }
        $(window).resize(function(event) {
          //ie8 resize event なし
            if(!isLteIE8){

                resizeCheck();

            }
        });
        resizeCheck();
    })();

    /**
     *
     * ポップアップ（/nyukai/responsive/js/lib.jsから移動）
     *
     */
    popUpFunc = function() {
        // target削除
        $(".winPopup, .envPopup, .priPopup").each(function() {
            if (($(this).attr("target") === "_blank") && ((!ua.isTouchDevice))) {
                $(this).attr("target", "_self");
            }else{
                $(this).attr("target", "_blank");
            };
        });

        $(".winPopup, .envPopup, .priPopup").click(function() {
            // UA判定のみ（スマホ、タブレット類は別ウインドウで開かない）
            // if (!ua.isTablet) {
            if (!ua.isTouchDevice) {
                var winName = this.href.match(/[a-zA-Z0-9]/g).join('');
                var w = 850;
                if ($(this).hasClass('envPopup')) {
                    winName = "envPopup";
                }
                if ($(this).hasClass('priPopup')) {
                    winName = "priPopup";
                    w = 750;
                }
                window.open(this.href, winName, 'width=' + w + ', Height=600, left=70 ,top=70, toolbar=0, resizable=1, scrollbars=1, menubar=0');
                return false;
            }
        });
    };
    popUpFunc();

    /*
     *
     * スマホヘッダ固定
     *
     */
    ;
    (function() {
        var headFixed = function() {
            var mode = $.cookie("layout_mode");
            if ((mode === "SP") || (window.innerWidth < 640)) {
                $("body").addClass('sp-layout');
                $("body").removeClass('pc-layout');
            } else {
                $("body").removeClass('sp-layout');
                $("body").addClass('pc-layout');
            }
        }
        $(window).on("load", headFixed);

      //ie8 resize event なし
        if(!isLteIE8){
            $(window).on("resize", headFixed);
        }
    })();;
    (function() {
        setTimeout(function() {
            $("body").addClass('sp-loaded');
        }, 1000);
    })();

    /* スムーススクロール */

    function SmoothScroll(_target, _e) {
        var smbcLine_height = $('#smbcLine').outerHeight();
        var header_height = $('#header').outerHeight();
        var head_height = smbcLine_height + header_height;
        var speed, href, target, position;
        speed = 500;
        href = $(_target).attr('href');
        target = $(href == "#" || href == "" ? 'html' : href);
        position = target.offset().top;

        //スマホ表示の場合（ヘッダーを固定しているため、ヘッダーの高さ分マイナスする）
        /*
        if (window.innerWidth < 640) {
            // URLを取得して「?]で分割「&」でも分割
             var url = location.href;
            if (url.match("/pop/") != null) {
                $('html, body').animate({
                    scrollTop: position
                }, speed, "swing");
            } else if(url.match('/mem/|/camp/')) {
                $('html, body').animate({
                    scrollTop: position - head_height
                }, speed, "swing");
            } else {
                $('html, body').animate({
                    scrollTop: position
                }, speed, "swing");
            }

            return false;
        }
        //PC表示の場合
        $('html, body').animate({
            scrollTop: position
        }, speed, "swing");
        return false;
        */
    }

    /* 2014.11.17 でふん */
    /* accordion内の ページ内 linkへ移動 */
    function AccordionLinkMove(_target){
        var w = window.innerWidth;
        var x = 640;
        var this_ancher = $(_target).attr("href");
        if (w < x) {
            $(this_ancher).closest('.section').find($('h2.acdiHead span')).removeClass('on');
            $(this_ancher).closest('.section').find($('h2.acdiHead span')).addClass('off');
            $(this_ancher).closest('.section').find($('h2.acdiHead')).next('.acdiBody').css("display", "block");
        }
    }

    /* ページ内リンク移動イベント */
    $('a[href^="#"]' + 'a[href!="#"]').on('click', function(_e) {
        AccordionLinkMove(this)
        return SmoothScroll(this, _e)
    });


    // onloadのタイミングで動作しないことがあるようなので、強制的に発火

    if (($.cookie("layout_mode") !== "PC") && (window.innerWidth < 640)) {
        // スマホ
        $(window).trigger('enterBreakpoint1');
    } else {
        // PC
        $(window).trigger('enterBreakpoint641');
    }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////querty_2 end///////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////querty_4 start///////////////////////////////
$(function($) {
    function setDialog(calc_pos) {
        if (calc_pos) {

            var ww = $(window).width();
            var cw = Math.round($(window).width() * 0.7);
            var left = (ww - cw) / 2;

//            console.log(ww);
//            console.log(cw);
//            console.log(left);
            $(modaltarget_id).dialog({
                autoOpen: false,
                width: '90%',
                modal: true,
                position: [left, null]
            });
        } else {
            $(modaltarget_id).dialog({
                autoOpen: false,
                width: '90%',
                modal: true,
                position: [null, null]
            });
        }
    }
    var modaltarget_id = "#modalWindow";
    $(".jsEvModal").each(function(){
        var add_id = $(this).attr("data-modaltarget");
        if(add_id){
            modaltarget_id = modaltarget_id + ",#" + add_id;
        }
    });

    if (device.tablet()) {
        if (Math.abs(window.orientation) === 90) {
            setDialog();
        } else {
            setDialog(true);
        }
        $(window).on("orientationchange", function() {
            // //横向き
            if (Math.abs(window.orientation) === 90) {
                setDialog();
                // /縦向き
            } else {
                setDialog(true);
            }
        });
    } else {
        setDialog();
    }

    function dialogOpen(_target, _e, modaltarget) {
        if(modaltarget != ""){
            $("#" + modaltarget).dialog("open");
        }else{
            $("#modalWindow").dialog("open");
        }
        var modal_height = $(modaltarget_id).outerHeight;
        $(modaltarget_id).dialog("close");
        if(window.height < modal_height){
            $("#" + modaltarget).dialog({position:{of: window,at: 'center center', my : 'center center'}});
        } else {
            $("#" + modaltarget).dialog({position:{of: 'body',at: 'top', my : 'center'}});
        }
        $(window).scrollTop(0);
        if(modaltarget != ""){
            $("#" + modaltarget).dialog("open");
        }else{
            $("#modalWindow").dialog("open");
        }
    }

    function dialogClose(_target, _e) {
        $(modaltarget_id).dialog("close");
    }

    var pointY;
    $(document).on('click', '.btnClose, .ui-widget-overlay', function(_e) {
        dialogClose(this, _e);
        $('#allWrapper').css({
            'position': 'relative',
            'width': '',
            'top': ''
        });
        var modal_position = $("body").attr('modal_position');
        $(window).scrollTop(modal_position);
    });
    $(document).keydown(function(_e){
        if (_e.keyCode == 27) {
            if(document.getElementsByClassName("ui-widget-overlay")){
                _e.preventDefault();
                dialogClose(this, _e);
                $('#allWrapper').css({
                    'position': 'relative',
                    'width': '',
                    'top': ''
                });
                var modal_position = $("body").attr('modal_position');
                $(window).scrollTop(modal_position);
            }
        }
    });
    $('.jsEvModal').on('click', function(_e) {
        pointY = $(window).scrollTop();
        $("body").attr('modal_position', pointY);
        $('#allWrapper').css({
            'position': 'fixed',
            'width': '100%',
            'top': -pointY
        });
        $('.modalWindowWrap').css({
            'margin': '80px auto'
        });

        var modaltarget = $(this).attr("data-modaltarget");
        if(!modaltarget){
            modaltarget = "";
        }
        dialogOpen(this, _e, modaltarget);
    });
    $(window).resize(function(_e) {
      //ie8 resize event なし
        if(!isLteIE8){
            var flg = [];
            $(modaltarget_id).each(function(_i){
                flg[_i] = $(this).dialog('isOpen');
                if (flg[_i]) {
                    $(this).dialog("close").dialog("open")
                }
            });
        }
    });
    $(window).setBreakpoints({
        distinct: true,
        breakpoints: [1, 620]
    });

    // ボックスの高さ揃え
    var colTileTime = false;
    $(window).on("load", function() {
        if(ua.isIE) {
            setTimeout(function(){
                colTileLoad();
            }, 1000);

        } else {
            colTileLoad();
        }
    });
    $(window).on("resize", function(){
      //ie8 resize event なし
        if (!isLteIE8) {

            //ie8はresize eventなし
            if (!isLteIE8) {
                colTileLoad();
            }

        }
    });

    function colTileLoad() {

        var win_w = window.innerWidth || isLteIE8;
        var forPcTiles = [".forPcColTile-group"];
        var forSpTiles = [".forSpColTile-group"];
        var nomalColTiles = [".colTile-group", ".tabTile-group",
            ".tabTilePlatinum01-group", ".tabTilePlatinum02-group",
            ".tabTilePlatinum03-group", ".tabTilePlatinum04-group",
            ".tabTilePlatinum05-group"
        ]
        var setTiles, resetTiles = [];
        if ($('script[src="/static/responsive/js/plugin/jquery.tile.min.js"]').size() != 0) {
            if (win_w) {
                if (win_w < 640) {
                  resetTiles = forPcTiles;
                  setTiles = nomalColTiles.concat(forSpTiles);
                } else {
                  resetTiles = forSpTiles;
                  setTiles = nomalColTiles.concat(forPcTiles);
                }
                // 高さ合わせ解除
                $.each(resetTiles, function(e) {
                    var col_arry = resetTiles[e];
                    for (var i = 1; i < 21; i++) {
                        if ($(col_arry + i).size() > 0) {
                            $(col_arry + i).height('auto');
                        }
                    }
                });
                // 高さ合わせ実行
                $.each(setTiles, function(e) {
                    var col_arry = setTiles[e];
                    for (var i = 1; i < 21; i++) {
                        if ($(col_arry + i).size() > 0) {
                            $(col_arry + i).tile();
                        }
                    }
                });
            } else {
                $.each(nomalColTiles, function(e) {
                    var col_arry = nomalColTiles[e];
                    for (var i = 1; i < 21; i++) {
                        if ($(col_arry + i).size() > 0 && col_arry.indexOf(".tabTile") == -1) {
                            $(col_arry + i).height("auto");
                        } else if ($(col_arry + i).size() > 0 && col_arry.indexOf(".tabTile") != -1) {
                            $(".tabHead.vertical").find(col_arry + i).height("auto");

                            $(".tabHead").not(".vertical").find(col_arry + i).tile();
                        }
                    }
                });
            }
        }
    }

    // フッタAccordion処理
    $("#footer .footNavArea dl dt, #footer .footAreaBottom dl dt").on("click", function() {
        if ($("body").hasClass("sp-layout") || device.mobile()) {
            if ($(this).hasClass("act")) {
                $(this).removeClass("act");
                accorAction($(this).next("dd"), "hide");
            } else {
                $(this).addClass("act");
                accorAction($(this).next("dd"), "show");
            }
        }
    });
    $(window).on("resize", function() {
      //ie8 resize event なし
        if(!isLteIE8){

            if ($("body").hasClass("pc-layout")) {
                $("#footer .footNavArea dl, #footer .footAreaBottom dl").find("dd").show();
            }

        }
    });

    // TextArea がアコーディオンに入っている時は、スマホ画面ではスクロールしない。
    function accordionSpScrollNone() {
        $('.kiyaku .acdiBody .jspPaneSp').remove();
        $('.kiyaku .acdiBody .jspPaneSp').empty();
        $('.kiyaku .acdiBody .defTextarea .jspContainer .jspPane').each(function(index) {
            var jaPaneHtml = $(this).html();
            $('.kiyaku .acdiBody').eq(index).append('<div class="jspPaneSp"></div>');
            $('.kiyaku .acdiBody .jspPaneSp').eq(index).html(jaPaneHtml);
        });
    }

    // Tooltip 幅の設定
    $(".toolTip").each(function() {
        $(this).find(".toolTBWrap").find(".toolTipBody").after("<span class='toolTipArrow'></span>");
    });
    // Tooltip 幅の設定
    $(".toolTip").hover(function(){
      var this_toolTip = $(this);

      this_toolTip.find(".toolTBWrap").each(function() {
        var w = $(window).width();
        var this_wrap = $(this);

        var contWrap = $('#contWrap');
        var contWrap_offsetLeft = contWrap.offset().left;
        var contWrap_offsetRight = contWrap.offset().left + contWrap.width();

        var this_toolTip_qIcon = this_toolTip.find(".qIcon");
        var this_toolTip_body = this_wrap.find(".toolTipBody");
        var this_toolTip_arrow = this_wrap.find(".toolTipArrow");

        var this_wrap_offsetLeft = this_toolTip_qIcon.offset().left - (this_wrap.outerWidth(true) / 2) + 15;
        var this_wrap_offsetRight = this_wrap_offsetLeft + this_wrap.outerWidth(true);

        if(contWrap_offsetLeft > this_wrap_offsetLeft){
          if(w <= 640){
            this_wrap.offset({
              left : contWrap_offsetLeft + 10
            });
          } else {
            this_wrap.offset({
              left : contWrap_offsetLeft
            });
          }
        } else if(contWrap_offsetRight < this_wrap_offsetRight){
          if(w <= 640){
            this_wrap.offset({
              left : w - this_wrap.outerWidth(true) - 12
            });
          } else {
            this_wrap.offset({
              left : contWrap_offsetRight - this_wrap.outerWidth(true)
            });
          }
        } else {
          this_wrap.offset({
            left : this_wrap_offsetLeft
          });
        }

        this_toolTip_arrow.offset({
          "top": this_toolTip_body.offset().top + this_toolTip_body.height() + 42,
          "left": this_toolTip_qIcon.offset().left + 1.5
        });
      });
    });

    $(".toolTip").on("click", function(e) {
        e.preventDefault();
    });

    $(".toolTip").on("touchstart", function(e) {
        $(".toolTip").find(".toolTBWrap").css("display", "none"); //他のツールチップ開いてるとき全部いったん非表示
        if (e.cancelable) {
            e.preventDefault();
        }
        var this_toolTip = $(this);
        var this_position = $(this).offset().top;
        var tool_body = $(this).find(".toolTBWrap").find(".toolTipBody");

        $(this).find(".toolTBWrap").css("display", "block");

        this_toolTip.find(".toolTBWrap").each(function() {
          var w = $(window).width();
          var this_wrap = $(this);

          var contWrap = $('#contWrap');
          var contWrap_offsetLeft = contWrap.offset().left;
          var contWrap_offsetRight = contWrap.offset().left + contWrap.width();

          var this_toolTip_qIcon = this_toolTip.find(".qIcon");
          var this_toolTip_body = this_wrap.find(".toolTipBody");
          var this_toolTip_arrow = this_wrap.find(".toolTipArrow");

          var this_wrap_offsetLeft = this_toolTip_qIcon.offset().left - (this_wrap.outerWidth(true) / 2) + 15;
          var this_wrap_offsetRight = this_wrap_offsetLeft + this_wrap.outerWidth(true);

          if(contWrap_offsetLeft > this_wrap_offsetLeft){
            if(w <= 640){
              this_wrap.offset({
                left : contWrap_offsetLeft + 10
              });
            } else {
              this_wrap.offset({
                left : contWrap_offsetLeft
              });
            }
          } else if(contWrap_offsetRight < this_wrap_offsetRight){
            if(w <= 640){
              this_wrap.offset({
                left : w - this_wrap.outerWidth(true) - 12
              });
            } else {
              this_wrap.offset({
                left : contWrap_offsetRight - this_wrap.outerWidth(true)
              });
            }
          } else {
            this_wrap.offset({
              left : this_wrap_offsetLeft
            });
          }

          this_toolTip_arrow.offset({
            "top": this_toolTip_body.offset().top + this_toolTip_body.height() + 42,
            "left": this_toolTip_qIcon.offset().left + 1.5
          });
        });
    });
    $(document).on('touchstart', function (e) {
      if (!$(e.target).closest(".toolTip").length) {
        $(this).find(".toolTBWrap").css("display", "none");
      }
    });


    //プラチナ関連
    //メニューのbackground-size ie8の設定をため、jsから設定

    $(".platinumWrap .platinumMenu01, .platinumWrap .platinumMenu02").each(function(){
        var this_warp = $(this);
//        var this_body = this_warp.find(".platinumAccordionBody");
        var this_control_btn = this_warp.find(".platinumAccordion .acdiBtn");
        var this_body = this_warp.find(".platinumAccordionBody");
        var this_li = this_warp.find("ul li");
        var win_w = window.innerWidth;
        var this_col_navi = "platinumMenu_nav" + this_body.attr("class").replace("platinumAccordionBody", "").replace("platinumNav", "").replace(/\s/g, '') + "_";

        $.each(this_li, function(e) {
            var num = (e + 1) < 10 ? "0" + (e + 1) : "" + e;
            var file_extension = ".png";
            var file_name = this_col_navi + num + file_extension;
            var file_root = "/static/responsive/img/mem/";
            $(this).find("a").append("<img src='" + file_root + file_name + "' class='forPcBlock'>");
        });

        if (isLteIE8) {
            var ie8_width = [];
            var maximum_width = 0;
            this_body.css({
                "white-space": "nowrap"
            });
            this_li.each(function(e) {
                ie8_width[e] = $(this).width();
            });
            this_li.each(function(e) {
                maximum_width += ie8_width[e] + 2;
                if (maximum_width < this_body.width()) {
                    $(this).css({
                        "width": ie8_width[e] + "px",
                        "position": "relative",
                        "display": "inline-block",
                        "left": "-" + e * 5 + "px"
                    });
                } else {
                    $(this).css({
                        "width": ie8_width[e] - (maximum_width - this_body.width()) - 1 + "px",
                        "position": "relative",
                        "display": "inline-block",
                        "left": "-" + e * 5 + "px"
                    });
                }
            });
        } else {
            $(window).resize(function(){
                win_w = window.innerWidth;
                if (win_w >= 640) {
                    this_control_btn.removeClass("off");
                    this_control_btn.addClass("on");
                    this_warp.find(".platinumAccordionBody").show();
                }
                if (win_w <= 640) {
                    this_control_btn.removeClass("off");
                    this_control_btn.addClass("on");
                    this_body.hide();
                }
            });
        }

        if (win_w <= 640 && this_control_btn.hasClass("on")) {
            this_control_btn.closest(".platinumAccordion").next(".platinumAccordionBody").hide();
        }

        this_warp.find("ul li").on("click", function(){
            var this_li = $(this);
            var this_all_li = this_li.closest("ul").children("li");

            this_all_li.removeClass("act");
            this_li.addClass("act");
        });

        this_control_btn.off("click touchend");
        this_control_btn.on("click touchend", function() {
            win_w = window.innerWidth;
              if (win_w <= 640 && this_control_btn.hasClass("off")) {
                  this_control_btn.removeClass("off");
                  this_control_btn.addClass("on");
                  this_body.hide();
              }else if (win_w <= 640 && this_control_btn.hasClass("on")) {
                  this_control_btn.removeClass("on");
                  this_control_btn.addClass("off");
                  this_body.show();
              }
        });
    });

    //ACCRDION ACTION
    //get_target : 対象
    //action : 処理区分
    //option_target : option処理の対象
    //option_position : option処理のタイミング
    //option_action : optionの処理区分
    //option_value : optionの処理に必要なデータ
    function accorAction(get_target, action, option_target, option_position, option_action,
        option_value) {
        var set_target = get_target;
        var set_time = 500;
        var set_option = option_target != undefined && option_action != undefined &&
            option_position != undefined && option_value != undefined;
        //IE6 IE7 IE8の処理 -start-
        if ($("html").hasClass("ie6") || $("html").hasClass("ie7") || $("html").hasClass("ie8")) {
            //option処理:first
            if (set_option && option_position == "first") {
                if (option_action == "show") {
                    option_target.show();
                }
                if (option_action == "hide") {
                    option_target.hide();
                }
            }
            //option処理:synchronous & normal
            if (set_option && option_position == "synchronous") {
                if (action == "show" && option_action == "heightColTileLoad") {
                    set_target.show();
                    option_target.height(option_target.height() + option_value);
                    colTileLoad();
                }
                if (action == "hide" && option_action == "heightColTileLoad") {
                    set_target.hide();
                    option_target.height(option_target.height() + option_value);
                    colTileLoad();
                }
            } else {
                if (action == "show") {
                    set_target.show();
                }
                if (action == "hide") {
                    set_target.hide();
                }
            }
            //option処理:last
            if (set_option && option_position == "last") {
                if (option_action == "show") {
                    option_target.show();
                }
                if (option_action == "hide") {
                    option_target.hide();
                }
            }
            //IE6 IE7 IE8の処理 -end-
        } else {
            //一般処理 -start-
            //option処理:last-showの場合、対象をdisplay:noneした後でshow処理をする。
            if (set_option && option_position == "last") {
                if (option_action == "show") {
                    if (option_target.css("display") != "none") {
                        option_target.css("display", "none");
                    }
                }
            }
            //option処理:first
            if (set_option && option_position == "first") {
                if (option_action == "show") {
                    option_target.show();
                }
                if (option_action == "hide") {
                    option_target.hide();
                }
            }
            //option処理:synchronous & normal
            if (set_option && option_position == "synchronous") {
                if (action == "show" && option_action == "heightColTileLoad") {
                    slideObj = new Object();
                    slideObj.duration = set_time;
                    slideObj.progress = function() {
                        option_target.height(option_target.height() + option_value);
                        colTileLoad();
                    }
                    set_target.slideDown(slideObj);
                }
                if (action == "hide" && option_action == "heightColTileLoad") {
                    slideObj = new Object();
                    slideObj.duration = set_time;
                    slideObj.progress = function() {
                        option_target.height(option_target.height() - option_value);
                        colTileLoad();
                    }
                    set_target.slideUp(slideObj);
                }
            } else {
                if (action == "show") {
                    set_target.stop().slideDown(set_time);

                }
                if (action == "hide") {
                    set_target.stop().slideUp(set_time);
                }
            }
            //option処理:last
            if (set_option && option_position == "last") {
                setTimeout(function() {
                    if (option_action == "show") {
                        option_target.show();
                    }
                    if (option_action == "hide") {
                        option_target.hide();
                    }
                }, set_time);
            }
        }
        //一般処理 -end-
    }

    $(".sliderWrap").each(function() {

        var this_wrap = $(this);
        var this_slider_for = this_wrap.find(".slider-for");
        var this_slider_nav = this_wrap.find(".slider-nav");
        var this_frame = this_wrap.find(".slider-frame");
        var slide_size = this_wrap.find(".slider-for").find("div img").size();
        var start_nav;
        var interval_index = 0;
        var win_w = window.innerWidth;
        var sliderWrapLoad = false;
        var setAutoPlay = true;
        var getStartIndex = 0;
//      カードの種類を切替えるページ：ローテーション表示なし
        if (this_wrap.hasClass("forKirikae") ) {
            setAutoPlay = false;
            getStartIndex = this_slider_for.find("div.act").index();
        }

        $('.sliderWrap .slider-nav').css("display", "block");
        $('.sliderWrap .slider-for div').css("display", "block");
        this_wrap.hide();

//        if (win_w > 640) {
//            $('.sliderWrap .slider-frame').css("display", "block");
//        } else {
//            $('.sliderWrap .slider-frame').css("display", "none");
//        }

        $(window).on("load", function() {
              win_w = window.innerWidth;
              this_wrap.show();
              if ((win_w > 640 || isLteIE8) && slide_size > 1) {
                  $('.sliderWrap .slider-frame').css("display", "block");
              } else {
                  $('.sliderWrap .slider-frame').css("display", "none");
              }
              this_slider_for.slick({
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  arrows: false,
                  fade: true,
                  asNavFor: '.slider-nav'
              });
              sliderWrapLoad = true;
          });

        $(window).resize(function(){
          //ie8 resize event なし
            if(!isLteIE8){
                win_w = window.innerWidth;
                if (win_w > 640 && slide_size > 1) {
                    setTimeout(function() {
                        win_w = window.innerWidth;
                        if (win_w > 640 && slide_size > 1) {
                            $('.sliderWrap .slider-frame').css("display", "block");
                        }
                    }, 100);
                } else {
                    $('.sliderWrap .slider-frame').css("display", "none");
                }
            }
        });

        if (slide_size > 5) {
            this_slider_nav.slick({
                asNavFor: '.slider-for',
                focusOnSelect: true,
                slidesToShow: 5,
                slidesToScroll: 1,
                dots: true,
                autoplay: setAutoPlay,
                autoplaySpeed: 4000,
                centerMode: true,
                draggable: false
            });
        } else if (slide_size == 1) {
            //js minで処理
            this_frame.hide();
        } else {
            var slider_nav_size = this_slider_nav.find("div").size();

            this_slider_nav.find(".slick-list").ready(function() {
                this_slider_nav.find(".slick-list").removeClass("draggable");
                start_nav = this_slider_nav.find(".slick-list").find("div.slick-active[index=0]")
            });

            for (var a = slide_size; a < 6; a++) {
                this_slider_nav.append("<div></div>");
            }

            this_slider_nav.slick({
                asNavFor: '.slider-for',
                slidesToShow: 5,
                focusOnSelect: true,
                dots: true,
                arrows: false,
                autoplay: setAutoPlay,
                autoplaySpeed: 4000
            });


            setTimeout(function() {

                this_slider_for.find(".slick-slide").each(function() {
                    var this_sld = $(this);
                    var sld_index = this_sld.attr("index");

                    if (this_sld.css("z-index") == 900 && this_sld.css("opacity") == 1) {
                        this_slider_for.find(".slick-slide").removeClass("slick-active");
                        this_sld.addClass("slick-active");
                    }

                    if (this_sld.hasClass("slick-active")) {
                        this_sld.closest(".sliderWrap").find('.slider-nav').find(
                            ".slick-list").find("div").each(function() {
                            var this_div = $(this);
                            if (this_div.attr("index") == sld_index &&
                                this_div.hasClass("slick-active")) {
                                this_frame.offset({
                                    "left": this_div.offset().left
                                });
                                return false;
                            }
                        });
                    }
                });
            }, 100);

            this_slider_nav.find(".slick-list").find("div").on("click touchend", function(e) {
                var this_div = $(this);
                var this_index = this_div.attr("index");
                if (this_index != undefined) {
                    this_slider_for.find(".slick-slide").each(function() {
                        var this_sld = $(this);

                        if (this_sld.hasClass("slick-active")) {
                            this_sld.removeClass("slick-active");
                        }

                        if (this_sld.attr("index") == this_index) {
                            this_sld.addClass("slick-active");

                            this_frame.offset({
                                "left": this_div.offset().left
                            });

                            this_slider_nav.find(".slick-dots").find("li").removeClass();

                            this_slider_nav.find(".slick-dots").find("li").each(
                                function() {
                                    var this_li = $(this);
                                    if (this_li.find("button").text() == ((this_index * 1) + 1)) {
                                        this_li.addClass("slick-active");
                                        return false;
                                    }
                                });
                        }
                    });
                }
            });

            setInterval(function() {
                if (sliderWrapLoad) {
//                    初期表示用の処理
                    if(this_slider_for.find(".slick-slide.act").size() == 1) {
                        this_slider_for.find(".slick-slide.slick-active").css({"opacity": 0, "z-index":800});
                        this_slider_for.find(".slick-slide").removeClass("slick-active");
                        this_slider_for.find(".slick-slide.act").addClass("slick-active");
                        this_slider_for.find(".slick-slide.act").css({"opacity": 1, "z-index":900});
                        this_slider_for.find(".slick-slide.act").removeClass("act");
                        this_slider_nav.find(".slick-list").find("div.slick-slide.slick-active[index=" + getStartIndex + "] img").click();
                    }
                    interval_index = this_slider_for.find(".slick-slide.slick-active").attr("index");

                    if (win_w > 640 || isLteIE8) {
                        this_frame.offset({
                            "left": this_slider_nav.find(".slick-list").find("div[index=" + interval_index + "]").not(".slick-cloned").offset().left
                        });
                    } else {
                        $(".slick-dots").find("li").removeClass("slick-active");
                        $($(".slick-dots").find("li")[interval_index]).addClass("slick-active");
                    }
                }
            }, 1);

            if (this_wrap.hasClass("forKirikae") ) {
                this_slider_nav.find(".slick-list").find("div.slick-slide.slick-active").on("touchend", function(e) {
                    var this_list = $(this);
                    var interval_index = this_list.attr("index");
                    var slide =this_slider_for.find(".slick-slide");
                    slide.css({"opacity": 0, "z-index":800});
                    $(slide[parseInt(interval_index)]).css({"opacity": 1, "z-index":900});
                    this_slider_nav.find(".slick-list").find("div.slick-slide.slick-active[index=" + interval_index + "] img").click();
                });
            }

            this_slider_nav.find(".slick-dots").ready(function() {
                this_slider_nav.find(".slick-dots").find("li").each(function(e) {
                    var this_li = $(this);
                    if (slide_size < (e + 1)) {
                        this_li.remove();
                    }
                });
            });

            //window resize
            $(window).on("resize", function() {
              //ie8 resize event なし
                if(!isLteIE8){
//                    this_slider_for.find(".slick-slide").css({"opacity": 0, "z-index":800});

                    setTimeout(function() {
                        this_slider_for.find(".slick-slide").each(function() {
//                            this_slider_for.find(".slick-slide").css({"opacity": 0, "z-index":800});
//                            this_slider_for.find(".slick-slide.slick-active").css({"opacity": 1, "z-index":900});
                            var this_sld = $(this);
                            var sld_index = this_sld.attr("index");

                            if (this_sld.hasClass("slick-active")) {
                                this_sld.closest(".sliderWrap").find('.slider-nav').find(".slick-list").find("div").each(function() {
                                    var this_div = $(this);
                                    if (this_div.attr("index") == sld_index && this_div.hasClass("slick-active")) {
                                        $(".frame").offset({
                                            "left": this_div.offset().left
                                        });
                                        return false;
                                    }
                                });
                            }
                        });
                    }, 100);

                }
            });
        }
    });

    //ステップ（縦型）ie8・ie9で二行目のDIVにmargin-leftを反映
    if (isLteIE8 || isLteIE9) {
        $(".verticalStep.type02 dd").each(function() {
            var this_div = $(this).find("div");
            $(this_div[1]).css({
                "margin-left": "25px",
                "width": "inherit"
            });
        });
    }

    //規約チェックボックス：labelクリック時処理
    $(window).load(function(){
        var findKiyakuCheck = $(document).find('.kiyakuCheckWrap');
        if(findKiyakuCheck.length !== 0){
            var element = document.getElementById("kiyaku_submit_btn");
            $(element).css({
                'opacity':'0.5',
                'pointer-events': 'none',
                'background-color':'#eee',
                'border': '1px solid #eee'
            });
        }
        $("#kiyaku_checkbox").on("click", function(){
            if($("#kiyaku_checkbox").attr("checked") != undefined){
                $("input[type='checkbox']#kiyaku_checkbox").attr('checked', false);
                $("#kiyaku_submit_btn").css({
                    'opacity':'0.5',
                    'pointer-events': 'none',
                    'background-color':'#eee',
                    'border': '1px solid #eee'
                });
            }else{
                $("input[type='checkbox']#kiyaku_checkbox").attr('checked', true);
                $("#kiyaku_submit_btn").removeAttr('style');
            }
        });
        $(".custom-form-checkbox").on("click", function(){
            if($("#kiyaku_checkbox").attr("checked") == undefined){
                $("#kiyaku_submit_btn").css({
                    'opacity':'0.5',
                    'pointer-events': 'none',
                    'background-color':'#eee',
                    'border': '1px solid #eee'
                });
            } else {
                $("#kiyaku_submit_btn").removeAttr('style');
            }
        });
    });

    //規約チェックボックス：labelクリック時処理（複数チェックボックス）
    $("[id^=kiyaku_multi_checkbox]").on("click", function(){
        if($("#" + $(this).attr('id')).attr("checked") != undefined){
            $("#" + $(this).attr('id')).attr('checked', false);
        }else{
            $("#" + $(this).attr('id')).attr('checked', true);
        }
    });

    //規約チェックボックスアラート処理
    $(window).load(function(){
        $("#kiyaku_submit_btn").on("click", function(){
            if($("#kiyaku_checkbox").attr("checked") != undefined){
                return true;
            }else{
                alert('確認事項の内容をご確認のうえ「同意します」にチェック願います。');
                return false;
            }
        });
        //規約チェックボックスアラート処理（複数チェックボックス）
        $("#kiyaku_submit_btn_multi_checkbox").on("click", function(){
            var flg = true;
            $("[id^=kiyaku_multi_checkbox]").each(function() {
                if($(this).attr("checked") == undefined){
                    alert('上記をご確認のうえ、チェックを入れて「同意する」をクリック（タップ）してください。');
                    flg = false;
                    return flg;
                }
            });
            return flg;
        });
    });




//    var isLteIE8 = (app.indexOf("msie 6.") != -1 || app.indexOf("msie 7.") != -1 || app.indexOf("msie 8.") != -1);


    //カテゴリ内のアコーディオンAction
    $(".serviceAccordionWrapArea .serviceAccordion").on("click", function() {
        var serviceArea = $(this).closest(".serviceAccordionWrapArea").children(".serviceAccordionArea");
        var this_height = serviceArea.height();
        var this_bord = $(this).closest(".liqC").children(".bordWNormal");
        if ($(this).hasClass("off")) {
            $(this).removeClass("off");
            $(this).addClass("on");
            $(this).html("<span></span>もっと見る");
        } else if ($(this).hasClass("on")) {
            $(this).removeClass("on");
            $(this).addClass("off");
            $(this).html("<span></span>閉じる");
        }

        if (serviceArea.hasClass("act")) {

            serviceArea.removeClass("act");
            accorAction(serviceArea, "hide", this_bord, "synchronous", "heightColTileLoad",
                this_height);
        } else {

            serviceArea.addClass("act");
            accorAction(serviceArea, "show", this_bord, "synchronous", "heightColTileLoad",
                this_height);
        }
    });

    //    カテゴリトップ
    if($(".categoryWarp").size() > 0){
        var imgCaptionTimer = false;
        var check_pc = window.innerWidth >640 || isLteIE8;
        var check_opton;
        if(check_pc){
            setCategoryTop("pc");
            check_opton = "pc";
        }else{
            setCategoryTop("sp");
            check_opton = "sp";
        }
        $(window).on("resize", function(){
          //ie8 resize event なし
            if(!isLteIE8){
                check_pc = window.innerWidth >640;
                if(check_pc && check_opton != "pc"){
                    setCategoryTop("pc");
                    check_opton = "pc";
                }else if(!check_pc){
                    setCategoryTop("sp");
                    check_opton = "sp";
                }
            }
        });
    }

    function setCategoryTop(option){

        var MyPointerEvent = com.smbc_card.util.MyPointerEvent;

        var touchStartTime, touchEndTime;
        //IE8のPNG対応
        if(isLteIE8){
            $('.categoryIcon img').each(function() {
                if($(this).attr('src').indexOf('.png') != -1) {
                    $(this).css({
                        'filter': 'progid:DXImageTransform.Microsoft.AlphaImageLoader(src="' + $(this).attr('src') + '", sizingMethod="scale");'
                    });
                }
            });
        }

        $(".categoryWarp").each(function(){
            var this_warp = $(this);
            var categoryArea = this_warp.children(".categoryArea").first();
            var categoryLinkArea = this_warp.next(".categoryLinkArea");
            var section_titles = this_warp.closest(".section").find(".categoryWarp").find(".categoryTitle");
            if(categoryLinkArea.find(".serviceAccordionWrapArea").size()>0){
                categoryLinkArea.css("padding-bottom", 25);
            }

            if(option == "pc"){
                categoryArea.find(".categoryTitle").css("width", categoryArea.width()-20);
            }else{
                categoryArea.find(".categoryTitle").css("width", "100%");
            }

            if(!this_warp.hasClass("noneIcon")){
                if(option == "pc"){
                    var areaHeight = categoryArea.height();
                    var titleHeight;
                    var max_height = 0;
                    var deleay = 80;
                    var linkArrow_position;

                    this_warp.removeClass("act");
                    if(section_titles.length > 0 && !section_titles.hasClass("setMaxHeight")){
                        section_titles.each(function(e){
                            if(max_height <= $(section_titles[e]).height()){
                                max_height = $(section_titles[e]).height();
                            }
                        });
                        categoryArea.find(".categoryTitle").height(max_height);
                        section_titles.addClass("setMaxHeight");
                        section_titles.height(max_height);
                        section_titles.find('.upArrow').css('top',((max_height-20)/2)+2+'px');
                    }

                    titleHeight = categoryArea.find(".categoryTitle").height();
                    categoryArea.css("top", "-"+titleHeight+ "px");
                    categoryArea.find(".categoryTitle").css("top", "-"+areaHeight+ "px");
                    categoryArea.find(".categoryTxt").css("top", "-"+areaHeight+ "px");

                    linkArrow_position = areaHeight-((areaHeight-(categoryArea.find(".categoryTitle").height()+categoryArea.find(".categoryTxt").height()))-35);
                    categoryArea.find(".linkArrow").css("top", "-"+linkArrow_position+ "px");
                    categoryArea.find(".closeArrow").css("top", "-"+linkArrow_position+ "px");

                    // 当該スライドパネルを開くイベントハンドラ
                    function handleOpenCategoryWrap() {
                        var $wrap = $(this);
                        if (!$wrap.hasClass('noneIcon') && !$wrap.hasClass('act')) {
                            closeAllWraps();
                            var $area = $wrap.children('.categoryArea').first();
                            var $title = $area.find('.categoryTitle').first();
                            $area.stop().animate({
                                top: '-=' + ($area.height() - $title.height()) + 'px'
                            }, deleay);
                            $wrap.addClass('act');
                        }
                        return false;
                    }

                    // 当該スライドパネルを閉じるイベントハンドラ
                    function handleCloseCategoryWrap() {
                        var $wrap = $(this);
                        if (!$wrap.hasClass('noneIcon') && $wrap.hasClass('act')) {
                            var $area = $wrap.children('.categoryArea').first();
                            var $title = $area.find('.categoryTitle').first();
                            $area.stop().animate({
                                top: '-' + ($title.height() ) + 'px'
                            }, deleay);
                            $wrap.removeClass('act');
                        }
                        return false;
                    }

                    // 全てのスライドパネルを閉じるヘルパメソッド
                    function closeAllWraps() {
                        $('.categoryWarp').each(function() {
                            handleCloseCategoryWrap.apply(this, arguments);
                        });
                    }

                    // ハンドラの多重登録を回避するために，登録済みのハンドラを解除する
                    MyPointerEvent.offMouseEnter(this_warp);
                    MyPointerEvent.offMouseLeave(this_warp);
                    MyPointerEvent.offMouseClick(this_warp);
                    MyPointerEvent.offTouchEnd(this_warp);

                    // スライドパネルが「閉じる」を含むタイプの場合
                    if (this_warp.find('.closeArrow').size() > 0) {
                        MyPointerEvent.onMouseEnter(this_warp, function() {
                            if (!$(this).hasClass('act')) {
                                return handleOpenCategoryWrap.apply(this, arguments);
                            }
                        });
                        MyPointerEvent.onMouseLeave(this_warp, function() {
                            if ($(this).hasClass('act')) {
                                return handleCloseCategoryWrap.apply(this, arguments);
                            }
                        });
                        MyPointerEvent.onMouseClick(this_warp, function() {
                            if ($(this).hasClass('act')) {
                                return handleCloseCategoryWrap.apply(this, arguments);
                            } else {
                                return handleOpenCategoryWrap.apply(this, arguments);
                            }
                        });
                        MyPointerEvent.onTouchEnd(this_warp, function(event) {
                            if ($(this).hasClass('act')) {
                                return handleCloseCategoryWrap.apply(this, arguments);
                            } else {
                                return handleOpenCategoryWrap.apply(this, arguments);
                            }
                        });
                    }
                    // スライドパネルが「閉じる」を含まない（「詳細を見る」を含む）タイプの場合
                    else {
                        MyPointerEvent.onMouseEnter(this_warp, function(event) {
                            if (!$(this).hasClass('act')) {
                                return handleOpenCategoryWrap.apply(this, arguments);
                            }
                        });
                        MyPointerEvent.onMouseLeave(this_warp, function(event) {
                            if ($(this).hasClass('act')) {
                                return handleCloseCategoryWrap.apply(this, arguments);
                            }
                        });
                        MyPointerEvent.onTouchEnd(this_warp, function(event) {
                            if (!$(this).hasClass('act')) {
                                return handleOpenCategoryWrap.apply(this, arguments);
                            } else {
                                // スライドパネル外タッチ時のハンドラが動作しないように、イベントバブリングを止める
                                event.stopPropagation();
                            }
                        });
                    }

                    // スライドパネル外をタッチした時にパネルを閉じる
                    MyPointerEvent.offTouchEnd($("body"));
                    MyPointerEvent.onTouchEnd($("body"), function() {
                        closeAllWraps.apply(this, arguments);
                    });

                }else if(option == "sp"){
                    this_warp.off("mouseout");
                    if (this_warp.hasClass("act") && this_warp.find(".closeArrow").size() > 0) {
                        categoryArea.closest(".categoryWarp").off("click");
                    }
                    if(isLteIE9){
                        this_warp.hover(
                                function(){
                                    this_warp.removeClass("act");
                                    return false
                                },
                                function(){
                                    return false
                                }
                            )
                    }
                    categoryArea.css("top", 0);
                    categoryArea.find(".categoryTitle").css("top", 0);
                    categoryArea.find(".categoryTxt").css("top", 0);
                    $(".categoryWarp").addClass("act");
                    section_titles.removeClass("setMaxHeight");
                }
            } else {
                if(option == "pc"){
                    this_warp.removeClass("act");
                    this_warp.hover(
                            function(){
                                this_warp.css("opacity", "1");
                            },
                            function(){
                                this_warp.css("opacity", "1");
                            }
                        )
                }
            }

            if (categoryArea.find("span.closeArrow").size()>0) {
                this_warp.css("cursor", "pointer");
            }

          //clickイベント-----start
            if(categoryArea.find(".categoryLink").size()>0){
                this_warp.css("cursor", "pointer");

                if(option == "pc"){
                    //this_warp.off("click touchstart");
                    MyPointerEvent.offTouchStart(this_warp);
                    MyPointerEvent.onTouchStart(this_warp, function() {
                        var $wrap = $(this);
                        if ($wrap.hasClass('act') || $wrap.hasClass('noneIcon')) {
                            var $area = $wrap.children('.categoryArea').first();
                            var $link = $area.find('.categoryLink');
                            window.location = $link.attr('href');
                        }
                    });
                    MyPointerEvent.offMouseClick(this_warp);
                    MyPointerEvent.onMouseClick(this_warp, function() {
                        var $wrap = $(this);
                        if ($wrap.hasClass('act') || $wrap.hasClass('noneIcon')) {
                            var $area = $wrap.children('.categoryArea').first();
                            var $link = $area.find('.categoryLink');
                            window.location = $link.attr('href');
                        }
                    });
                }else{
                    this_warp.off("click touchstart");
                    //resizeするときの中腹処理防止
                    this_warp.off("touchstart mouseover");
                    this_warp.on("touchstart mouseover", function(){
                        this_warp.css("opacity", "0.5");
                        this_warp.addClass("onTouch");
                    });

                    $("body").on("touchmove mouseout",function(){
                        $(".categoryWarp").removeClass("onTouch");
                        $(".categoryWarp").css("opacity", "1");
                    });

                    this_warp.on("touchend", function(){
                        $(".categoryWarp").css("opacity", "1");
                        if(this_warp.hasClass("act") || this_warp.hasClass("noneIcon")){
                            if(this_warp.hasClass("onTouch")){
                                window.location = categoryArea.find(".categoryLink").attr("href");
                            }
                            return false
                        }
                    });
                    if(!ua.isAndroid){
                        this_warp.on("click", function(){
                            if(this_warp.hasClass("act") || this_warp.hasClass("noneIcon")){
                                window.location = categoryArea.find(".categoryLink").attr("href");
                            }
                        });
                    }
                }
            }
            //clickイベント-----end
        });
    }


    $(".serviceAccordionWrapArea .serviceAccordion").each(function() {
        var this_area = $(this);

        $(window).load(function() {
            var this_width = this_area.width();
            var bord_width = this_area.closest(".serviceAccordionWrapArea").width();
            var bord_offet_left = this_area.closest(".serviceAccordionWrapArea").offset().left;
            var set_left = bord_offet_left + ((bord_width - this_width - 10) / 2);
            this_area.offset({
                left: set_left
            });
        });

        $(window).resize(function() {
          //ie8 resize event なし
            if(!isLteIE8){
                var this_width = this_area.width();
                var bord_width = this_area.closest(".serviceAccordionWrapArea").width();
                var bord_offet_left = this_area.closest(".serviceAccordionWrapArea").offset().left;
                var set_left = bord_offet_left + ((bord_width - this_width - 10) / 2);
                this_area.offset({
                    left: set_left
                });
            }
        });
    });

    //justify
    var textJustify = function(arg){
        $(arg).each(function(){
            var target = $(this);
            var get_width = target.width();
            var get_font_size = target.css('font-size').match("[0-9]*");
            var get_text = target.text();
            var text_length = get_text.length;
            var set_spacing = Math.floor( ( ( get_width - ( get_font_size * text_length ) ) / ( text_length-1 ) ) * 10 ) / 10;

            target.html("<span>" + get_text.slice(0, -1) + "</span>" + get_text.slice(-1));
            target.find("span").css("letter-spacing", set_spacing + "px");
        });
    };
    //textJustify(".reception_wrap .title");

});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////querty_4 end///////////////////////////////

/**
 * Capy画像サイズ対応
 */
(function() {
    function reloadAllCapyImg() {
        // 会員TOPメインコンテンツエリアのCapy
        if(typeof(puzzleApp) !== 'undefined') {
            puzzleApp.loadPuzzleImage();
        }

        // SP表示時の左スライドメニュー内のCapy
        if(typeof(PuzzleApp2) !== 'undefined') {
            PuzzleApp2.loadPuzzleImage();
        }

        // 会員下層ページPCレイアウト時の左サイドメニューエリアのCapy
        if(typeof(PuzzleApp3) !== 'undefined') {
            PuzzleApp3.loadPuzzleImage();
        }
    }

    function getScreenWidth() {
        var doc = document;
        return doc.body ? (window.innerWidth || doc.body.clientWidth) : window.innerWidth;
    }

    var id;
    function setResizeHandler() {
        // IE8では画面内の要素に変更があるたびにresizeイベントが呼ばれ、
        // 画像の再リロード→resize→画像の再リロード、と無限ループしてしまうため、
        // 画面幅を取得して変更があった場合にだけ次の処理に進める。
        var lastWidth = $(window).width();
        var lastHeight = $(window).height();

        $(window).on('resize.capy', function() {
            var currWidth = $(window).width();
            var currHeight = $(window).height();
            if ((currWidth === lastWidth) && (currHeight === lastHeight)) {
                return;
            } else {
                lastWidth = currWidth;
                lastHeight = currHeight;
            }

            if(640 < getScreenWidth()) {
                return;
            }
            clearTimeout(id);
            id = setTimeout(function() {
                reloadAllCapyImg();
            }, 200);
        });
    }

    if(!device.mobile()) {
        $(window).on('enterBreakpoint641', function() {
            clearTimeout(id);
            setTimeout(reloadAllCapyImg, 200);
        });
        $(window).setBreakpoints({
            distinct: true,
            breakpoints: [641]
        });
        setResizeHandler();
    }
})();

/**
 * Capyエリア内ではパズル操作に支障が出るためコンテキストメニューの表示を抑制する.
 */
(function($) {
    $(document).ready(function() {
        var $capyAreaList = $('.capy-captcha, .capyArea, .capyArea img');
        $capyAreaList.on('contextmenu', function() {
            return false;
        });
    })
})(jQuery);

/* ヘッダ・フッター関連 */
(function($) {
  var $win = $(window);
  var $baseContents = $('header');
  // 共通ヘッダメニュー開閉
  var $header = $('#header');
  $(".subMenu_item-menu").click(function() {
    $('.megaMenu').not('.megaMenubtn').stop(true, true).toggle("slide", { direction: "right" });
    $header.toggleClass('isSpMenuOpen');

    //メガドロメニュー閉
    $('.jsAccordionToggle' + '.jsAccordion_active').click();

    if($header.hasClass('isSpMenuOpen')) {
      $headerOverlay.addClass('isShow'); // オーバーレイを表示
    }else {
      $headerOverlay.removeClass('isShow'); // オーバーレイを表示
    }

    return false;
  });

  // グロナビのjQueryオブジェクト
  var $megaMenu = $('.megaMenu');
  var $megaMenu_items = $('.megaMenu_item');
  var $megaMenu_body = $('.megaMenu_itemBody');
  // 検索エリアのjQueryオブジェクト
  var $searchArea = $('#searchArea');
  // ヘッダーオーバーレイ
  var $headerOverlay = $('#header_overlay');
  // 検索エリアを開閉
  var switchSearchBox = function(doClose) {
    if ($searchArea.is(':visible')) { // 検索エリアが開いている場合
      if (doClose) {
        $searchArea.slideDown();
      } else {
        $searchArea.slideUp();
      }
    } else { // 検索エリアが閉じている場合
      if (!doClose) {
        $searchArea.slideUp();
      } else {
        $searchArea.slideDown();
      }
    }
  };
  // メガメニュー全体のイベント処理
  var setHoverTimeOut;
  $megaMenu.on('mouseleave', function () {
    clearTimeout(setHoverTimeOut);
    if (window.innerWidth <= 640) return;
    // mouseleave
    if ($headerOverlay.hasClass('isShow')) {
      if ($searchArea.is(':hidden')) {
        $headerOverlay.removeClass('isShow'); // オーバーレイを非表示
      }
    }
    $megaMenu_items.removeClass('megaMenu_item-isMenuOpen');
  });

  // メガメニューの第一階層毎のイベント処理
  // PC用はmouseenterとmouseleaveで判定
  $megaMenu_items.on('mouseenter', function () {
    var $this = $(this);
    var ua = navigator.userAgent;
    if (window.innerWidth <= 640 || ua.indexOf('iPad') > -1 || ua.indexOf('Android') > -1) return;

    // mouseenter
    var wait = 400;
    if ($megaMenu_items.siblings('.megaMenu_item-isMenuOpen').length) {
      wait = 150;
    }
    setHoverTimeOut = setTimeout(function(){ //一定時間以上hoverでメニュー表示
      if ($this.hasClass('linkMenu')) {
        if (!($searchArea.is(':visible'))) { // 検索エリアが開いてない
          $headerOverlay.removeClass('isShow'); // オーバーレイを非表示
        }
      } else {
        $headerOverlay.addClass('isShow'); // オーバーレイを表示
      }
      $megaMenu_items.not($this).removeClass('megaMenu_item-isMenuOpen');
      $this.addClass('megaMenu_item-isMenuOpen');
    }, wait);
  });
  $megaMenu_items.on('mouseleave', function() {
    // mouseleave
    clearTimeout(setHoverTimeOut);
  });
  // SP/Tablet用はtouchstartで判定
  $megaMenu_items.on('touchstart', function() {
    // touchstart
    var $this = $(this);


    if(window.innerWidth <= 640) {
      if (!($this.hasClass('linkMenu'))) {
        if ($this.hasClass('megaMenu_item-isMenuOpen')) {
          $this.removeClass('megaMenu_item-isMenuOpen');
          $headerOverlay.removeClass('isShow'); // オーバーレイを非表示
        } else {
          $megaMenu_items.removeClass('megaMenu_item-isMenuOpen');
          $this.addClass('megaMenu_item-isMenuOpen');
          $headerOverlay.addClass('isShow'); // オーバーレイを表示
        }
      }
    }
  });
  // メガメニューの本体内ではtouchstartイベント伝搬しないようにする
  $megaMenu_body.on('touchstart', function(e) {
    e.stopPropagation();
  });

  // サイト内検索ボタンクリック時
  var $subMenu_itemSearch = $('.subMenu_item-search');
  $subMenu_itemSearch.click(function(e) {
    if ($searchArea.is(':visible')) { // 検索エリアが開いている場合
      $headerOverlay.removeClass('isShow');
      $searchArea.slideToggle('up');
      $megaMenu_items.removeClass('megaMenu_item-isMenuOpen'); // クリックされたメガメニュー意外を閉じる
    } else { // 検索エリアが閉じている場合
      $headerOverlay.addClass('isShow');
      $searchArea.slideToggle('up');
    }
    // e.preventDefault();
    return false;
  });
  // メガメニューまたは検索エリア外クリック時クローズ
  $('body').on('click touchstart', function(e) {
    if(window.innerWidth > 640) {
      if ($headerOverlay.hasClass('isShow')) {
        if (!$searchArea.has(e.target).length &&
            !$subMenu_itemSearch.has(e.target).length &&
            !$megaMenu.has(e.target).length) {
          if ($searchArea.is(':visible')) { // 検索エリアが開いている場合閉じる
            $searchArea.slideUp();
          }
          $megaMenu_items.removeClass('megaMenu_item-isMenuOpen');
          $headerOverlay.removeClass('isShow'); // オーバーレイを消す

          // SPでclickとtouchstartが2回実施されないようにpreventDefaultで抑止
          if (e.cancelable) {
            e.preventDefault();
          }
        }
      }
    }
  });

  // 会員情報のjQueryオブジェクト(PC時)
  var $userInfo = $('.subMenu_userInfo_title');
  // モーダル初期化
  $userInfo.magnificPopup({
    type: 'inline',
    preloader: false,
    showCloseBtn: false,
    fixedContentPos: true,
    fixedBgPos: false,
    disableOn: function() {
      if ($(window).width() > 640) {
        return false;
      }
      return true;
    },
    callbacks: {
        beforeOpen: function() {
        },
        open: function() {
          $('.js-modal_close').on('click', function(e){
            e.preventDefault();
            $.magnificPopup.close();
          });
        }
    },
  });
  // ドロップダウンの開閉
  var $subMenu_dropdown = $('.subMenu_dropdown')
  $subMenu_dropdown.click(function() {
    $(this).toggleClass('isShow');
  });
  // ドロップダウン内リンククリック時にドロップダウン下の要素へのイベント伝搬を抑止
  $('.subMenu_dropdown_item_link').click(function(e) {
    e.stopPropagation();
  });
  // ドロップダウンの外側クリック時にドロップダウンを閉じる
  $('body').on('click touchstart', function(e) {
    if(window.innerWidth > 640){
      if (!$subMenu_dropdown.is(e.target) ) {
        if (!$subMenu_dropdown.has(e.target).length) {
          $subMenu_dropdown.removeClass('isShow');
        }
      }
    }
  });

  // 共通ヘッダ・フッターアコーディオン用
  $('.jsAccordionToggle').click(function(){
    if(window.innerWidth <= 640){
      $(this).next().slideToggle();
      $(this).toggleClass('jsAccordion_active');
      //親要素のボーダー調整
      if($(this).hasClass('jsAccordion_active')){
          $(this).parent('.megaMenu_item').css('border', 'none');
      } else {
          $(this).parent('.megaMenu_item').attr('style', '');
      }

      var $this = $(this);
      if($(this).hasClass('megaMenu_itemTitle')) {
          $('.jsAccordion_active').not($this).next().slideToggle();
          $('.jsAccordionToggle').not($this).removeClass('jsAccordion_active');

          if($(this).hasClass('jsAccordion_active')) {
              $headerOverlay.addClass('isShow'); // オーバーレイを表示
              $(this).next().children().scrollTop(0);

              //表示エリア高さ調整
              var windowHeight = $(window).height();
              var smbcLine_height = $('#smbcLine').outerHeight();
              var header_height = $('#header').outerHeight();
              var head_height = windowHeight - smbcLine_height - header_height;
              $('.megaMenu_subMenu').css('max-height', head_height)
          } else {
              $headerOverlay.removeClass('isShow'); // オーバーレイを非表示
          }
      }
    }
  });

  // アコーディオン内に設けた閉じるボタンにてアコーディオン閉じる動作を行う
  $('.megaMenu_subClsBtn').click(function(){
    if(window.innerWidth <= 640){
      $(this).parent().parent().parent().find('.jsAccordionToggle').click();
    }
  });

  // 追従ヘッダ
  // イベントを間引く
  function debounce(func, wait, immediate) {
    var timeout;
    return function() {
      var context = this, args = arguments;
      var later = function() {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      var callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
  }

  function throttle(callback, limit) {
    var wait = false;
    return function() {
      if (wait) {
        return;
      }
      callback.call();
      wait = true;
      setTimeout(function() {
        wait = false;
      }, limit);
    };
  }

  var $smbc_line = $('#smbcLine');
  var $header = $('#header');
  var $contWrap = $('#contWrap');
  function onScroll() {
    var currentPos = $(this).scrollTop();
    var smbcLine_height = $smbc_line.outerHeight();
    var head_height = $header.outerHeight();

    if (window.innerWidth > 640) {
      //pc
      if (currentPos > smbcLine_height) {
        $header.addClass('header-fixed');
        if(document.URL.match("/mem/platinum/") && !$('.bordCardBox').length) {
          $contWrap.css('margin-top', head_height+15);
        } else {
          $contWrap.css('margin-top', head_height);
        }
        // 固定ヘッダのスクロール対応
        $header.css('left', - $win.scrollLeft());
      } else {
        $header.removeClass('header-fixed');
        $contWrap.css('margin-top', '');
        $header.css('left', '');
      }
    } else {
      //sp
      var total_height = smbcLine_height + 60;
      if (currentPos > total_height) {
        $header.addClass('header-fixed');
        if(document.URL.match("/mem/platinum/") && !$('.bordCardBox').length) {
          $contWrap.css('margin-top', 155);
        } else {
          $contWrap.css('margin-top', 135);
        }
        // SP時表示は固定ヘッダのスクロール調整をしない
        $header.css('left', '');
      } else {
        $header.removeClass('header-fixed');
        $contWrap.css('margin-top', '');
        $header.css('left', '');
      }
    }
  }
  $win.on('load', onScroll);
  $win.on('scroll', throttle(onScroll, 200));
  $win.on('scroll', debounce(onScroll, 200));

  // SP時smbcLineの高さがリサイズにより変わるため、それに合わせてメニュー高さを調整
 /*
  $win.on('load resize', function() {
    // メガメニューの高さ調整
    if (window.innerWidth <= 640) {
      var offset = $header.height() - 75;
      $megaMenu.css({'height': window.innerHeight - offset});
    }
  });
*/

  // MediaQueryが切り替わった際に実行
  var mq = window.matchMedia('screen and (max-width: 640px)');
  function onMqChange(mq) {
    $headerOverlay.removeClass('isShow'); // オーバーレイを非表示
    if (mq.matches) {
      // SP
    } else {
      // PC
      $baseContents.attr('style', ''); // SP時メニューオープン状態でPC幅に切り替えたときにstyleを消す
      $('.megaMenu').attr('style', '');
      $('#header').removeClass('isSpMenuOpen');

      $megaMenu_items.removeClass('megaMenu_item-isMenuOpen');
      $('.jsAccordionToggle').next().attr('style',''); //アコーディオンを開閉した状態でpcに切り替えたときのstyleを消す。
      $('.jsAccordion_active').removeClass('jsAccordion_active');
      $('.megaMenu_item').attr('style', '');
    }
  }
  // アコーディオンのデフォルトオープン処理(DomContentLoaded時)
  // PC時はメガメニューを開いてしまうのでSP時のみ実施する
  if (window.innerWidth <= 640) {
    $('.jsAccordion_active_default').click();
  }
  mq.addListener(onMqChange);
})(jQuery);
/* /ヘッダ・フッター関連/ */

//table再構築用
$(function(){
  var tableClassNames = [];
  var tableClassName = [];
  var tableLayout = [];
  $('table').each(function(i,e){
    var _this = $(this);
    var _thisClass = _this.attr('class');
    if(_thisClass){
        tableClassNames = _this.attr('class').split(' ');
    }
    tableClassName = tableClassNames.filter(function(item){
        return item.match('jsSpTableLayout');
    });
    tableLayout = tableClassNames.filter(function(item){
        return item.match('tableLayoutException');
    });

    if(tableClassName != ""){
      tableSpLayout(_this,tableClassName,tableLayout);
    }
  });
  $('.tableAccordionHeading').on('click',function(){
    $(this).next().slideToggle();
    $(this).toggleClass('jsTableAccordion_active');
    //高さ調整
    $(".column2 .tableAccordionContentsInner").each(function(){
        $(this).find(".tableAccordionContentHeading2").tile();
    });

  });
});

//class名にjsSpTableLayoutが含まれるtableタグが存在する場合処理を実行
function tableSpLayout(_this, tableClassName, tableLayout){
  var tableTempHtml = '';
  var tableData = {};

  $(_this).find('tr').each(function(i,e){
    tableData[i] = {};
  });
  //table要素を2次元配列として取得
  $(_this).find('tr').each(function(i,e){
    var rowData = {};
    $(this).find('th , td').each(function(j,el){
      rowData[j] = {};
      rowData[j].text = $(this).html();
      rowData[j].rowSpan = $(this).attr('rowspan');
      rowData[j].colSpan = $(this).attr('colspan');
      tableData[i][j] = rowData[j];
    });
  });

  //テキストが入っている要素の列数を取得する
  var colCount = 0;
  for(var i=0; i < Object.keys(tableData[0]).length; i++){
    if(tableData[0][i].text != ""){
      colCount++;
    }
  }

  if(tableClassName == 'jsSpTableLayout_01'){

    //HTML生成
    tableTempHtml += '<div class="tableSpLayout_01 forSpBlock">';

    for(var i=0; i < Object.keys(tableData[0]).length; i++){
      tableTempHtml += '<div class="tableContent">';
      for(var j=0; j < Object.keys(tableData).length; j++){
        if(j==0){
          tableTempHtml += '<div class="tableHeading">' + tableData[j][i].text + '</div>';
        } else {
          tableTempHtml += '<div class="tableText">' + tableData[j][i].text + '</div>';
        }
      }
      tableTempHtml += '</div>';
    }
    tableTempHtml += '</div>';

  } else if(tableClassName == 'jsSpTableLayout_02'){
    //HTML生成
    if(colCount <= 2){
      if(tableLayout == 'tableLayoutException'){
        tableTempHtml += '<div class="tableSpLayout_02 column3 forSpBlock">';
      } else {
        tableTempHtml += '<div class="tableSpLayout_02 column2 forSpBlock">';
      }
    } else {
      tableTempHtml += '<div class="tableSpLayout_02 column3 forSpBlock">';
    }

    for(var i=1; i < Object.keys(tableData).length; i++){
      tableTempHtml += '<div class="tableContent">';
        tableTempHtml += '<div class="tableAccordionHeading">' + tableData[i][0].text + '</div>';
        tableTempHtml += '<div class="tableAccordionContents">';
          tableTempHtml += '<div class="tableAccordionContentsInner">';
        for(var j=1; j < Object.keys(tableData[0]).length; j++){
            tableTempHtml += '<div class="tableAccordionContent">';
              tableTempHtml += '<div class="tableAccordionContentHeading2">' + tableData[0][j].text + '</div>';
              tableTempHtml += '<div class="tableAccordionText">' + tableData[i][j].text + '</div>';
            tableTempHtml += '</div>';
        }
          tableTempHtml += '</div>';
        tableTempHtml += '</div>';
      tableTempHtml += '</div>';
    }
    tableTempHtml += '</div>';

  } else if(tableClassName == 'jsSpTableLayout_03'){
    //HTML生成
    if (colCount <= 2) {
        if(tableLayout == 'tableLayoutException'){
            tableTempHtml += '<div class="tableSpLayout_03 column3 forSpBlock">';
        } else {
            tableTempHtml += '<div class="tableSpLayout_03 column2 forSpBlock">';
        }
    } else {
      tableTempHtml += '<div class="tableSpLayout_03 column3 forSpBlock">';
    }

    var rowSpanCount = 0;
    for(var i=1; i < Object.keys(tableData).length; i++){


      tableTempHtml += '<div class="tableContent">';
        tableTempHtml += '<div class="tableAccordionHeading">' + tableData[i][0].text + '</div>';
        tableTempHtml += '<div class="tableAccordionContents">'; //アコーディオンコンテンツ

        if(tableData[i][0].rowSpan){ //trの先頭列にrowspanがあるとき
          rowSpanCount = tableData[i][0].rowSpan;
          for(var k=0; k < rowSpanCount; k++){ //rowspanの数だけ行数ループさせる。
            if(k == 0){ //rowspanのついてる行のとき
              if(!tableData[i][0].colSpan){
                tableTempHtml += '<div class="tableAccordionContentHeading">' + tableData[i][1].text + '</div>';
              }
              tableTempHtml += '<div class="tableAccordionContentsInner">';

              var j = Object.keys(tableData[i]).length - colCount;
              for(j; j < Object.keys(tableData[i]).length; j++){
                tableTempHtml += '<div class="tableAccordionContent">';
                if(!tableData[i][0].colSpan){
                  tableTempHtml += '<div class="tableAccordionContentHeading2">' + tableData[0][j-1].text + '</div>';
                } else {
                  tableTempHtml += '<div class="tableAccordionContentHeading2">' + tableData[0][j].text + '</div>';
                }
                tableTempHtml += '<div class="tableAccordionText">' + tableData[i][j].text + '</div>';
                tableTempHtml += '</div>';
              }

              tableTempHtml += '</div>';

            } else { //rowspanのついていない行のとき

              if(!tableData[i][0].colSpan){
                tableTempHtml += '<div class="tableAccordionContentHeading">' + tableData[i+k][0].text + '</div>';
              }
              tableTempHtml += '<div class="tableAccordionContentsInner">';

              var j = Object.keys(tableData[i]).length - colCount;
              for(j; j < Object.keys(tableData[i]).length; j++){
                  tableTempHtml += '<div class="tableAccordionContent">';
                  if(!tableData[i][0].colSpan){
                    tableTempHtml += '<div class="tableAccordionContentHeading2">' + tableData[0][j-1].text + '</div>';
                  } else {
                    tableTempHtml += '<div class="tableAccordionContentHeading2">' + tableData[0][j].text + '</div>';
                  }
                    tableTempHtml += '<div class="tableAccordionText">' + tableData[i+k][j-1].text + '</div>';
                  tableTempHtml += '</div>';
              }

              tableTempHtml += '</div>';

            }
          }
        } else {
          if(!tableData[i][0].colSpan){
            tableTempHtml += '<div class="tableAccordionContentHeading">' + tableData[i][1].text + '</div>';
          }
          tableTempHtml += '<div class="tableAccordionContentsInner">';

          var j = Object.keys(tableData[i]).length - colCount;
          for(j; j < Object.keys(tableData[i]).length; j++){
            if(tableData[i][0].rowSpan){

            }
              tableTempHtml += '<div class="tableAccordionContent">';
              if(!tableData[i][0].colSpan){
                tableTempHtml += '<div class="tableAccordionContentHeading2">' + tableData[0][j-1].text + '</div>';
              } else {
                tableTempHtml += '<div class="tableAccordionContentHeading2">' + tableData[0][j].text + '</div>';
              }
                tableTempHtml += '<div class="tableAccordionText">' + tableData[i][j].text + '</div>';
              tableTempHtml += '</div>';
          }

          tableTempHtml += '</div>';
        }

        tableTempHtml += '</div>';
      tableTempHtml += '</div>';



      if(tableData[i][0].rowSpan){
        i += tableData[i][0].rowSpan -1;
      }
    }

    tableTempHtml += '</div>';
  }

  //HTMLを挿入
  _this.after(tableTempHtml);
}

//M-BT-10 CVエリア - 固定　閉じるボタン動作
(function(){
    var key = 'followBtnArea';
    var target = $(document).find(".followBtnArea");
    if (!target.length) {
        return;
    }
    if(sessionStorage.getItem(key)){
        target.hide();
    } else {
        var pgTopBtn = $(document).find(".pgTopLinkWrap");
        if (pgTopBtn.length) {
            if ($(window).width() > 640) {
                pgTopBtn.css("bottom", "100px")
            } else {
                pgTopBtn.css("bottom", "87px")
            }
        }
        target.show();
    }
    $(document).find(".followBtnArea_cloase").on("click",function(){
        sessionStorage.setItem(key, 'hide');
        target.hide();
        pgTopBtn.removeAttr('style');
    });
})();
//M-FL-1  ステップ 　最後の要素のを特定しクラス付与
(function(){
    $(function(){
        $(".verticalStep").each(function(){
            //.verticalStepの次に.verticalStepが続かないもしくは最後の要素になるときクラスを付与
            if(!$(this).next() || !$(this).next().hasClass("verticalStep")){
                $(this).addClass("last");
            }
        });
    });
})();

//M-OP-1-1  タブ：タブ数が多い場合 (SP /タブ名称文字列が長い場合)
(function(){
    var _document = $(document);
    var tabAreaWrap = _document.find(".tabAreaWrap");
    tabAreaWrap.each(function(){
        var _this = $(this);
        var tabHead = _this.find(".tabHead");
        var item = tabHead.find("li");

        if(item.length > 9){
            var div = $('<div class="acdiTab"></div>');
            item.each(function(){
                var newAcd = $('<div><h3 class="acdiHead"><span class="acdiBtn"></span></h3><div class="acdiBody"></div></div>');
                var thisClass = $(this).attr("class");
                var class_Array = thisClass.split(" ");
                var thisNumber = class_Array.filter(function(v){
                    return v.match(/item/);
                });
                var targetTabBodyName = ".tabBody" + thisNumber[0].replace(/item/,"");
                var targetTabBody = _this.find(targetTabBodyName);

                newAcd.find(".acdiHead").prepend($(this).html());
                newAcd.find(".acdiBody").append(targetTabBody.html());
                div.append(newAcd);
            });
            _this.html(div);
            $(_this).on("click",".acdiHead",function(){
                $(this).next(".acdiBody").slideToggle();
                var btn =$(this).find(".acdiBtn");
                if(btn.hasClass("on")){
                    btn.removeClass("on");
                    btn.addClass("off");
                }else if(btn.hasClass("off")){
                    btn.removeClass("off");
                    btn.addClass("on");
                }
            });
            $(window).on("load",function(){
                _this.find(".acdiHead").eq(0).next(".acdiBody").show();
                _this.find(".acdiHead").eq(0).find(".acdiBtn").removeClass("on").addClass("off");
            });
        }
    });
})();

//M-OP-2 アコーディオンL 最後の要素のを特定しクラス付与
(function(){
        $(document).find("h2.acdiHeadL,h3.acdiHead").each(function(){
            function addLast(target){
                if(target.parent(".acdiBody").length == 0){
                    target.addClass("acdiLast");
                }
            }

            if($(this).next(".acdiBody").next().length == 0){//acdiBodyの次の要素がない
                if($(this).parent().next() !== undefined){//親要素の次の要素がある
                    if(!$(this).parent().next().find("*:first").hasClass("acdiHead") && !$(this).parent().next().find("*:first").hasClass("acdiHeadL")){//親要素の次の要素の最初の子要素がacdiHeadではない
                         addLast($(this));
                    }
                }else{//親要素の次の要素がない
                     addLast($(this));
                }

            }else if(!$(this).next(".acdiBody").next().hasClass("acdiHead") && !$(this).next(".acdiBody").next().hasClass("acdiHeadL")){//acdiBodyの次の要素がacdiHeadではない
                 addLast($(this));
            }
        });
})();

//M-BO-10-1  お問い合わせ（2件以上）　レイアウト変更
(function(){
    var inquiryCol = $(document).find(".inquiryColWrap");
    if(inquiryCol){
        var parent = inquiryCol.parent(".inquiryWrapArea");
        parent.each(function(){
            var $inquiryWrap = $(this).find(".inquiryWrap").clone();
            var $inquiryIcon = $(this).find(".inquiryIcon");
            var $newInquiryColWrap = $("<div class='inquiryColWrap'></div>");
            $newInquiryColWrap.append($inquiryWrap);
            $inquiryIcon.nextAll().remove();
            $inquiryIcon.after($newInquiryColWrap);
        });
    }
})();

//M-BO-12 アプリ ダウンロード（iOS/Android）  端末出し分け
(function(){
    $(document).ready(function(){
        var isAndroid = navigator.userAgent.match(/Android/i) != null;
        var isiOS = navigator.userAgent.match(/iPhone/i) != null || navigator.userAgent.match(/iPad/i) != null;
        if(isAndroid){
            $('.switch-ios').hide();
            $('.switch-pc').hide();
            $('.switch-android').show();
        }
        else if(isiOS){
            $('.switch-android').hide();
            $('.switch-pc').hide();
            $('.switch-ios').show();
        }
        else{
            $('.switch-android').hide();
            $('.switch-ios').hide();
            $('.switch-pc').show();
        }
    });
})();

//M-IM-6-1  スライドバナー  表示・挙動制御
if ($(document).find(".swiper-container").length) {
    var mySwiper = new Swiper('.swiper-container', {
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            641: {
                centeredSlides: false,
                slidesPerView: 3,
                spaceBetween: 20,
            }
        },
        loop: false,
        slidesPerView: 1.34,
        spaceBetween: 30,
        centeredSlides: true,
        followFinger: false,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        pagination: {
            el: ".swiper-pagination",
            type: "bullets"
        },
    });
}

//M-FL-1-3  操作ステップ  表示・挙動制御
if ($(document).find(".step-swiper").length) {
    var slider1 = new Swiper('.slider1', {
        navigation: {
            nextEl: '.step-swiper-button-next',
            prevEl: '.step-swiper-button-prev',
        },
        breakpoints: {
            641: {
                centeredSlides: false,
                slidesPerView: 3,
                spaceBetween: 20,
            }
        },
        loop: false,
        slidesPerView: 1.2,
        spaceBetween: 30,
        centeredSlides: true,
        followFinger: false,
        nextButton: '.step-swiper-button-next',
        prevButton: '.step-swiper-button-prev',
        pagination: {
            el: ".step-swiper-pagination",
            type: "bullets"
        },
    });
    var slider2 = new Swiper('.slider2', {
        navigation: {
            nextEl: '.step-swiper-button-next',
            prevEl: '.step-swiper-button-prev',
        },
        breakpoints: {
            641: {
                centeredSlides: false,
                slidesPerView: 3,
                spaceBetween: 20,
            }
        },
        loop: false,
        slidesPerView: 1.2,
        spaceBetween: 30,
        centeredSlides: true,
        followFinger: false,
        nextButton: '.step-swiper-button-next',
        prevButton: '.step-swiper-button-prev',
        pagination: {
            el: ".step-swiper-pagination",
            type: "bullets"
        },
    });
    var slider3 = new Swiper('.slider3', {
        navigation: {
            nextEl: '.step-swiper-button-next',
            prevEl: '.step-swiper-button-prev',
        },
        breakpoints: {
            641: {
                centeredSlides: false,
                slidesPerView: 3,
                spaceBetween: 20,
            }
        },
        loop: false,
        slidesPerView: 1.2,
        spaceBetween: 30,
        centeredSlides: true,
        followFinger: false,
        nextButton: '.step-swiper-button-next',
        prevButton: '.step-swiper-button-prev',
        pagination: {
            el: ".step-swiper-pagination",
            type: "bullets"
        },
    });
}

//M-BO-11  規約 表示作成
($(window).on('load', function(){
    var $kiyakuBody = $(document).find(".kiyaku");
    var $kiyakuHead = $kiyakuBody.children("h2");
    $kiyakuHead.removeClass("acdiHead");
    $kiyakuHead.find(".acdiBtn").remove();

    var print = $(document).find('[href="javascript:window.print();"]');
    if(print.length !== 0){
        $(document).find('.kiyaku .kiyakuTable').css('padding', '40px 0 0');
        return false;
    }
    // SimpleBar初期化
    $('.defTextarea').css('overflow', 'visible');
    $('.defTextarea').each(function(i, el) {
      new SimpleBar(el, { autoHide: false });
    });
}));

//M-BO-6  キャンペーン情報
(function(){
    var sliderTemplate ='<div>\
                <div class="campaign swiper-container">\
                    <div class="campaign swiper-wrapper"></div>\
                    <div class="campaign swiper-pagination"></div>\
                </div>\
                <div class="campaign swiper-button-prev"></div>\
                <div class="campaign swiper-button-next"></div>\
            </div>';
    var sliderElement = $(sliderTemplate);

    function campaignSwiper(campaignItem){
        var campaignSwiper = new Swiper('.campaignSlider .swiper-container', {
            navigation: {
                nextEl: '.campaign.swiper-button-next',
                prevEl: '.campaign.swiper-button-prev'
            },
            autoHeight:true,
            loop: false,
            autoHeight: false,
            centeredSlides: true,
            slidesPerView: 1.34,
            spaceBetween: 30,
            pagination: {
              el: '.campaign.swiper-pagination',
              clickable: true
            },
            breakpoints: {
              641: {
                centeredSlides : false,
                slidesPerView: 3,
                spaceBetween: 20
              }
            }
        });
        var imgHeight = function(){
            var h = campaignItem.find(".rectangle_banner img").eq(0).height();
            if(h == 0){
                h = campaignItem.width()*0.83;
            }
            return h;
        }
        sliderElement.find(".swiper-button-next,.swiper-button-prev").css("top",imgHeight() /2 - 45/2 + 20 + "px");

        var timer = 0;
        $(window).on("resize",function(){
          if (timer > 0) {
            clearTimeout(timer);
          }

          timer = setTimeout(function () {
            sliderElement.find(".swiper-button-next,.swiper-button-prev").css("top",imgHeight() /2 - 45/2 + 20 + "px");
          }, 200);
        });
    }

    var targetElement = document.getElementById("campaignListArea");

    var observer  = new MutationObserver(function(){
        observer.disconnect();//監視を破棄
        //キャンペーンが追加されたとき
        var $campaignSlider = $(document).find(".campaignSlider");
        var $campaignListArea = $campaignSlider.find("#campaignListArea");
        var campaignItem = $campaignListArea.find(".item");
        $campaignListArea.remove();
        $campaignSlider.eq(0).append(sliderElement);
        sliderElement.find(".swiper-wrapper").append(campaignItem);

        campaignSwiper(campaignItem);
    });
    var config = { attributes: true, childList: true, characterData: true };
    //キャンペーンが追加されるのを待つ
    if(targetElement){
        observer.observe(targetElement,config);
    }
})();

//M-IM-5-1  動画モーダル
$(function($) {
    function setDialog(calc_pos) {
        var ww = $(window).width();
        if (calc_pos) {
            var cw = Math.round($(window).width() * 0.7);
            var left = (ww - cw) / 2;
            $('#modalMovie').dialog({
                autoOpen: false,
                width: '70%',
                modal: true,
                position: [left, null]
            });
        } else if(640 > ww) {
            $('#modalMovie').dialog({
                autoOpen: false,
                width: '95%',
                modal: true,
                position: [null, null]
            });
        } else if(ww > 640) {
            $('#modalMovie').dialog({
                autoOpen: false,
                width: 'auto',
                modal: true,
                position: [null, null]
            });
        }
    }
    if (device.tablet()) {
        if (Math.abs(window.orientation) === 90) {
            setDialog();
        } else {
            setDialog(true);
        }
        $(window).on("orientationchange", function() {
            // //横向き
            if (Math.abs(window.orientation) === 90) {
                setDialog();
                // /縦向き
            } else {
                setDialog(true);
            }
        });
    } else {
        setDialog();
    }

    function dialogOpen(_target, _e) {
        $(window).scrollTop(0);
        $("#modalMovie").dialog({position:{of: window,at: 'center center', my : 'center center'}});
        $("#modalMovie").dialog("open");
    }
    function dialogClose(_target, _e) {
        $('#modalMovie').dialog("close");
    }

    var pointY;
    $(document).on('click', '.btnClose, .ui-widget-overlay', function(_e) {
        dialogClose(this, _e);
        $('#allWrapper').css({
            'position': 'relative',
            'width': '',
            'top': ''
        });
        var modal_position = $("body").attr('modal_position');
        $(window).scrollTop(modal_position);
    });
    $(document).keydown(function(_e){
        if (_e.keyCode == 27) {
            if(document.getElementsByClassName("ui-widget-overlay")){
                _e.preventDefault();
                dialogClose(this, _e);
                $('#allWrapper').css({
                    'position': 'relative',
                    'width': '',
                    'top': ''
                });
                var modal_position = $("body").attr('modal_position');
                $(window).scrollTop(modal_position);
            }
        }
    });
    $('.jsEvModal_Movie').on('click', function(_e) {
        pointY = $(window).scrollTop();
        $("body").attr('modal_position', pointY);
        $('#allWrapper').css({
            'position': 'fixed',
            'width': '100%',
            'top': -pointY
        });
        dialogOpen(this, _e);
    });

    $(window).resize(function(_e) {
    //ie8 resize event なし
        if(!isLteIE8){

            var flg = $('#modalMovie').dialog('isOpen');
            if (flg) {
                $("#modalMovie").dialog("close").dialog("open")
            }

        }
    });
    $(window).setBreakpoints({
        distinct: true,
        breakpoints: [1, 640]
    });
});

//M-BL-6 券面ブロック
(function(){
    $(window).on("load",function(){
        function btn_position(){
            btn_position_reset();
            $(".cardConversionBlock").each(function(){
                var parentHeight = 0;
                $(this).find(".cardConversionDetail").each(function(i){
                    var height = $(this).height();
                    if(parentHeight <= height){
                        parentHeight = height;
                    }
                });

                var target = $(this).find(".cardConversionBtn");
                var btnPosition = 0;
                target.each(function(){
                    var targetHeight = $(this).height();
                    var thisBtnPosition = $(this).find(".btnNormal").position().top;
                    if(btnPosition <= thisBtnPosition){
                        btnPosition = thisBtnPosition;
                    }
                });
                target.each(function(){
                    var targetHeight = $(this).height();
                    var thisBtnPosition = $(this).find(".btnNormal").position().top;
                    var top = btnPosition - thisBtnPosition;
                    $(this).css({
                        "position":"relative",
                        "top":top
                    });
                });
            });
        }
        function btn_position_reset(){
            $(".cardConversionBlock").find(".cardConversionBtn").removeAttr("style");
        }

        var timer = 0;
        var ww = $(window).width();
        if(ww > 640){
            btn_position();
        }
        var timer = 0;
       $(window).on("resize",function(){
            var newSize = $(window).width();
          if (timer > 0) {
            clearTimeout(timer);
          }
          timer = setTimeout(function () {
            if(ww > 640 && newSize < 640){
                btn_position_reset();
            }else if(ww < 640 && newSize > 640){
                btn_position();
            }
            ww = newSize;
          }, 200);
        });
    });
})();

/*アンカーリンク制御*/
$(function () {
    var headerHeight = $("#header").height();
    setTimeout(function(){
        $('a[href^="#"]').click(function(e) {
            if ($(window).width() <= 640) {
            	headerHeight = 75;
            }

            if ($(this).parent().hasClass("subMenu_item-menu")) { //ハンバーガーメニュークリックの場合はスムーススクロール中断
                return;
            }
            e.preventDefault();
            var href= $(this).attr("href");
            var target = $(href);
            var position = target.offset().top - headerHeight;
            if($(this).closest(".modalWindow")[0]) {
                position = position + headerHeight;
            }
            $('body,html').stop().animate({scrollTop:position}, 700, "swing");
            return false;
        });
    }, 500);

    var nowScroll = $(window).scrollTop();
    var hashTag = location.hash;

    if(hashTag) {
        if(nowScroll!=0){
            $('body,html').stop().scrollTop(0);
        }
        var target = $(hashTag);
        var position = target.offset().top - headerHeight;
        $('body,html').stop().animate({scrollTop:position});
    }
});


/*ログインエリア*/
(function () {
    var loginForm = $(document).find('form[action*="/memapi/jaxrs/xt_login/agree/v1"]');
    if (loginForm) {
        var validation = {
            id: {
                input: false,
                format: false,
                count: false
            },
            password: {
                input: false,
                format: false,
                count: false
            }
        };

        var message = {
            id: {
                input: "IDをご入力ください。",
                format: "IDは7~20桁の半角英数字・記号（“_”および“-”）でご入力ください。",
                count: "IDは7~20桁の半角英数字・記号（“_”および“-”）でご入力ください。"
            },
            password: {
                input: "パスワードをご入力ください。",
                format: "パスワードは6~20桁の半角英数字でご入力ください。",
                count: "パスワードは6~20桁の半角英数字でご入力ください。"
            }
        };

        function validationResult(name, _this) {//name="id""password",_this=input
            //validationの値をもとにエラーメッセージを設定
            _this.removeClass(".error").next(".loginValidationMessage").remove();
            var validationMessage = "";
            if (!validation[name].input) {
                validationMessage = message[name].input;
            } else if (!validation[name].format) {
                validationMessage = message[name].format;
            } else if (!validation[name].count) {
                validationMessage = message[name].count;
            }
            if (validationMessage != "") {
                _this.addClass("error").after('<div class="loginValidationMessage">' + validationMessage + '</div>');
            } else {
                _this.removeClass("error").next(".loginValidationMessage").remove();
            }
        }
        var input_id = loginForm.find('input[name="userid"]');
        var input_password = loginForm.find('input[name="password"]');
        var login_submit = loginForm.find('[type="submit"]');

        //IDの入力チェック
        input_id.on("focusout", function () {
            var id_value = $(this).val();
            var thisName = "id";
            if (id_value != "") {
                validation.id.input = true;
            } else {
                validation.id.input = false;
            }
            if (id_value.match(/^[a-zA-Z0-9_-]*$/g)) {
                validation.id.format = true;
            } else {
                validation.id.format = false;
            }
            if (id_value.length >= 7 && id_value.length <= 20) {
                validation.id.count = true;
            } else {
                validation.id.count = false;
            }
            validationResult(thisName, $(this));
        });
        //passwordの入力チェック
        input_password.on("focusout", function () {
            var password_value = $(this).val();
            var thisName = "password";
            if (password_value != "") {
                validation.password.input = true;
            } else {
                validation.password.input = false;
            }
            if (password_value.match(/^[a-zA-Z0-9]*$/g)) {
                validation.password.format = true;
            } else {
                validation.password.format = false;
            }
            if (password_value.length >= 6 && password_value.length <= 20) {
                validation.password.count = true;
            } else {
                validation.password.count = false;
            }
            validationResult(thisName, $(this));
        });
    }
})();

/* 関連リンクの画像自動設（定主要画面のみ）*/
$(function() {
  // hrefを分解
  var RELVANT_PAGE_JSON = '/mem/responsive/data/relevant_page.json'; // 関連リンクのJSONのパス
  var DEFAULT_RELVANT_IMG = '/mem/responsive/img/img_relation_other.png'; // JSONに無い場合の共通画像
  var BLANK_IMG = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=='; // リンク切れアイコン対策のブランク画像
  // 関連リンク情報の配列から指定したURLを含むものを探す
  $.getJSON(RELVANT_PAGE_JSON, function(relevant_page_json) {
    // 主要画面でのみ使用される関連リンクの構造(.relevantPageArea > .imageCutRightType02)で要素を選択
    $('.relevantPageArea > .imageCutRightType02').each(function () {
      var $el = $(this);
      var $link = $el.find('a').first(); // 先頭の関連リンクのみ利用(念の為)
      var $img = $el.find('img').first(); // 先頭の画像のみ利用
      // 関連リンクがない、または画像の要素自体がない場合はスキップ
      if ($link.length === 0 || $img.length === 0) return;
      // 画像にsrcが設定されている場合もスキップ（リンク切れ対策のブランク画像は除く）
      if ($img.attr('src') !== BLANK_IMG && $img.attr('src')) return;

      var matched = false; // JSONのpathにマッチしたかどうかのフラグ
      var pathname = $link.prop('pathname'); // 関連リンクのpathname
      // 関連リンクのpathnameが、JSONのpathにマッチするかチェック
      $.each(relevant_page_json, function(index, json) {
        if (pathname.match(new RegExp('^' + json.path))) {
          $img.attr('src', json.image_path); //  JSONのimage_pathの画像を設定
          matched = true;
          return false;
        }
      });
      // 関連リンクのpathnameが、JSONのpathにマッチしない場合、関連リンク用デフォルト画像を設定
      if (!matched) {
        $img.attr('src', DEFAULT_RELVANT_IMG);
      }
    });
  });
});

var dataList = {};
$(function(){
    const items = document.querySelectorAll("[data-templatepath]");
    const itemsArr = Array.prototype.slice.call(items);
    itemsArr.forEach(function(item,index){
        const order = index + 1;
        dataList["prev"+( '00' + order ).slice( -2 )] = item.innerHTML;
        const elms = item.querySelectorAll("[data-nextPage]");
        const elmsArr = Array.prototype.slice.call(elms);
        const path = item.dataset.templatepath;
        elmsArr.forEach(function(elm,index){
            const jumpTo = elm.dataset.nextpage;
            const url = path + jumpTo + ".html";
            $.ajax({
                url:url,
                dataType : 'html',
            })
            .done(function(data){
                dataList[jumpTo] = data;
                const nodes = item.querySelectorAll("[data-nextPage]");
                for(let i=0;i<nodes.length;i++){
                    nodes[i].addEventListener("click",selectInfoEventHandler);
                }
            })
            .fail(function(data){
                console.error(data)
            });
        });
    });
    function selectInfoEventHandler(event){
        const target = event.currentTarget;
        const jumpTo = target.dataset.nextpage;
        var parentNode = undefined;
        if(jumpTo.indexOf("prev") != -1){
            parentNode = target.parentElement;
            if(jumpTo == "prev"){
                parentNode.innerHTML = dataList[jumpTo + "01"];
            }
            else{
                parentNode.innerHTML = dataList[jumpTo];
            }
        }
        else{
            parentNode = target.parentElement.parentElement;
            parentNode.innerHTML = dataList[jumpTo];
        }
        const items = parentNode.querySelectorAll("[data-nextPage]");
        for(let i=0;i<items.length;i++){
            items[i].addEventListener("click",selectInfoEventHandler);
        }
    }
    const elms = document.querySelectorAll("[data-nextPage]");
    for(let i=0;i<elms.length;i++){
        elms[i].addEventListener("click",selectInfoEventHandler);
    }
});