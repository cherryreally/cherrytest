define([
'dojo/_base/declare', 
'dojo/dom', 
'dojo/dom-style',
'./HMFWidgetUtil',
'dojo/text!./FooterWidgetPostLogin.html', 
'vp/alcor/pages/FooterWidget', 
'vp/alcor/util/findWidgetsRecursive',
'vp/alcor/util/UAUtil',
'vp/alcor/config/AlcorConfig'
], function(declare, dom, domStyle, HMFWidgetUtil, template, FooterWidget, findWidgetsRecursive, UAUtil, AlcorConfig) {

return declare('vps.member.FooterWidgetPostLogin', [FooterWidget],  {
templateString: template,
_sp:"switch_sp",    
enableDevice:   "vps.member.EnableDeviceButton",    
disableDevice:   "vps.member.DisableDeviceButton",  

onStartup: function() {
this.inherited(arguments);

this.afterReplace();
var copyArea = dom.byId('CopyAreaYear');
var year = new Date().getYear();
if (year < 2000) {
year += 1900;
}
copyArea.innerHTML = year;


var accessBy = AlcorConfig.getAccessBy();
if (accessBy === '01') {
domStyle.set(this._sp, "display", "none");
} else {
var _contents = dom.byId('Center');
if(_contents){
findWidgetsRecursive(_contents, function(widget) {
if (widget.declaredClass === this.enableDevice ) {
domStyle.set(this._sp, "display", "block");
} else if(widget.declaredClass === this.disableDevice) {
domStyle.set(this._sp, "display", "none");
}
},this);
}

this.onNode(this._sp, 'click', function() {
UAUtil.switchDevice("03:01");
});
}
},

afterReplace: function(){
HMFWidgetUtil.replaceLink("vpass.member.user.HpSvrRoot", ".HpSvrRoot_footer");
HMFWidgetUtil.replaceLink("vpass.member.user.NosecHpSvrRoot", ".NosecHpSvrRoot_footer");
}
});
});
