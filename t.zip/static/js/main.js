require([
'vp/alcor/control/TransitionManager',
'dojo/ready',
'vps/member/WebApiConst',
'vps/member/DefaultModules',
'vps/member/LoginControlWidget',
'vps/member/HeaderWidgetPostLogin',
'vps/member/MenuWidgetPostLogin',
'vps/member/FooterWidgetPostLogin',
'vp/member/pages/entry',
'dojo/parser'
], function(TransitionManager, ready, WebApiConst) {
TransitionManager.init({
webApiConst: WebApiConst,
acceptHash:[{
hash: 'entry',
contentWidgetName:'vp.member.pages.entry',
history: function() {}
}]
});
});
