define([
'dojo/_base/declare', 
'dojo/query', 
'vp/alcor/pages/_AbstractPage', 
'vp/alcor/util/Logger' 
], function(declare, query,  _AbstractPage, Logger) {
var _myself = 'vp/memx/pages/IncWebAnalyticsGA';
return declare('vps.member.widget.IncWebAnalyticsGA', [_AbstractPage],  {

onStartup: function() {
}
});
});
