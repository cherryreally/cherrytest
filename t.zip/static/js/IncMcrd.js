define([
'dojo/_base/declare',
'dojo/dom-construct',
'dijit/_WidgetBase'
], function(declare, domConst, _WidgetBase) {
var _isLoaded = false;

var CONFIG_CODE = 'var blade_co_account_id="1222"; var blade_group_id="";';

return declare('vps.member.IncMcrd', [_WidgetBase],
 {
startup: function() {
if (_isLoaded) {
return; 
}
_isLoaded = true;
var target = document.body;
domConst.create('div', {
innerHTML: ['&nbsp;<script type="text/javascript" defer="defer">', '<\/script>'].join(CONFIG_CODE)
}, target);
domConst.create('script', {
type: 'text/javascript',
src: 'https://d-track.send.microad.jp/js/bl_track.js'
}, target);
}
});
});
