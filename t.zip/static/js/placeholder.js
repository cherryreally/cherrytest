    // プレースホルダー
   var ahPlaceholder = function(){
        $('#side input[type="text"], #side input[type="password"], #gNavi input[type="text"], #gNavi input[type="password"], .ktop_infoBox .loginInfoBox ul li input')
        .placeholder();
    }
    ahPlaceholder();
