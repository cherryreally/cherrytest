define([
'dojo/_base/declare', 
'dojo/dom', 
'./HMFWidgetUtil',
'dojo/text!./MenuWidgetPreLogin.html', 
'vps/member/WebApiConst', 
'vps/member/VerisignSeal',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/control/StoreManager',
'vp/alcor/pages/MenuWidget', 
'vp/alcor/view/ExtLink'
], function(declare, dom, HMFWidgetUtil, template, WebApiConst,
VerisignSeal, AlcorConstants, StoreManager, MenuWidget, ExtLink) {

return declare('vps.member.MenuWidgetPreLogin', [MenuWidget],  {
templateString: template,

onStartup: function() {
var that = this;
this.inherited(arguments);


}
});
});
