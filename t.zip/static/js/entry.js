define([
'dojo/_base/declare',
'dojo/query',
'dojo/_base/lang',
'dojo/dom',
'dojo/text!./entry.html',
'dijit/registry',
'vp/alcor/pages/_AbstractPage',
'vp/alcor/control/TransitionManager',
'vp/alcor/control/ValueController',
'vp/alcor/view/inputcheck/AlcorValidators',
'vp/alcor/view/inputcheck/DataTypeValidators',
'vp/alcor/view/FuncControl',
'vp/alcor/view/Message',
'vp/alcor/view/ErrorMessage',
'vpx/view/ActionPreparatorBr',
'vpx/view/ValidationHandler',
'vps/member/WebApiConst',
'vp/alcor/control/StoreManager',
'vps/member/EnableDeviceButton',
'vps/member/IncCommonFunctions'
], function(declare, query, lang, dom, templatePath, registry,
_AbstractPage, TransitionManager, ValueController,
AlcorValidators, DataTypeValidators, FuncControl, Message, ErrorMessage,
ActionPreparator, ValidationHandler, WebApiConst, StoreManager){

return declare('vp.member.pages.entry', [_AbstractPage], {

templateString: templatePath,
preventBack: true,
cssClass: 'mainWidgetBase',
includeQueryParamOnInit: true,
isNeedReturnMySelfAfterLogin: true, 

initTransitOptions: {
webApiId: WebApiConst.API.VC0201001_RS0011,
success: function(res) {
if (res && res.body && res.body.content && res.body.content.PwRecreateAuthDisplayServiceBean) {
ValueController.updateFormWithoutCache('FRM_c_GMVC0201001U327210-0001',
res.body.content.PwRecreateAuthDisplayServiceBean);
}
}
},
onStartup: function() {
var formId = 'FRM_c_GMVC0201001U327210-0001';
var formNode = registry.byId(formId) || dom.byId(formId);

ValueController.updateForm(formId);

StoreManager.dataStore.remove('FRM_c_GMVC0201001U327211-0001');
StoreManager.dataStore.remove('FRM_c_GMVC0201001U327212-0001');

function clearAuth() {
var data = ValueController.get('FRM_c_GMVC0201001U327210-0001');
if (data) {
if (data.acct4_re) {
data.acct4_re = '';
}
data.debitAcctNoCertDispState = "0";
}
}

this.onNode(formNode, 'submit', function() {
ValidationHandler.init();
TransitionManager.transit({
webApiId: WebApiConst.API.VC0201001_RS0012,
formId: formId,
onValidationFailed: ValidationHandler.onValidationFailed,
doMove: true,
success: clearAuth,
error: clearAuth,
preventScreenDataCache: true
});
}, true);


ActionPreparator.prepareInputActions();
ActionPreparator.prepareAccordionActions();
ActionPreparator.prepareAccordionSlideActions();


function checkBirthday() {
var nodeYear  = dom.byId('vp-view-VC0201-001_RS0010_birth_year');
var nodeMonth = dom.byId('vp-view-VC0201-001_RS0010_birth_mon');
var nodeDay   = dom.byId('vp-view-VC0201-001_RS0010_birth_day');
if (nodeYear && nodeYear.value && nodeMonth && nodeMonth.value && nodeDay && nodeDay.value) {
var r = true;
r &= DataTypeValidators.Year.getValidator()(nodeYear.value);
r &= nodeYear.value >= 1800;
r &= DataTypeValidators.Month.getValidator()(nodeMonth.value);
r &= DataTypeValidators.Day.getValidator()(nodeDay.value);

return r;
}
return false;
}


lang.hitch(this, function() { 
var node = 'vp-view-VC0201-001_RS0010_acct1';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.UserAccount,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100001'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_acct2';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.UserAccount,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100002'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_acct3';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.UserAccount,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100003'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_acct4';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.UserAccount,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100004'})
});
})();

FuncControl.getResult({
functionControlKey:'Reauthentication_method',
type:'equals',
value:'2'
}).then(lang.hitch(this, function(isEqual) {
if (isEqual) {
var node = 'vp-view-VC0201-001_RS0010_acct4_re';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.UserAccountLast4,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100008'})
});
}
}));

FuncControl.getResult({
functionControlKey:'Reauthentication_method',
type:'equals',
value:'1'
}).then(lang.hitch(this, function(isEqual) {
if (isEqual) {
var node = 'vp-view-VC0201-001_RS0010_cvv2';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.Cvv2AuthCode,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100007'})
});
}
}));

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_limit_mon';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.CardMonth,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100006'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_limit_year';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.CardYear,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100005'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_birth_year';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.Year,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100009'})
});

this.addValidation({
node: node,
validator: function(value) {
return value >= 1800;
},
checkOnChange: true,
invalidMessage:Message.getMessage({msgKey:'00.U327.E2100018'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_birth_mon';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.Month,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100010'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_birth_day';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.Day,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100011'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_birth_day';

this.addValidation({
node: node,
validator: function() {
if (checkBirthday()) {
var nodeYear  = dom.byId('vp-view-VC0201-001_RS0010_birth_year');
var nodeMonth = dom.byId('vp-view-VC0201-001_RS0010_birth_mon');
var nodeDay   = dom.byId('vp-view-VC0201-001_RS0010_birth_day');

var year  = nodeYear.value;
var month = nodeMonth.value;
var day   = nodeDay.value;
if (month.length === 1) {
month = '0' + month;
}
if (day.length === 1) {
day = '0' + day;
}
var birthday = year + month + day;

return AlcorValidators.checkDate(birthday, {dateFormat : 'yyyyMMdd'});
}
return true;
},
invalidMessage:Message.getMessage({msgKey:'00.U327.E2100017'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_phone1';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.KaiinPhone1,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100012'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_phone2';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.Phone2,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100013'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_phone3';

this.addDataTypeValidation({
node: node,
datatypeValidator: DataTypeValidators.Phone3,
required: true,
common:false,
checkOnChange: true,
missingMessage:Message.getMessage({msgKey:'00.U327.E2100014'})
});
})();

lang.hitch(this, function() {
var node = 'vp-view-VC0201-001_RS0010_phone3';

this.addValidation({
node: node,
validator: function() {
var nodePhone1 = dom.byId('vp-view-VC0201-001_RS0010_phone1');
var nodePhone2 = dom.byId('vp-view-VC0201-001_RS0010_phone2');
var nodePhone3 = dom.byId('vp-view-VC0201-001_RS0010_phone3');
if (nodePhone1 && nodePhone1.value && nodePhone2 && nodePhone1.value && nodePhone3 && nodePhone3.value) {
var phone = nodePhone1.value + nodePhone2.value + nodePhone3.value;
if (phone.length > 11) {
var r = true;
r &= DataTypeValidators.KaiinPhone1.getValidator()(nodePhone1.value);
r &= DataTypeValidators.Phone2.getValidator()(nodePhone2.value);
r &= DataTypeValidators.Phone3.getValidator()(nodePhone3.value);
if (r) {
return false;
}
}
}
return true;
},
invalidMessage:Message.getMessage({msgKey:'00.U327.E2100019'})
});
})();
}
});
});
