define([
'dojo/_base/declare',
'dojo/_base/lang',
'dojo/dom',
'dojo/text!./DeviceButton.html',
'dojo/dom-style',
'vp/alcor/util/UAUtil',
'vp/alcor/config/AlcorConfig',
'vp/alcor/constants/AlcorConstants',
'vp/alcor/pages/_AbstractPage'
], function(declare, lang, dom, template, domStyle, UAUtil, AlcorConfig, AlcorConstants, _AbstractPage) {
return declare('vps.member.EnableDeviceButton', [_AbstractPage], {
templateString: template,
_sp:"switch_sp",
onStartup: function() {
var accessBy = AlcorConfig.getAccessBy();
if (accessBy === '01') {
if (dom.byId('switch_sp')){
domStyle.set(this._sp, "display", "none");
}
} else {
if (dom.byId('switch_sp')){
domStyle.set(this._sp, "display", "block");
}
}
}
});
});
