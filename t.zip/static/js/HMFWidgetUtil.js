define([
'dojo/_base/declare', 
'dojo/_base/array',
'dojo/dom-attr',
'dojo/query',
'vp/alcor/control/StoreManager',
'vp/alcor/constants/AlcorConstants'
], function(declare, array, domAttr, query, StoreManager, AlcorConstants){

return new declare([],{

replaceLink: function(sysPropKey, className) {
var that = this;
if(sysPropKey){
StoreManager.keyStorePromise.then(function(keyStore) {
var sysprops = keyStore.get(AlcorConstants.SYS_PROP_KEY);

if(sysprops){
var syspropsVal = sysprops [sysPropKey];
that.addPath(className, syspropsVal);
}
});
}
},

addPath: function(className, sysPropVal) {
var _nodes = query(className);

if(sysPropVal){
array.forEach(_nodes, function(_node){
if(_node){
var localName = _node.localName || _node.nodeName.toLowerCase();
var attrName;
if(localName === "a"){
attrName = "href";
}else if(localName === "form"){
attrName = "action";
}else if(localName === "iframe"){
attrName = "src";
}
if(attrName && domAttr.has(_node,attrName)){
var _val = domAttr.get(_node, attrName);
if(_val){
var link;
if (localName === "iframe") {
link = sysPropVal;
} else {
link = sysPropVal + _val;
}
domAttr.set(_node, attrName, link);
}
}
}
});
}

}

})();
});
