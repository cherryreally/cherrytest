define([
'dojo/_base/declare', 
'dojo/text!./HeaderWidgetPreLogin.html', 
'./HMFWidgetUtil',
'vpx/view/megadropdown',
'vpx/view/ActionPreparatorBr',
'vp/alcor/pages/HeaderWidget' 
], function(declare, template, HMFWidgetUtil, megadropdown, ActionPreparator,
HeaderWidget) {

return declare('vps.member.HeaderWidgetPreLogin', [HeaderWidget],  {
templateString: template,

onStartup: function() {
this.inherited(arguments);

ActionPreparator.prepareHeaderActions();
if(megadropdown.MDDinit){
megadropdown.MDDinit();
}

this.afterReplace();
},
afterReplace: function(){
HMFWidgetUtil.replaceLink("vpass.member.user.HpSvrRoot", ".HpSvrRoot_header");
}
});
});
