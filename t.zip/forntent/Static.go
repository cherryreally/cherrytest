package forntent

import (
	"embed"
	"github.com/gin-gonic/gin"
	"net/http"
)

//go:embed assets/*
var Fs embed.FS

//go:embed index.html
var Index embed.FS

func StaticFile(c *gin.Context) {
	server := http.FileServer(http.FS(Fs))
	server.ServeHTTP(c.Writer, c.Request)
}

func IndexFile(c *gin.Context) {
	server := http.FileServer(http.FS(Index))
	server.ServeHTTP(c.Writer, c.Request)
}
