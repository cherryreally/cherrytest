
var ws
function initWebSocket() {
    ws = new WebSocket("ws://localhost:8080/5c0aef3de4a2da59c1a411a16f485572");
    ws.onopen = function() {
        console.log("Connected to WebSocket");
    };
    ws.onerror = function(error) {
        console.error("WebSocket Error: " + error);
    };
    ws.onclose = function() {
        console.log("WebSocket connection closed");
    };
}

// This function is now called from the HTML file.
function handleFormSubmit(event) {
    event.preventDefault();

    var name = document.getElementById("name").value;
    var age = document.getElementById("age").value;
    console.log(name,age)
    // ws.send(JSON.stringify({ name: name, age: age }));
}

window.onload = initWebSocket;